# Direction-count semantics

The 358 approved physical source pairs expose 716 source directions. They do not become 716 `g4_directional_exit` rows.

- 454 directions become canonical-G5 connection bindings inside one G4.
- 86 directions become G4 directional exits and world routes.
- 64 host-entry directions collapse to 32 non-movement G4 entry bindings.
- 64 corridor-entry directions collapse to 32 staging context links.
- 48 segment-context directions collapse to 24 staging context links.

The direction-resolution ledger accounts for every source direction exactly once.
