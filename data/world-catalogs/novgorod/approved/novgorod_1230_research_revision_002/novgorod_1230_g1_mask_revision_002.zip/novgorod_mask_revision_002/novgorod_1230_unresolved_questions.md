# Неразрешённые вопросы

- **CNF_IZHORA_VOD_BORDER** — Точная граница ижорско-водской зоны и степень новгородского контроля: Cells remain contested/dependent; no exact boundary polygon.
- **CNF_KARELIA_CONTROL** — Форма контроля Новгорода над карельскими землями около 1230 года: Karelian cells are dependent or contested, never core/direct by default.
- **CNF_BELOOZERO_VAGA_JURISDICTION** — Новгородско-Ростово-Суздальские юрисдикции в Белозерско-Сухонско-Важском пространстве: Interface cells remain contested; Beloozero is external G0.
- **CNF_ZAVOLOCHYE_EXACT_EXTENT** — Точная внешняя граница Заволочья в 1230 году: Sparse corridor-and-anchor mask; no filled territorial polygon.
- **CNF_ROUTE_TRACES** — Точные трассы дорог и волоков: Corridor geometry only; exact_route_claim=false.
- **CNF_LATE_ADMIN_RETROJECTION** — Использование поздних пятин и писцовых книг: No pyatina boundaries used in candidate mask.
