from pathlib import Path
from collections import Counter, defaultdict
import json, tempfile, zipfile

ROOT=Path(__file__).resolve().parents[1]

def load(rel): return json.loads((ROOT/rel).read_text(encoding='utf-8'))
def fail(msg): print('FAIL direction ledger:',msg); raise SystemExit(1)
def vref(row):
    if 'id' in row and 'version' in row: return f"{row['id']}@{row['version']}"
    if 'profile_id' in row and 'profile_version' in row: return f"{row['profile_id']}@{row['profile_version']}"
    if 'segment_id' in row and 'segment_version' in row: return f"{row['segment_id']}@{row['segment_version']}"
    return None

expected_kind_counts={
    'intra_g4_site_connection_source':454,
    'cross_g4_world_route_source':86,
    'host_entry_site_connection_source':64,
    'corridor_to_host_route_context_source':64,
    'world_route_segment_context_source':48,
}
expected_pair_counts={
    'intra_g4_site_connection_source':227,
    'cross_g4_world_route_source':43,
    'host_entry_site_connection_source':32,
    'corridor_to_host_route_context_source':32,
    'world_route_segment_context_source':24,
}
expectation={
    'intra_g4_site_connection_source':('canonical_g5_connection_binding',1,True),
    'cross_g4_world_route_source':('g4_directional_exit+world_route',2,True),
    'host_entry_site_connection_source':('g4_entry_endpoint_binding_non_movement',1,False),
    'corridor_to_host_route_context_source':('route_context_link_staging_only',1,False),
    'world_route_segment_context_source':('route_context_link_staging_only',1,False),
}

rows=load('data/direction-resolution-ledger.json')['records']
if len(rows)!=716: fail(f'row count {len(rows)} != 716')
if Counter(r['source_mapping_kind'] for r in rows)!=Counter(expected_kind_counts): fail('direction class counts')
if len({r['direction_id'] for r in rows})!=716: fail('direction_id is not unique')
if any(r['resolution_status']!='approved_resolved' for r in rows): fail('unresolved row')
if any(r['blocking_gap_code'] is not None for r in rows): fail('non-null blocking gap')

local_refs=set()
for path in (ROOT/'target').glob('*.json'):
    data=json.loads(path.read_text(encoding='utf-8'))
    for row in data.get('records',[]):
        ref=vref(row)
        if ref: local_refs.add(ref)

by_pair=defaultdict(list)
for r in rows:
    by_pair[r['source_pair_id']].append(r)
    kind=r['source_mapping_kind']
    cls,nrefs,moving=expectation[kind]
    if r['target_compilation_class']!=cls: fail(f"{r['direction_id']} class")
    if not isinstance(r['target_refs'],list) or len(r['target_refs'])!=nrefs: fail(f"{r['direction_id']} target_refs")
    if not isinstance(r['runtime_movement'],bool) or r['runtime_movement'] is not moving: fail(f"{r['direction_id']} runtime_movement")
    missing=[x for x in r['target_refs'] if x not in local_refs]
    if missing: fail(f"{r['direction_id']} missing target refs {missing}")
if any(len(v)!=2 for v in by_pair.values()): fail('each physical pair must have exactly two directions')
if Counter(v[0]['source_mapping_kind'] for v in by_pair.values())!=Counter(expected_pair_counts): fail('pair class counts')

with tempfile.TemporaryDirectory() as td:
    with zipfile.ZipFile(ROOT/'inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip') as z:
        if z.testzip() is not None: fail('embedded source ZIP corrupt')
        z.extractall(td)
    matches=list(Path(td).rglob('data/physical-exit-source-pairs.json'))
    if len(matches)!=1: fail('source physical pair catalogue not unique')
    src=json.loads(matches[0].read_text(encoding='utf-8'))['records']
source_pairs={r['physical_exit_pair_id']:r for r in src}
if len(source_pairs)!=358 or set(source_pairs)!=set(by_pair): fail('source pair identity coverage')
source_dirs={}
for pair in src:
    if pair['direction_count']!=2 or len(pair['directions'])!=2: fail(pair['physical_exit_pair_id']+' source direction cardinality')
    for d in pair['directions']:
        source_dirs[d['direction_id']]={
            'source_pair_id':pair['physical_exit_pair_id'],
            'source_mapping_kind':pair['target_mapping_kind'],
            'edge_type':pair['edge_type'],
        }
if len(source_dirs)!=716: fail('source direction identity count')
ledger_dirs={r['direction_id']:{k:r[k] for k in ('source_pair_id','source_mapping_kind','edge_type')} for r in rows}
if source_dirs!=ledger_dirs: fail('ledger is not an exact typed projection of source directions')

# Pair-level rows intentionally collapse to one target for nonmovement/staging classes.
for pair_id,pair_rows in by_pair.items():
    kind=pair_rows[0]['source_mapping_kind']
    flat=[x for r in pair_rows for x in r['target_refs']]
    if kind in {'host_entry_site_connection_source','corridor_to_host_route_context_source','world_route_segment_context_source'}:
        if len(set(flat))!=1: fail(pair_id+' expected pair-level collapsed target')
    else:
        if len(set(flat))!=len(flat): fail(pair_id+' movement directions must have distinct targets')

print('PASS verify_direction_ledger 358 pairs / 716 directions / exact target refs')
