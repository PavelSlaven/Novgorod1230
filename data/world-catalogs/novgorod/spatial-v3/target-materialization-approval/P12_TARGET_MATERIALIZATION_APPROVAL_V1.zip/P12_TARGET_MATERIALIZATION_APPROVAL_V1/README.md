# P12 target materialization approval bundle v1

## Goal

Approve the missing target authoring inputs required after the accepted P12 source package and target-contract specification: semantic version pins, connection profiles, route chains, exact normalized target rows and permission for isolated target-DDL materialization.

## Decision

Status: `APPROVED_WITH_ACTIVATION_BOUNDARY`.

Approved:

- target world revision plus 49 canonical G0–G3 parent/version pins: 50 version pins total;
- contract amendment `rus.p12_target_contract_amendment@1.2.0` for isolated implementation;
- 12 connection/route-segment profiles;
- 227 canonical spatial rows: 32 G4 hosts and 195 canonical G5 parcels;
- 195 scene profiles and 195 deterministic candidates;
- 454 directed same-G4 canonical-G5 connection bindings;
- 32 non-movement G4 entry bindings;
- 56 compiler-staging context links;
- 86 directed G4 exits and 86 direct one-segment world routes;
- 172 route points, 86 route segments, 86 mandatory segment spatial contexts and 172 endpoint bindings;
- typed resolution of all 358 physical source pairs / 716 directions;
- exact row-level projection under `target/`;
- isolated PostgreSQL target-DDL materialization after branch binding.

## Authority boundary

This is an owner-requested editorial and technical approval. It authorizes implementation of the exact approved contracts and isolated PostgreSQL apply/readback/rollback. It is not a release signature, independent critic result, repository commit, deployment record or permission to write to an operator/production database.

P12 authoring gaps are resolved. Repository gap flags may close only after the exact projection is implemented and passes the gates in `P12_GAP_CLOSURE_AUTHORIZATION.json`. P28 and production remain blocked. Production v2 is unchanged.

## Pinned inputs

- target specification ZIP SHA-256: `1833b383e5ee2568330ab88ae40c7d5b9d057dbde81aa4f43641c48ecd3eb6f3`;
- source approval ZIP SHA-256: `e3342beac492ff6433a03ecbf7c32dbffdc9dafce8e7ebd623af826b33d7bbbe`;
- observed canonical `main`: `9f2a8c1477793e3baac376d558a64b1b2272cc4a`;
- target world revision: `novgorod_spatial_v3_target_contract_approval_001@1`.

The reported local integration was not visible in observable GitHub refs during preparation. `data/repository-observation.json` records the observation. Repository apply requires the pushed existing task branch to satisfy `templates/repository-branch-binding.template.json`; no branch or HEAD is inferred.

## Principal decisions

1. The 716 source directions are classified, not flattened into 716 exits: 454 site connections, 86 actual route directions and 176 non-movement/staging directions.
2. Each approved cross-G4 source pair compiles to two reciprocal directed one-segment routes. No shortest-path, nearest-endpoint or first-row synthesis is permitted.
3. Source direction is topological. Numeric bearings are forbidden because the accepted source contains no factual azimuth.
4. All world-route segments are time-based. Local same-G4 connections are action-based. The four shore-transfer directions use the approved 15-minute gameplay calibration and dynamic checks.
5. Minutes and risk bands are versioned gameplay calibration, not measured historical distance or duration.
6. Unknown or failed mandatory availability checks block traversal. No semantic fallback is allowed.
7. `target/` is the only approved row-level DDL input. `data/` contains decisions, trace and review ledgers.

## Package structure

- `target/` — exact normalized rows authorized for target-DDL projection;
- `data/` — approvals, pins, trace ledgers, authorization and repository observations;
- `workbooks/` — completed reviewable authoring tables;
- `schemas/` — validation contracts;
- `scripts/` — fail-closed structural, semantic, source, workbook, branch and manifest checks;
- `docs/` — decisions, integration order and audit cycles;
- `reports/` — actually executed standalone checks;
- `inputs/` — immutable accepted ZIP inputs;
- `templates/` — intentionally unbound repository handoff evidence.

## Integration order

1. Push and bind the existing single task branch/PR; do not create another PR.
2. Verify both input ZIP hashes and this bundle manifest.
3. Add failing contract, negative and database tests.
4. Implement amendment v1.2.0 and normalized DDL against the exact branch-owned schema.
5. Compile only `target/` and apply it to isolated PostgreSQL.
6. Verify counts, FKs, uniqueness, reciprocity, route continuity, readback digest, idempotence and rollback.
7. Regenerate `SCHEMA_REFERENCE.md` and repository-intelligence artifacts.
8. Run targeted checks and full `npm test`.
9. Obtain independent critic `PASS` or admissible `PASS WITH NOTES`.
10. Close P12 operational gap flags for the exact bundle digest.
11. Create an exact activation-candidate commit.
12. Obtain trusted signed P27, fresh-checkout and P28 evidence before any production switch.

## Standalone checks

```bash
python scripts/validate_package.py
python scripts/validate_target_projection.py
python scripts/verify_source_reproduction.py
python scripts/verify_scene_endpoint_slots.py
python scripts/verify_direction_ledger.py
python scripts/verify_workbooks.py
python scripts/validate_json_schemas.py
python scripts/validate_artifact_structure.py
python scripts/verify_repository_branch_binding.py --expect-blocked
python scripts/semantic_audit.py
python scripts/verify_manifest.py
python scripts/run_all_checks.py
```

Final standalone audit result: `PASS`, open findings: `0`.

## Known limitations and remaining work

Not performed in this standalone environment:

- repository checkout changes, commit or PR update;
- exact binding to the user’s unpushed local integration HEAD;
- target DDL implementation;
- PostgreSQL apply/readback/idempotence/rollback;
- generated schema-reference rebuild;
- project test suite, Graphify/RAG rebuild or runtime E2E;
- independent repository critic;
- signed P27, fresh-checkout or P28 evidence;
- production deployment or composition switch.

These are operational/release gates, not missing authoring values.
