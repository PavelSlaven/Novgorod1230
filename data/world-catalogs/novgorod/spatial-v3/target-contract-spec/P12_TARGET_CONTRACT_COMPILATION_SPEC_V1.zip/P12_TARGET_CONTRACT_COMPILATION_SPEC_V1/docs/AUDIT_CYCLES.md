# Итеративные циклы аудита

## Цикл 1 — семантика количеств

Замечания:

1. `358` допускало трактовку как число directional exits.
2. `600` допускало трактовку как target SQL row count.
3. `716` могло быть ошибочно объявлено числом world routes.

Исправления: source counts отделены от target logical projections; SQL row counts запрещено выводить до exact DDL compilation manifest.

## Цикл 2 — классы связей

Замечания:

1. Source label `host_entry_site_connection_source` создавал ложное ожидание party connection между G3/G4 и G5.
2. G2/G3 context links могли быть ошибочно импортированы как time-bearing routes.
3. Cross-G4 endpoint на retained G3 не был однозначно разрешён в canonical entry G5.

Исправления: введены non-movement `g4_entry_endpoint_binding`, staging-only `route_context_link` и exact G3→entry-G5 endpoint projection.

## Цикл 3 — owner target contract

Замечания:

1. Target standard определял party `g5_site_connection`, но не world-base authoring owner.
2. Не были формализованы action/time XOR, orientation/environment ownership, reverse bindings и scene endpoint slots.
3. Compiler stages не имели полного input/output/error/side-effect разделения.

Исправления: создан proposed contract amendment и восемь изолированных compiler stages. Amendment остаётся неактивным до branch integration и critic cycle.

## Цикл 4 — отсутствующие редакторские данные

Замечания:

1. Source pairs не содержат factual orientation, environment, movement cost, recheck, risk, capacity или availability profiles.
2. Cross-G4 pairs не содержат approved direction contexts, directional exits и ordered route chains.
3. Retained G2/G3 не содержат exact target authoring versions, а target world revision не подтверждён branch graph.
4. Scene profiles требуют exact branch contract/version validation, несмотря на детерминированное source coverage.

Исправления: добавлены fail-closed profile, route-chain и version-pin workbooks; каждый пробел имеет typed blocking gap.

## Цикл 5 — evidence boundary

Замечания:

1. Структурно заполненный JSON мог получить ложный `PASS` без проверки подписи.
2. Не был определён canonical signing payload.
3. Не были определены trusted roles, revoked-key behavior и evidence-file digest binding.

Исправления: verifier требует active trust store, role-bound Ed25519 keys, canonical payload verification и exact evidence-file digests. Встроенный empty trust-store template гарантированно блокируется.

## Цикл 6 — commit/deployment identity

Замечания:

1. Предыдущая последовательность допускала P27/fresh-checkout до создания activation patch, а затем требовала evidence для другого commit.
2. Термины repository activation и production deployment могли смешиваться.

Исправления: определён один `activation_candidate_commit`, к которому привязаны P27, fresh checkout и P28; commit не считается production-active до отдельного signed deployment. Post-deployment выполняет smoke verification того же SHA, а не создаёт новый непроверенный patch.

## Цикл 7 — воспроизводимость и целостность

Замечания:

1. Не было доказано byte-identity copied inputs с исходным ZIP.
2. Не было deep semantic check parentage, route reciprocity, profile coverage и pin cardinality.
3. Manifest не имел отдельной sidecar-проверки.

Исправления: добавлены source-manifest verification, reproducibility check, semantic audit, JSON Schema validation и manifest sidecar.

## Финальный аудит

Проверены термины, counts, relation ownership, parentage, version pinning, route reciprocity, scene coverage, fail-closed behavior, side effects, signature trust boundary, integration order и rollback boundary.

**Открытые замечания к внутренней ясности пакета: 0.**

Оставшиеся gaps — явно описанные отсутствующие branch-owned данные, утверждения и доказательства. Они не маскируются как завершённая реализация.
