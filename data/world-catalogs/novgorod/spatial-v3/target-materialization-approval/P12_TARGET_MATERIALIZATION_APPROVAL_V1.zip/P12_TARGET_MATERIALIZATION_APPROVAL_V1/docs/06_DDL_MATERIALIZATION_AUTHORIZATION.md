# DDL materialization authorization

Implementation is authorized only in the existing task branch and an isolated PostgreSQL database.

Required physical capabilities:

1. immutable `(id, version)` authoring identities;
2. normalized canonical nodes, scene profiles/candidates, connection profiles/bindings, entry bindings, exits, routes, points, segments, contexts and endpoints;
3. FK/version graph checks;
4. same-parent constraint for G5 bindings;
5. reciprocal reverse constraints;
6. action/time XOR;
7. continuous route ordinals and exactly one from/to endpoint;
8. runtime denial for staging tables;
9. immutable import manifest and readback digest;
10. regenerated `SCHEMA_REFERENCE.md` from actual DDL.

The authorized flow is dry-run → apply → readback digest → rollback in isolated PostgreSQL. Operator and production databases are prohibited.
