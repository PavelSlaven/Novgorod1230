from __future__ import annotations
import json, sys
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
CASES = [
    ('data/contract-amendment.json', 'schemas/contract-amendment.schema.json'),
    ('data/gap-ledger.json', 'schemas/gap-ledger.schema.json'),
    ('templates/P27_SIGNED_AUDIT_EVIDENCE.template.json', 'schemas/p27-signed-audit-evidence.schema.json'),
    ('templates/FRESH_CHECKOUT_EVIDENCE.template.json', 'schemas/fresh-checkout-evidence.schema.json'),
    ('templates/P28_ACTIVATION_DECISION.template.json', 'schemas/p28-activation-decision.schema.json'),
    ('templates/ACTIVATION_TRUST_STORE.template.json', 'schemas/activation-trust-store.schema.json'),
]
errors = []
for instance_path, schema_path in CASES:
    instance = json.loads((ROOT / instance_path).read_text(encoding='utf-8-sig'))
    schema = json.loads((ROOT / schema_path).read_text(encoding='utf-8-sig'))
    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(instance), key=lambda x: list(x.absolute_path)):
        errors.append({'instance': instance_path, 'schema': schema_path, 'path': list(e.absolute_path), 'message': e.message})
if errors:
    print(json.dumps({'result': 'FAIL', 'errors': errors}, ensure_ascii=False, indent=2))
    sys.exit(1)
print(json.dumps({'result': 'PASS', 'validated_pairs': len(CASES), 'errors': []}, ensure_ascii=False, indent=2))
