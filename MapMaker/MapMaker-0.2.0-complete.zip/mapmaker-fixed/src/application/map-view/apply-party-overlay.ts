import type { MapNodeDTO } from "../../domain/types.js";
import type { LocalCanonicalGraph, OverlayGraph } from "./internal.js";

function mergeStatus(a?: MapNodeDTO["visibleStatus"], b?: MapNodeDTO["visibleStatus"]): MapNodeDTO["visibleStatus"] | undefined {
  if (!a && !b) return undefined;
  return { ...a, ...b };
}

export function applyPartyOverlay(graph: LocalCanonicalGraph): OverlayGraph {
  const nodeStatusById = new Map<string, MapNodeDTO["visibleStatus"]>();
  for (const item of graph.partyOverlay.nodes ?? []) nodeStatusById.set(item.nodeId, mergeStatus(nodeStatusById.get(item.nodeId), item.visibleStatus));
  const edgeStateById = new Map<string, { traversalState?: import("../../domain/types.js").TraversalState; knownSummary?: string }>();
  for (const item of graph.partyOverlay.edges ?? []) edgeStateById.set(item.edgeId, { traversalState: item.traversalState, knownSummary: item.knownSummary });
  return { ...graph, nodeStatusById, edgeStateById };
}
