# Integration guide

1. Place the archive in one local clean branch, outside production runtime paths.
2. Compare the observed baseline with the actual branch HEAD; update baseline facts only from evidence.
3. Verify the immutable P12 ZIP, internal source manifest and package checks.
4. Reconcile the proposed contract amendment with the exact branch contract matrix and priority norms.
5. Through TDD, implement schemas, DTOs, validators, DDL, importers and isolated stages `P12-TC01`…`P12-TC08`.
6. Resolve the exact target world revision and retained G2/G3 version pins.
7. Fill endpoint-profile and route-chain workbooks through the editorial process; run historical and mechanical audits.
8. Generate the compiled target bundle and canonical digest; generated output is never edited manually.
9. Run isolated PostgreSQL dry-run, apply, readback digest and rollback; then targeted and full project checks.
10. Prepare one exact `activation_candidate_commit` containing the complete v3 implementation and composition switch, but do not deploy it.
11. Run the independent P27 critic and a fresh checkout against that exact commit SHA. Produce real signed evidence through trusted release keys.
12. Produce a signed P28 decision bound to the same commit and exact evidence-file digests.
13. Deploy only that signed commit atomically, then run post-deployment SHA/composition smoke checks.

Production v2 remains deployed through step 12. No step permits dual-write, partial activation, unsigned evidence or a different deployment commit.
