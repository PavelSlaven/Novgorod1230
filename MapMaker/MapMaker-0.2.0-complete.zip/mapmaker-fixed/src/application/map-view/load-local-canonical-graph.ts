import type { BuildMapViewInput } from "../../domain/types.js";
import type { LocalCanonicalGraph, ValidatedRequest } from "./internal.js";

export function loadLocalCanonicalGraph(input: BuildMapViewInput, request: ValidatedRequest): LocalCanonicalGraph {
  const nodes = input.nodes.filter((node) => node.parentNodeId === request.parentNodeId && node.level === request.level);
  const nodeIds = new Set(nodes.map((node) => node.id));
  if (nodes.length === 0) throw new Error("empty_local_map");
  if (!nodeIds.has(request.currentNodeId)) throw new Error("current_position_outside_local_map");
  const edges = input.edges.filter((edge) => nodeIds.has(edge.source) || nodeIds.has(edge.target));
  const boundaryExits = (input.boundaryExits ?? []).filter((exit) => nodeIds.has(exit.sourceNodeId));
  return {
    request, nodes, edges, boundaryExits,
    nodeKnowledge: input.nodeKnowledge,
    edgeKnowledge: input.edgeKnowledge,
    partyOverlay: input.partyOverlay ?? {},
    layout: input.layout
  };
}
