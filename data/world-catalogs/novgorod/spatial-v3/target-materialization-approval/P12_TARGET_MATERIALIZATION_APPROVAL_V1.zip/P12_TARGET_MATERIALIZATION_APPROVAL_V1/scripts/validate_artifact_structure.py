from pathlib import Path
import csv,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def fail(msg): print('FAIL artifact structure:',msg); raise SystemExit(1)
json_count=csv_count=md_count=py_count=0
for p in ROOT.rglob('*'):
    if p.is_symlink(): fail('symlink forbidden '+str(p.relative_to(ROOT)))
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix()
    if any(ord(ch)<32 for ch in rel): fail('control character in path '+repr(rel))
    if '__pycache__' in p.parts or p.suffix in {'.pyc','.tmp','.bak'}: fail('unexpected generated file '+rel)
    if p.suffix=='.json':
        json.loads(p.read_text(encoding='utf-8')); json_count+=1
    elif p.suffix=='.csv':
        with p.open(encoding='utf-8',newline='') as f: table=list(csv.reader(f))
        if not table or not table[0] or len(table[0])!=len(set(table[0])): fail('invalid CSV header '+rel)
        width=len(table[0])
        for i,row in enumerate(table[1:],2):
            if len(row)!=width: fail(f'{rel}:{i} width {len(row)} != {width}')
        csv_count+=1
    elif p.suffix=='.md':
        text=p.read_text(encoding='utf-8')
        if sum(1 for line in text.splitlines() if line.lstrip().startswith('```'))%2: fail('unbalanced code fence '+rel)
        md_count+=1
    elif p.suffix=='.py':
        compile(p.read_text(encoding='utf-8'),str(p),'exec'); py_count+=1
for rel in ['inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip','inputs/P12_TARGET_CONTRACT_COMPILATION_SPEC_V1.zip']:
    with zipfile.ZipFile(ROOT/rel) as z:
        names=z.namelist()
        if len(names)!=len(set(names)): fail('duplicate ZIP entry '+rel)
        if z.testzip() is not None: fail('corrupt ZIP '+rel)
        for name in names:
            pp=Path(name)
            if pp.is_absolute() or '..' in pp.parts: fail('unsafe ZIP path '+name)
print(f'PASS validate_artifact_structure JSON={json_count} CSV={csv_count} Markdown={md_count} Python={py_count} ZIP=2')
