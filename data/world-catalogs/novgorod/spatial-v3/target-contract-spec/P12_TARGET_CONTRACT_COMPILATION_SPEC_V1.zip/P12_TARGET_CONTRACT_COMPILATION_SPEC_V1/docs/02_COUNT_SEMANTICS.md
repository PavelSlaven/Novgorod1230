# Семантика количеств

## Source counts

| Count | Значение |
|---:|---|
| 32 | созданные migration host G4 для retained G3 |
| 195 | canonical G5 source records |
| 242 | source hierarchy mappings в legacy graph |
| 358 | bidirectional physical source pairs |
| 600 | 242 hierarchy + 358 physical source mappings |
| 716 | два source directions для каждой из 358 physical pairs |
| 195 | scene profiles и single candidates |

## Target logical projections

Source count не равен target row count. Допустимы только следующие утверждения:

- 227 canonical node proposals = 32 G4 + 195 G5.
- 454 directed canonical-G5 connection binding requests = 227 intra-G4 source pairs × 2.
- 86 directed world-route requests = 43 cross-G4 source pairs × 2.
- 32 non-movement G4 entry bindings = 32 host-entry source pairs; обратное source direction не создаёт вторую entry relation.
- 56 staging context links = 32 corridor-entry + 24 G2 adjacency source pairs.

Число физических SQL rows зависит от branch DDL: version rows, normalized dependency edges, endpoint bindings, route points и segments считаются отдельно. Никакая сумма source counts не объявляется SQL row count без compilation manifest.
