CREATE TABLE IF NOT EXISTS map_layouts (
  id TEXT PRIMARY KEY,
  parent_node_id TEXT NOT NULL,
  scale_level TEXT NOT NULL CHECK (scale_level IN ('G1','G2','G3','G4')),
  coordinate_space TEXT NOT NULL DEFAULT 'normalized_square',
  layout_profile TEXT NOT NULL,
  layout_version INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft','geometry_failed','geometry_validated','needs_semantic_review','approved','rejected')),
  source_revision TEXT,
  quality_report JSONB NOT NULL DEFAULT '{}'::jsonb,
  semantic_review JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(parent_node_id, scale_level, layout_version)
);
CREATE TABLE IF NOT EXISTS map_node_positions (
  layout_id TEXT NOT NULL REFERENCES map_layouts(id) ON DELETE CASCADE,
  node_id TEXT NOT NULL,
  x_norm NUMERIC NOT NULL CHECK (x_norm BETWEEN 0 AND 1),
  y_norm NUMERIC NOT NULL CHECK (y_norm BETWEEN 0 AND 1),
  visual_role TEXT,
  boundary_side TEXT CHECK (boundary_side IS NULL OR boundary_side IN ('north','east','south','west')),
  icon_key TEXT,
  label_priority INTEGER CHECK (label_priority IS NULL OR label_priority BETWEEN 1 AND 3),
  locked BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY(layout_id,node_id)
);
CREATE TABLE IF NOT EXISTS map_edge_geometry (
  layout_id TEXT NOT NULL REFERENCES map_layouts(id) ON DELETE CASCADE,
  visual_edge_id TEXT NOT NULL,
  bend_points JSONB NOT NULL DEFAULT '[]'::jsonb,
  style_key TEXT,
  marker_key TEXT,
  z_index INTEGER NOT NULL DEFAULT 0,
  locked BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY(layout_id,visual_edge_id)
);
CREATE TABLE IF NOT EXISTS map_layout_constraints (
  id TEXT PRIMARY KEY,
  layout_id TEXT NOT NULL REFERENCES map_layouts(id) ON DELETE CASCADE,
  constraint_type TEXT NOT NULL,
  source_node_id TEXT,
  target_node_id TEXT,
  axis TEXT,
  side TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'approved'
);
CREATE TABLE IF NOT EXISTS map_layout_reviews (
  id TEXT PRIMARY KEY,
  layout_id TEXT NOT NULL REFERENCES map_layouts(id) ON DELETE CASCADE,
  reviewer_type TEXT NOT NULL CHECK (reviewer_type IN ('human','llm','policy')),
  reviewer_id TEXT NOT NULL,
  decision TEXT NOT NULL CHECK (decision IN ('approved','rejected')),
  notes TEXT,
  source_version TEXT,
  reviewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS map_icon_families (
  icon_key TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  svg_symbol_id TEXT,
  allowed_overlays JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'approved'
);
CREATE TABLE IF NOT EXISTS map_node_icon_rules (
  id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL,
  source_value TEXT NOT NULL,
  icon_key TEXT NOT NULL REFERENCES map_icon_families(icon_key),
  priority INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'approved'
);
CREATE TABLE IF NOT EXISTS map_edge_styles (
  style_key TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  renderer_config JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'approved'
);
