# Executed standalone checks

The following commands were actually run in this environment and passed:

```text
python scripts/validate_package.py
python scripts/validate_target_projection.py
python scripts/verify_source_reproduction.py
python scripts/verify_scene_endpoint_slots.py
python scripts/verify_direction_ledger.py
python scripts/verify_workbooks.py
python scripts/validate_json_schemas.py
python scripts/validate_artifact_structure.py
python scripts/verify_repository_branch_binding.py --expect-blocked
python scripts/semantic_audit.py
```

`python scripts/run_all_checks.py` also passed against the finalized manifest. The deterministic ZIP was extracted into a clean directory and the same complete runner passed from the extracted tree.

No repository-local npm, PostgreSQL, Graphify, browser E2E, independent critic, signature or production deployment check is claimed here.
