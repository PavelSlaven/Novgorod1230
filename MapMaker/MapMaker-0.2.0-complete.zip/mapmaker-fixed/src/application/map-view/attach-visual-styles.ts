import type { PositionedGraph } from "./internal.js";

const allowedIcons = new Set([
  "generic_place", "entrance", "exit", "road", "street", "yard", "dwelling", "market", "church",
  "monastery", "authority", "guard", "workshop", "storage", "stable", "livestock", "field", "garden",
  "forest", "hunting", "camp", "dock", "riverbank", "bridge", "ford", "ferry", "ruin", "hidden_passage"
]);

export function attachVisualStyles(graph: PositionedGraph): PositionedGraph {
  return {
    ...graph,
    positionedNodes: graph.positionedNodes.map((node) => ({ ...node, iconKey: allowedIcons.has(node.iconKey) ? node.iconKey : "generic_place" }))
  };
}
