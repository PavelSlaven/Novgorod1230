import json, pathlib, sys
root=pathlib.Path(__file__).parent
v=json.load(open(root/'09-validation/structural-validation.json',encoding='utf-8'))
c=json.load(open(root/'09-validation/gameplay-completeness-audit.json',encoding='utf-8'))
assert v['result']=='PASS', v
assert c['result']=='PASS', c
p=json.load(open(root/'gn_nov_g1_xp017_yp026.rebuild-002.package.json',encoding='utf-8'))
assert len(p['g2_zones'])>=12
assert len(p['g3_places'])>=10
assert min(sum(1 for x in p['g4_locations'] if x['parent_node_id']==g['id']) for g in p['g3_places'])>=5
print('PASS',len(p['g2_zones']),len(p['g3_places']),len(p['g4_locations']),len(p['graph_nodes']),len(p['graph_edges']))
