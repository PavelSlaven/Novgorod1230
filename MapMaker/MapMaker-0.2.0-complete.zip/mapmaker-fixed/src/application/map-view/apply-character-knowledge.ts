import type { EdgeKnowledgeState, NodeKnowledgeState } from "../../domain/types.js";
import type { OverlayGraph, VisibleEdge, VisibleGraph, VisibleNode } from "./internal.js";

const exactNodeStates = new Set(["visited", "seen", "known_exactly"]);
const exactEdgeStates = new Set(["traversed", "known_exactly"]);

function nodePresentation(state: import("../../domain/types.js").InternalNodeKnowledgeState, presented?: NodeKnowledgeState): NodeKnowledgeState {
  if (state === "false_belief") return presented ?? "known_roughly";
  return state;
}

function edgePresentation(state: import("../../domain/types.js").InternalEdgeKnowledgeState, presented?: EdgeKnowledgeState): EdgeKnowledgeState {
  if (state === "false_belief") return presented ?? "known_roughly";
  return state;
}

export function applyCharacterKnowledge(graph: OverlayGraph): VisibleGraph {
  const canonicalById = new Map(graph.nodes.map((node) => [node.id, node]));
  const nodeKnowledgeById = new Map(graph.nodeKnowledge.map((item) => [item.nodeId, item]));
  const visibleNodes: VisibleNode[] = [];
  const publicNodeIdByCanonicalId = new Map<string, string>();
  const usedPublicIds = new Set<string>();

  for (const [nodeId, knowledge] of nodeKnowledgeById) {
    if (!canonicalById.has(nodeId)) continue;
    if (usedPublicIds.has(knowledge.publicId)) throw new Error(`duplicate_public_node_id:${knowledge.publicId}`);
    const presentation = nodePresentation(knowledge.state, knowledge.presentationState);
    if (!exactNodeStates.has(knowledge.state) && !knowledge.displayPosition) {
      throw new Error(`approximate_knowledge_missing_display_position:${nodeId}`);
    }
    usedPublicIds.add(knowledge.publicId);
    publicNodeIdByCanonicalId.set(nodeId, knowledge.publicId);
    visibleNodes.push({
      canonicalId: nodeId,
      publicId: knowledge.publicId,
      title: knowledge.displayTitle,
      description: knowledge.displayDescription,
      iconKey: knowledge.displayIconKey,
      knowledgeState: presentation,
      displayPosition: knowledge.displayPosition,
      current: nodeId === graph.request.currentNodeId,
      hasKnownChildren: knowledge.knownChildMapAvailable,
      visibleStatus: { ...knowledge.visibleStatus, ...graph.nodeStatusById.get(nodeId) }
    });
  }

  const edgeKnowledgeById = new Map(graph.edgeKnowledge.map((item) => [item.edgeId, item]));
  const visibleEdges: VisibleEdge[] = [];
  for (const edge of graph.edges) {
    if (edge.edgeType === "contains") continue;
    const knowledge = edgeKnowledgeById.get(edge.id);
    if (!knowledge) continue;
    if (!publicNodeIdByCanonicalId.has(edge.source) || !publicNodeIdByCanonicalId.has(edge.target)) continue;
    if (!exactEdgeStates.has(knowledge.state) && knowledge.displayType === edge.edgeType) {
      throw new Error(`approximate_edge_reveals_canonical_type:${edge.id}`);
    }
    const overlay = graph.edgeStateById.get(edge.id);
    visibleEdges.push({
      canonicalId: edge.id,
      reverseCanonicalId: edge.reverseEdgeId,
      publicId: knowledge.publicId,
      sourceCanonicalId: edge.source,
      targetCanonicalId: edge.target,
      displayType: knowledge.displayType,
      knowledgeState: edgePresentation(knowledge.state, knowledge.presentationState),
      traversalState: overlay?.traversalState ?? knowledge.traversalState,
      knownSummary: overlay?.knownSummary ?? knowledge.knownSummary
    });
  }

  return { ...graph, visibleNodes, visibleEdges, publicNodeIdByCanonicalId };
}
