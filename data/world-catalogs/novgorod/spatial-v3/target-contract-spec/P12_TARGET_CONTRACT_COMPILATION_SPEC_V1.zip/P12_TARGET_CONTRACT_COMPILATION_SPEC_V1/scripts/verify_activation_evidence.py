from __future__ import annotations
import argparse, base64, copy, hashlib, json, re, sys
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

HEX64 = re.compile(r'^[0-9a-f]{64}$')
SHA40 = re.compile(r'^[0-9a-f]{40}$')

def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def block(message):
    print('BLOCKED:', message)
    raise SystemExit(2)
def canonical_bytes(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
def unsigned_payload(obj, signature_field):
    data = copy.deepcopy(obj)
    data.pop(signature_field, None)
    return canonical_bytes(data)
def verify_signature(obj, field, key_record, expected_role):
    sig = obj.get(field, {})
    if sig.get('algorithm') != 'ed25519': block(f'{field}: unsupported algorithm')
    if sig.get('key_id') != key_record['key_id']: block(f'{field}: key mismatch')
    if key_record.get('role') != expected_role or key_record.get('status') != 'active': block(f'{field}: key role/status not trusted')
    try:
        public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(key_record['public_key_base64'], validate=True))
        signature = base64.b64decode(sig['signature_base64'], validate=True)
        public_key.verify(signature, unsigned_payload(obj, field))
    except (KeyError, ValueError, InvalidSignature) as exc:
        block(f'{field}: cryptographic verification failed')

def get_key(store, key_id):
    matches = [k for k in store.get('keys', []) if k.get('key_id') == key_id]
    if len(matches) != 1: block(f'trust store does not contain exactly one active key {key_id!r}')
    return matches[0]

parser = argparse.ArgumentParser()
parser.add_argument('p27')
parser.add_argument('fresh')
parser.add_argument('decision')
parser.add_argument('--trust-store', required=True)
args = parser.parse_args()
p27, fresh, decision, store = map(load, [args.p27, args.fresh, args.decision, args.trust_store])
if store.get('status') != 'active_trust_store': block('trust store is not active')
if p27.get('status') != 'signed_evidence': block('P27 is not signed evidence')
if fresh.get('status') != 'signed_evidence': block('fresh checkout is not signed evidence')
if decision.get('status') != 'signed_decision': block('activation is not a signed decision')
sha = p27.get('commit_sha', '')
if not SHA40.fullmatch(sha): block('invalid commit SHA')
if fresh.get('commit_sha') != sha or decision.get('commit_sha') != sha: block('commit mismatch')
for obj, keys in [
    (p27, ['audit_payload_sha256', 'changed_file_manifest_sha256', 'test_result_manifest_sha256']),
    (fresh, ['evidence_manifest_sha256']),
    (decision, ['source_package_sha256', 'compiled_bundle_sha256', 'p27_evidence_sha256', 'fresh_checkout_evidence_sha256']),
]:
    for key in keys:
        if not HEX64.fullmatch(obj.get(key, '')): block('invalid digest ' + key)
if p27.get('critic_verdict') not in ('PASS', 'PASS WITH NOTES'): block('inadmissible critic verdict')
if fresh.get('initial_git_status') != 'clean' or fresh.get('final_git_status') != 'clean' or fresh.get('result') != 'PASS': block('fresh checkout not clean/pass')
if not decision.get('mandatory_gates') or not all(decision['mandatory_gates'].values()): block('mandatory gate false or absent')
if decision.get('decision') != 'activate': block('decision is not activate')

p27_sig = p27.get('signature', {})
fresh_sig = fresh.get('signature', {})
decision_sig = decision.get('signed_by', {})
verify_signature(p27, 'signature', get_key(store, p27_sig.get('key_id')), 'p27_critic')
verify_signature(fresh, 'signature', get_key(store, fresh_sig.get('key_id')), 'fresh_checkout_attestor')
verify_signature(decision, 'signed_by', get_key(store, decision_sig.get('key_id')), 'p28_release_authority')

# Evidence-file digest binding is over exact bytes, not reserialized JSON.
if hashlib.sha256(Path(args.p27).read_bytes()).hexdigest() != decision['p27_evidence_sha256']:
    block('P27 evidence file digest mismatch')
if hashlib.sha256(Path(args.fresh).read_bytes()).hexdigest() != decision['fresh_checkout_evidence_sha256']:
    block('fresh-checkout evidence file digest mismatch')
print('PASS: structural, commit-binding, digest-binding and Ed25519 trust-root verification succeeded')
