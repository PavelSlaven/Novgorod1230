# P28 atomic activation gate

## Commit and deployment boundary

`activation_candidate_commit` is one exact Git commit that already contains the complete v3 contract/DDL/compiler implementation and the production-composition switch, but has not yet been deployed to production. P27, fresh-checkout evidence and the P28 decision all bind to this same commit SHA. Preparing or merging the commit is not equivalent to deploying it.

## State machine

```text
source_approved
→ target_compiled
→ activation_candidate_commit_prepared_not_deployed
→ isolated_db_verified_for_exact_commit
→ P27_signed_for_exact_commit
→ fresh_checkout_verified_for_exact_commit
→ P28_signed_for_exact_commit
→ deploy_exact_commit_atomically
→ post_deploy_smoke_verified
```

Transitions are strictly sequential. Any missing, stale or different-commit artifact returns `blocked`. Evidence from another commit cannot be inherited.

## Atomic activation commit

The exact candidate commit must simultaneously:

- promote target docs/ADR only after their required implementation exists;
- switch default production composition to v3;
- require schema version 3 for newly created parties;
- remove v2 from the default writer composition;
- retain v2 only in explicit migration, compatible rollback or read-only paths;
- enable startup no-mixing assertions;
- contain rollback instructions and deployment preconditions.

The commit remains non-production until the signed P28 decision authorizes deployment of that exact SHA.

## Deployment and post-deployment verification

Deployment selects only the signed `activation_candidate_commit`. It must not create an unreviewed follow-up patch. After deployment, runtime smoke/readiness checks verify the deployed SHA and composition. A failed smoke check triggers the approved rollback procedure; it does not authorize ad-hoc repair in production.

## Rollback

Rollback is an explicit signed operation to a previously approved compatible deployment target. It does not perform dual writes and does not rematerialize parties. New v3 parties are never opened by the v2 writer. A v2 rollback path is admissible only for save revisions whose compatibility was established before activation; otherwise service remains blocked until a v3-compatible corrective release is approved.
