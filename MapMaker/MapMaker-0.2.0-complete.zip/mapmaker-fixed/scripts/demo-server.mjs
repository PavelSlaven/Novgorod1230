import { createReadStream } from "node:fs";
import { readFile, stat } from "node:fs/promises";
import { createServer } from "node:http";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { buildMapView } from "../dist/node.js";
import { selectStaticRoot } from "./static-security.mjs";

const moduleRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const levels = new Set(["G1", "G2", "G3", "G4"]);
const types = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".map": "application/json; charset=utf-8", ".svg": "image/svg+xml"
};

function devIcon(nodeType) {
  const rules = [[/church|chapel|temple|погост/i,"church"],[/monastery/i,"monastery"],[/market|trade/i,"market"],[/yard/i,"yard"],[/house|dwelling/i,"dwelling"],[/workshop|craft/i,"workshop"],[/warehouse|storage|barn/i,"storage"],[/stable|horse/i,"stable"],[/forest|grove/i,"forest"],[/field|meadow/i,"field"],[/garden/i,"garden"],[/dock|pier|harbor/i,"dock"],[/river|bank/i,"riverbank"],[/bridge/i,"bridge"],[/gate|entrance/i,"entrance"],[/camp|hunt/i,"camp"],[/ruin/i,"ruin"]];
  return rules.find(([pattern]) => pattern.test(nodeType))?.[1] ?? "generic_place";
}

export function startDemoServer(options = {}) {
  const root = path.resolve(options.root ?? moduleRoot);
  const generatedRoot = path.resolve(options.generatedRoot ?? process.env.MAPMAKER_GENERATED_ROOT ?? path.join(root, "private-generated", "server"));
  const host = options.host ?? process.env.MAPMAKER_HOST ?? "127.0.0.1";
  const port = Number(options.port ?? process.env.MAPMAKER_PORT ?? 4179);
  const staticRoots = ["examples", "dist"];
  let manifestCache;

  async function loadManifest() {
    if (!manifestCache) {
      const manifest = JSON.parse(await readFile(path.join(generatedRoot, "manifest.json"), "utf8"));
      const layouts = manifest.layouts.map((item) => ({ ...item, key: `${item.level}:${item.parentNodeId}` }));
      manifestCache = {
        public: { formatVersion: manifest.formatVersion, generatedAt: manifest.generatedAt,
          layouts: layouts.map(({ key, file, qualityReport, ...item }) => ({ ...item, qualityReport })) },
        byKey: new Map(layouts.map((item) => [item.key, item]))
      };
    }
    return manifestCache;
  }

  function sendJson(response, status, value) {
    response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
    response.end(JSON.stringify(value));
  }

  async function serveView(url, response) {
    const level = url.searchParams.get("level");
    const parentNodeId = url.searchParams.get("parentNodeId");
    if (!level || !levels.has(level) || !parentNodeId) { sendJson(response, 400, { error: "invalid_map_request" }); return; }
    try {
      const manifest = await loadManifest();
      const item = manifest.byKey.get(`${level}:${parentNodeId}`);
      if (!item) { sendJson(response, 404, { error: "local_map_not_found" }); return; }
      const file = path.resolve(generatedRoot, item.file);
      const relative = path.relative(generatedRoot, file);
      if (relative.startsWith("..") || path.isAbsolute(relative)) throw new Error("unsafe_manifest_path");
      const chunk = JSON.parse(await readFile(file, "utf8"));
      const levelNumber = Number(level.slice(1));
      const nextLevel = levelNumber < 4 ? `G${levelNumber + 1}` : undefined;
      if (chunk.nodes.length === 0) { sendJson(response, 422, { error: "empty_local_map" }); return; }
      const currentNodeId = url.searchParams.get("currentNodeId");
      const current = chunk.nodes.some((node) => node.id === currentNodeId) ? currentNodeId : chunk.nodes[0].id;
      const boundaryEdgeKnowledge = (chunk.boundaryExits ?? []).flatMap((exit) => exit.edgeIds.map((edgeId) => ({
        edgeId, publicId: edgeId, state: "known_exactly", displayType: exit.edgeType, displayLabel: "Выход из локальной карты",
        traversalState: "open", knownTargetMapAvailable: Boolean(nextLevel && manifest.byKey.has(`${nextLevel}:${exit.externalNodeId}`))
      })));
      const view = buildMapView({
        parentNodeId, level, nodes: chunk.nodes, edges: chunk.edges, boundaryExits: chunk.boundaryExits,
        layout: chunk.layout, currentNodeId: current, allowUnapprovedLayout: true,
        nodeKnowledge: chunk.nodes.map((node) => ({
          nodeId: node.id, publicId: node.id, state: node.id === current ? "visited" : "known_exactly",
          displayTitle: node.title, displayIconKey: devIcon(node.nodeType), knownChildMapAvailable: Boolean(nextLevel && manifest.byKey.has(`${nextLevel}:${node.id}`))
        })),
        edgeKnowledge: [
          ...chunk.edges.map((edge) => ({ edgeId: edge.id, publicId: edge.id, state: "known_exactly", displayType: edge.edgeType, traversalState: "open" })),
          ...boundaryEdgeKnowledge
        ],
        breadcrumbs: []
      });
      sendJson(response, 200, view);
    } catch (error) {
      sendJson(response, 500, { error: "dev_view_failed", message: error instanceof Error ? error.message : String(error) });
    }
  }

  async function serveStatic(pathname, response) {
    if (pathname === "/") pathname = "/examples/index.html";
    const file = selectStaticRoot(root, pathname, staticRoots);
    if (!file) { response.writeHead(404).end("Not found"); return; }
    try {
      const info = await stat(file);
      if (!info.isFile()) throw new Error("not_file");
      response.writeHead(200, { "content-type": types[path.extname(file)] ?? "application/octet-stream", "x-content-type-options": "nosniff" });
      createReadStream(file).pipe(response);
    } catch { response.writeHead(404).end("Not found"); }
  }

  const server = createServer(async (request, response) => {
    const url = new URL(request.url ?? "/", "http://localhost");
    if (url.pathname === "/dev-api/manifest") {
      try { sendJson(response, 200, (await loadManifest()).public); }
      catch { sendJson(response, 503, { error: "map_data_missing", hint: "Сначала выполните npm run compile:novgorod" }); }
      return;
    }
    if (url.pathname === "/dev-api/view") { await serveView(url, response); return; }
    await serveStatic(url.pathname, response);
  });
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => resolve({ server, address: server.address(), generatedRoot }));
  });
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const { address } = await startDemoServer();
  const actualPort = typeof address === "object" && address ? address.port : 4179;
  console.log(`MapMaker G1-G4 explorer: http://127.0.0.1:${actualPort}`);
  console.log("DEV ONLY: canonical chunks remain server-side; layout approval status is not modified.");
}
