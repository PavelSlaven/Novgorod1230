# Private generated data

Каталог `server/` не является web static root. Его содержимое читает только серверный map-view pipeline.

- `server/manifest.json` — индекс 1 141 локальной карты.
- `server/AUDIT_REPORT.json` — итог quality gate.
- `server/G1..G4` — закрытые канонические чанки.

Не публиковать этот каталог через CDN, Express static, nginx alias или иной статический сервер.
