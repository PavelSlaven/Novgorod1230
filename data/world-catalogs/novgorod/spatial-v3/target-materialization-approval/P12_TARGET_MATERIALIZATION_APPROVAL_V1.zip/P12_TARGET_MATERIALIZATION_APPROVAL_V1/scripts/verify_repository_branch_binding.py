from pathlib import Path
import argparse,json,re
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--binding',default='templates/repository-branch-binding.template.json')
p.add_argument('--expect-blocked',action='store_true')
a=p.parse_args()
path=Path(a.binding)
if not path.is_absolute(): path=ROOT/path
obj=json.loads(path.read_text(encoding='utf-8'))
schema=json.loads((ROOT/'schemas/repository-branch-binding.schema.json').read_text(encoding='utf-8'))
errs=list(Draft202012Validator(schema).iter_errors(obj))
if errs: print('FAIL branch binding schema:',errs[0].message); raise SystemExit(1)
if a.expect_blocked:
    if obj['status']!='BLOCKED_UNBOUND' or any(obj[k] is not None for k in ['pr_number','branch_name','head_sha','approval_bundle_sha256']):
        print('FAIL expected fail-closed unbound template'); raise SystemExit(1)
    print('PASS verify_repository_branch_binding negative template is fail-closed'); raise SystemExit(0)
if obj['status']!='BOUND_FOR_REPOSITORY_APPLY': print('BLOCKED repository branch binding is not active'); raise SystemExit(2)
if not obj['branch_name'] or not re.fullmatch(r'[0-9a-f]{40}',obj['head_sha'] or '') or not re.fullmatch(r'[0-9a-f]{64}',obj['approval_bundle_sha256'] or ''):
    print('BLOCKED incomplete exact branch binding'); raise SystemExit(2)
print('PASS repository branch binding structure; online ancestry and path checks remain repository-owned gates')
