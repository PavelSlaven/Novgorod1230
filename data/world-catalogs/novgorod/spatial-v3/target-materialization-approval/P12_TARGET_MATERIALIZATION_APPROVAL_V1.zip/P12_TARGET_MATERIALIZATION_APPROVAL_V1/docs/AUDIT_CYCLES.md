# Audit cycles

## Cycle 1

Findings: direct approved physical pairs were being confused with staging context paths; branch content versions and a future activation commit were conflated; null capacity semantics were implicit.

Corrections: approved `direct_route_source_binding`, separated semantic content pins from the activation commit, and added explicit no-static-limit capacity semantics.

## Cycle 2

Findings: 716 source directions risked being reported as 716 G4 exits; gameplay minutes could be mistaken for historical measurements; reciprocal routes and bindings needed formal checks.

Corrections: retained the typed 454/86/176 classification, added calibration disclaimers and reciprocal validation.

## Cycle 3

Findings: P12 data-gap closure and P28 production authority were insufficiently separated.

Corrections: made P12 closure conditional on actual isolated materialization evidence and kept P28/production explicitly blocked.

## Cycle 4

Findings: compiler-trace JSON was not an exact target-contract row set; target route points, exits, endpoints and segments used trace fields rather than formal contract fields.

Corrections: added the normalized `target/` projection and made it the only authorized DDL input.

## Cycle 5

Findings: `water_land_transition` used action cost although `world_route_segment` requires a time profile; every segment also lacked its mandatory spatial-context row.

Corrections: approved a 15-minute shore-transfer gameplay profile and generated exactly one G0/G1 weather-scoped spatial context per segment.

## Cycle 6

Findings: existing geometric orientation contracts require azimuth, but the source contains only ordered endpoints. Supplying numeric bearings would invent facts.

Corrections: approved amendment v1.2.0 with a typed non-geometric topological orientation branch and explicit prohibition of compass inference.

## Cycle 7

Findings: exact stable-ID version dependencies and G4 traversal relation sets were implicit.

Corrections: added normalized authoring dependency edges, 32 traversal profiles and 86 ordered context/exit bindings.

## Cycle 8 — typed ledger and package consistency

Findings:

1. `runtime_movement` and `target_refs` in the JSON direction ledger used CSV-shaped strings.
2. DDL authorization duplicated four preconditions.
3. README and gap evidence contained stale v1.1 / pin-count wording.

Corrections:

- JSON ledger now uses Boolean movement semantics, arrays of target references and nullable gap codes.
- Duplicate preconditions were removed without weakening any gate.
- All narrative and evidence references now use amendment v1.2.0 and the exact 50-pin graph.

Result: corrected; re-audit required.

## Cycle 9 — profile narrative and amendment de-duplication

Findings:

1. The connection-profile narrative still described `water_land_transition` as one action after the target contract had been corrected to a 15-minute time profile.
2. Four amendment invariants were duplicated.

Corrections:

- The narrative now matches the approved shore-transfer time contract and its dynamic checks.
- Duplicate invariants were removed without changing contract meaning.

Result: corrected; final re-audit required.


## Cycle 10 — repository fact boundary

Findings:

1. The owner reported local integration, but the observable canonical `main` and open travel PR did not expose the accepted P12 paths.
2. Assigning a branch name or HEAD from inference would fabricate repository evidence.

Corrections:

- Added a dated repository observation and a fail-closed branch-binding template.
- Repository apply now requires a pushed existing task branch, exact PR number, exact 40-hex HEAD and final approval-bundle SHA-256.
- Standalone authoring approval and isolated compilation remain valid; repository apply and activation remain blocked while unbound.

Result: corrected.

## Final cycle

Internal semantic, structural, count, schema, source-reproduction, workbook, direction-ledger and trust-boundary findings: **0**.

Result: **PASS** for the standalone approval bundle. This is not the mandatory independent repository critic result and is not production activation evidence.
