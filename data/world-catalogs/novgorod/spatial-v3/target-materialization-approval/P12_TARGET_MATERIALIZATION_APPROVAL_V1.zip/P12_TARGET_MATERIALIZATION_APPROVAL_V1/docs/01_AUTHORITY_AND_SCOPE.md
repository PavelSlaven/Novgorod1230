# Authority and scope

The accepted source ZIP and target-contract specification are immutable inputs. Their SHA-256 values are pinned in `inputs/input-digests.json`.

This package is an editorial and technical approval for target authoring contracts. It may be integrated only into the existing single task branch/PR. It does not invent an integration branch name or commit SHA.

The observed canonical `main` remained `9f2a8c1477793e3baac376d558a64b1b2272cc4a`. Therefore the exact activation commit is intentionally absent and remains a P28 blocker, not a P12 authoring gap.
