# Endpoint/profile authoring specification

## Почему профили не выводятся автоматически

Source edge содержит только endpoint IDs, edge type, evidence status и seasonal note. Он не содержит factual azimuth, exact duration, movement-method cost, environment profile, recheck policy, capacity, risk profile или availability condition set. Название, визуальный layout и правдоподобие не заменяют эти данные.

## Authoring unit

Профиль утверждается для точного сочетания:

```text
target scope + source edge type + environment regime + orientation regime + cost regime
```

Один profile может использоваться несколькими bindings только при доказанной механической эквивалентности. Историческая или природная похожесть сама по себе недостаточна.

## Обязательные решения

1. `passage_or_route_kind_id`.
2. `transition_environment_profile_ref`.
3. `movement_orientation_profile_ref` с factual frame/progress points.
4. `cost_kind=action|time`.
5. Для action — `action_units`; для time — method, cost profile, `base_minutes`, recheck policy.
6. Optional capacity только при подтверждённом механическом лимите.
7. Risk и availability profile либо явный approved null semantics.
8. Provenance, status, version и digest.

Рабочая форма: `templates/endpoint-profile-authoring.csv`. Все незаполненные строки являются hard gaps, а не разрешением использовать default.
