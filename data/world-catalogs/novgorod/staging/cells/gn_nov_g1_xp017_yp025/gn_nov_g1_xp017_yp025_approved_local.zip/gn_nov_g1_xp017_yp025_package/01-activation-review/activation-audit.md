# Activation audit: gn_nov_g1_xp017_yp025

Result: **PASS WITH NOTES**.

The cell remains active solely as a broad lower-Northern-Dvina corridor cell. No local medieval settlement, church, monastery, fortification, estate, exact landing or direct administration is asserted. The approved corridor enters from `gn_nov_g1_xp018_yp025` and leaves north toward `gn_nov_g1_xp017_yp026`.
