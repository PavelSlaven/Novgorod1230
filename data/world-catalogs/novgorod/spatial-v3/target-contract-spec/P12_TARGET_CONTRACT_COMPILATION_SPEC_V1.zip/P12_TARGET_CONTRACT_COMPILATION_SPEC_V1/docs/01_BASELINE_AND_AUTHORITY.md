# Baseline, authority и ограничения

## Authority order

1. `code_driven_world_materialization_architecture.md` — граница code/LLM и fail-closed materialization.
2. Target spatial standard — logical contracts и invariants.
3. Исполняемый branch DDL/JSON Schemas — физическая проекция после их фактического чтения.
4. P12 source approval ZIP — утверждённый source-level input, но не target-ready bundle.

## Canonical state

GitHub `main` проверен на commit `9f2a8c1477793e3baac376d558a64b1b2272cc4a`. На этом commit невозможно подтвердить описанную пользователем интеграцию P12. Пакет поэтому не фиксирует branch table names, migration numbers или integration commit, которых нет в доступном canonical state.

## Repository Intelligence

Локальный checkout, нормативный RAG CLI и fresh Graphify graph в этой среде недоступны. Это не мешает созданию отдельного specification archive, но блокирует утверждение repository integration, generated artifacts, full tests и P28 release readiness.

## Запреты

- Не использовать Drive snapshot как canonical branch state.
- Не считать source package target contract compilation.
- Не заполнять orientation, time, movement method, risk или route chain эвристикой.
- Не создавать assistant-authored signature.
- Не менять production v2 до атомарного P28 decision.
