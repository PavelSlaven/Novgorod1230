# Topological orientation amendment

The accepted source establishes directed physical endpoint pairs but does not establish compass bearings, survey geometry or a reliable local reference frame. Numeric azimuth would therefore be an invented fact.

Amendment v1.2.0 adds a typed topological orientation branch. It defines direction by exact ordered endpoints and never by layout coordinates, titles, nearest geometry or inferred upstream/downstream semantics. The reverse is a separately approved reciprocal binding or route.

DDL and DTO validation must represent geometric and topological orientation as an explicit tagged union. A topological profile cannot populate numeric azimuth columns and cannot be silently converted to a geometric profile.
