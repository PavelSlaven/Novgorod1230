import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright-core";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("browser renders bend points, marker layer, knowledge styles and keyboard navigation", async (t) => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] });
  t.after(() => browser.close());
  const page = await browser.newPage({ viewport: { width: 1100, height: 850 } });
  await page.setContent('<!doctype html><html><body><div id="map" style="width:760px;height:760px"></div></body></html>');
  await page.addStyleTag({ path: path.join(root, "dist/styles/map-maker.css") });
  await page.addScriptTag({ path: path.join(root, "dist/browser-harness.js") });
  await page.evaluate(() => window.renderMapFixture());
  await page.waitForFunction(() => window.fixtureReady === true);
  assert.ok(await page.locator(".mm-graph canvas").count());
  await page.waitForSelector(".mm-marker-bridge");
  assert.equal(await page.locator(".mm-marker-bridge").count(), 1);
  assert.ok(await page.locator(".mm-keyboard-list button").count() >= 3);
  assert.equal(await page.evaluate(() => window.knowledgeStyleApplied), true);
  await page.locator(".mm-keyboard summary").click();
  await page.locator(".mm-keyboard-list button").first().focus();
  assert.equal(await page.evaluate(() => document.activeElement?.tagName), "BUTTON");
});
