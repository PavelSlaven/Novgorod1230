from pathlib import Path
import csv,hashlib,io,json,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def fail(m): print('FAIL reproduction:',m); raise SystemExit(1)
def read_nested_spec():
    z=zipfile.ZipFile(ROOT/'inputs/P12_TARGET_CONTRACT_COMPILATION_SPEC_V1.zip')
    prefix=[n.rsplit('/data/source-direction-ledger.csv',1)[0] for n in z.namelist() if n.endswith('/data/source-direction-ledger.csv')][0]
    dirs=list(csv.DictReader(io.StringIO(z.read(prefix+'/data/source-direction-ledger.csv').decode('utf-8-sig'))))
    nodes=list(csv.DictReader(io.StringIO(z.read(prefix+'/data/canonical-node-compilation.csv').decode('utf-8-sig'))))
    scenes=list(csv.DictReader(io.StringIO(z.read(prefix+'/data/scene-profile-compilation.csv').decode('utf-8-sig'))))
    return dirs,nodes,scenes
dirs,nodes,scenes=read_nested_spec()
tnodes=load('target/canonical-spatial-nodes.json')['records']
tscenes=load('target/scene-materialization-profiles.json')['records']
ledger=load('data/direction-resolution-ledger.json')['records']
if {x['id'] for x in tnodes}!={x['id'] for x in nodes}: fail('canonical node identity drift')
if {x['id'] for x in tscenes}!={x['profile_id'] for x in scenes}: fail('scene profile identity drift')
if {x['direction_id'] for x in ledger}!={x['direction_id'] for x in dirs}: fail('direction identity drift')
if len(dirs)!=716 or len(nodes)!=227 or len(scenes)!=195: fail('immutable input counts')
print('PASS verify_source_reproduction 716/227/195')
