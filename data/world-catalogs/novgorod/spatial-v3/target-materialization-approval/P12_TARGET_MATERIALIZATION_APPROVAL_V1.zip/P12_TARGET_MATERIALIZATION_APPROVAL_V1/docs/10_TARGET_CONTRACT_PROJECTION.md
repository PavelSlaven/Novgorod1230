# Exact target-contract projection

The `target/` directory is the only approved row-level input for target-DDL materialization. Files under `data/` remain approval records, compiler traces and count ledgers unless a document explicitly says otherwise.

The projection implements the base spatial-v3 contracts plus approved amendment `rus.p12_target_contract_amendment@1.2.0`. It contains exact normalized rows for canonical nodes, scene profiles/candidates, connection profiles/bindings, G4 traversal profiles/exits, directed world routes, route points, segments, mandatory segment spatial contexts, endpoint bindings and authoring dependency edges.

No target row contains source-only compilation fields such as `target_status`, `compilation_status`, legacy labels or presentation geometry. Those remain in trace data.

All route segments are time-based. The four `water_land_transition` directions use the approved `movement.shore_transfer@1` and `cost.shore_transfer_15m@1` calibration. This is a gameplay baseline, not a measured medieval duration.

The target projection does not contain SQL table names because the accepted specification does not expose the integration branch DDL. The implementer maps each `contract_name` to the branch-owned normalized table only after exact DDL/schema reconciliation. A mismatch is a hard block.
