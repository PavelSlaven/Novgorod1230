from pathlib import Path
import json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def fail(m): print('FAIL scene slots:',m); raise SystemExit(1)
z=zipfile.ZipFile(ROOT/'inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip')
name=next(n for n in z.namelist() if n.endswith('/data/approved-scene-template-families.json'))
templates=json.loads(z.read(name).decode('utf-8'))['records']
slots={f"{x['id']}@{x['version']}":{s['slot_key'] for s in x['endpoint_slots']} for x in templates}
profiles=load('target/scene-materialization-profiles.json')['records']; candidates=load('target/scene-materialization-candidates.json')['records']
byprofile={f"{x['profile_id']}@{x['profile_version']}":x['scene_template_ref'] for x in candidates}
source_template={x['source_ref']:byprofile[f"{x['id']}@{x['version']}"] for x in profiles}
for tref in source_template.values():
    if tref not in slots or not {'arrival','departure'}<=slots[tref]: fail('template lacks required slots '+tref)
for b in load('target/canonical-g5-connection-bindings.json')['records']:
    for g5,key in [(b['from_canonical_g5_id'],b['from_scene_endpoint_slot_key']),(b['to_canonical_g5_id'],b['to_scene_endpoint_slot_key'])]:
        tref=source_template[f'{g5}@1']
        if key not in slots[tref]: fail('connection slot '+g5+' '+key)
for b in load('target/g4-entry-endpoint-bindings.json')['records']:
    tref=source_template[f"{b['canonical_g5_id']}@1"]
    for key in [b['arrival_scene_endpoint_slot_key'],b['departure_scene_endpoint_slot_key']]:
        if key not in slots[tref]: fail('entry slot '+b['canonical_g5_id']+' '+key)
for b in load('target/world-route-endpoint-bindings.json')['records']:
    tref=source_template[f"{b['canonical_g5_id']}@1"]
    if b['scene_endpoint_slot_key'] not in slots[tref]: fail('route slot '+b['canonical_g5_id'])
print('PASS verify_scene_endpoint_slots 17 templates / 195 G5')
