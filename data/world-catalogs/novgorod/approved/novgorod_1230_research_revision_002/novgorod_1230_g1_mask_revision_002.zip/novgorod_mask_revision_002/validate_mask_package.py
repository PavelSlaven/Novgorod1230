import json, hashlib, re
from pathlib import Path
from collections import defaultdict, deque, Counter

BASE=Path('/mnt/data/novgorod_mask_revision_002')

def load(name): return json.loads((BASE/name).read_text(encoding='utf-8'))
def sha_file(p):
    h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

catalog=load('novgorod_1230_source_catalog.json')
sources={x['source_id']:x for x in catalog['sources']}
claims_doc=load('novgorod_1230_claim_ledger.json')
claims={x['claim_id']:x for x in claims_doc['claims']}
conflicts_doc=load('novgorod_1230_conflict_register.json')
conflicts=conflicts_doc['conflicts']
anchors=load('novgorod_1230_anchor_register.geojson')['features']
corridors=load('novgorod_1230_corridor_register.geojson')['features']
mask=load('novgorod_1230_candidate_g1_mask.json')
cells=mask['cells']
decisions=load('novgorod_1230_g1_decision_ledger.json')['decisions']
transitions=load('novgorod_1230_external_transitions.json')['transitions']
migrations=load('novgorod_1230_id_migration_map.json')['entries']
revision=load('novgorod_1230_research_revision_002.json')
validation=load('novgorod_1230_g1_mask_validation.json')

errors=[]; warnings=[]

def require(cond,msg):
    if not cond: errors.append(msg)

def walk_refs(obj, path='$', out=None):
    if out is None: out=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k=='source_ids' and isinstance(v,list):
                for s in v: out.append((path+'.'+k,s))
            elif k=='source_id' and isinstance(v,str): out.append((path+'.'+k,v))
            walk_refs(v,path+'.'+k,out)
    elif isinstance(obj,list):
        for i,v in enumerate(obj): walk_refs(v,f'{path}[{i}]',out)
    return out

# 1-2 active provenance
active=[c for c in cells if c.get('cell_active')]
require(all(c.get('activation_reasons') for c in active),'active cell without activation_reasons')
require(all(c.get('source_ids') or c.get('reconstruction_method') for c in active),'active cell without source_ids/reconstruction_method')

# 3 cross-artifact source provenance
refs=[]
for name in ['novgorod_1230_claim_ledger.json','novgorod_1230_conflict_register.json','novgorod_1230_anchor_register.geojson','novgorod_1230_corridor_register.geojson','novgorod_1230_candidate_g1_mask.json','novgorod_1230_g1_decision_ledger.json','novgorod_1230_natural_constraints.geojson','novgorod_1230_control_model.geojson','novgorod_1230_ethnocultural_zones.geojson']:
    refs.extend((name,path,s) for path,s in walk_refs(load(name)))
missing_source_refs=[r for r in refs if r[2] not in sources]
require(not missing_source_refs,f'missing source references: {missing_source_refs[:10]}')
require(len(sources)==len(set(sources)),'duplicate source IDs')
require(all(x.get('full_citation') and x.get('source_class') and x.get('limitations') is not None for x in sources.values()),'incomplete source catalog record')

# 4 exact borders
require(all(c.get('exact_historical_boundary_claimed') is False for c in cells),'cell claims exact historical boundary')
require(all(f['properties'].get('exact_historical_boundary_claimed') is False for f in load('novgorod_1230_control_model.geojson')['features']),'control feature claims exact historical boundary')

# 5 modern boundaries
require(revision['grid_coordinate_system']=='regional_square_32km_aeqd_novgorod_anchor','unexpected grid system')
require(all('modern GSHHS technical proxy only' in c.get('land_water_basis','') for c in cells),'unmarked modern shoreline proxy')

# 6 late settlements
require(all(f['properties'].get('coordinate_role')=='modern_or_reconstructed_locator_only' for f in anchors),'anchor coordinate role missing')
require(all(f['properties'].get('date_range',{}).get('from') is not None and f['properties']['date_range']['from']<=1230 for f in anchors),'anchor without pre-1230 dating')
require(not any(k in mask for k in ('g2_zones','g3_places','g4_locations')),'mask contains detailed late settlement entities')

# 7 retrogression
late_method_conflicts=[c for c in conflicts if c['conflict_id']=='CNF_LATE_ADMIN_RETROJECTION']
require(bool(late_method_conflicts) and late_method_conflicts[0]['status']=='resolved_methodologically','late administrative retrojection not documented')

# 8 dated archaeology
arch=[f for f in anchors if f['properties'].get('evidence_status')=='archaeologically_supported']
require(all(f['properties'].get('date_range',{}).get('from') is not None and f['properties'].get('date_range',{}).get('to') is not None for f in arch),'undated archaeological anchor')

# 9 spatial precision
require(all(c.get('spatial_precision') in {'exact_site','local_area','corridor','macrozone','unknown'} for c in cells),'cell missing precision')
require(all(c.get('spatial_precision') in {'exact_site','local_area','corridor','macrozone','unknown'} for c in claims.values()),'claim missing precision')
require(all(f['properties'].get('spatial_precision') in {'exact_site','local_area','corridor','macrozone','unknown'} for f in anchors+corridors),'feature missing precision')

# 10 political basis
require(all(c.get('political_basis_claim_ids') and all(x in claims for x in c['political_basis_claim_ids']) for c in cells),'cell political basis missing or invalid')

# 11 contested
contested=[c for c in cells if c.get('control_status')=='contested']
require(bool(contested),'no contested cells')
require(any(c['conflict_id']=='CNF_IZHORA_VOD_BORDER' for c in conflicts),'Izhora/Vod conflict missing')
require(any(c['conflict_id']=='CNF_KARELIA_CONTROL' for c in conflicts),'Karelia conflict missing')
require(any(c['conflict_id']=='CNF_BELOOZERO_VAGA_JURISDICTION' for c in conflicts),'Beloozero/Vaga conflict missing')

# 12-13 G0 model
external_regions={t['external_region_id'] for t in transitions}
require('region_pskov_land' in external_regions and 'region_beloozero' in external_regions,'Pskov/Beloozero transition missing')
require(all(c['region_id']=='region_novgorod_land' for c in cells),'cell duplicates internal territory as separate G0')
for forbidden in ('region_karelia','region_ladoga_izhoria','region_zavolochye'):
    require(forbidden not in {c['region_id'] for c in cells},f'forbidden duplicate G0 {forbidden}')

# 14 corridor traces connected through cell membership (8-neighbour)
for f in corridors:
    cid=f['id']; coords={(c['global_grid_x'],c['global_grid_y']) for c in cells if cid in c.get('corridor_ids',[])}
    require(bool(coords),f'{cid} has no cells')
    if not coords: continue
    seen={next(iter(coords))}; q=deque(seen)
    while q:
        x,y=q.popleft()
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                if not (dx or dy): continue
                n=(x+dx,y+dy)
                if n in coords and n not in seen: seen.add(n); q.append(n)
    require(seen==coords,f'{cid} disconnected: {len(coords)-len(seen)} cells')

# global non-external connectivity
coords={(c['global_grid_x'],c['global_grid_y']) for c in cells if c['control_status']!='external'}
seen={next(iter(coords))}; q=deque(seen)
while q:
    x,y=q.popleft()
    for dx in (-1,0,1):
        for dy in (-1,0,1):
            if not (dx or dy): continue
            n=(x+dx,y+dy)
            if n in coords and n not in seen: seen.add(n); q.append(n)
require(seen==coords,f'global active mask disconnected: {len(coords)-len(seen)} cells')

# 15 external transitions
required_ext={'EXT_PSKOV','EXT_LIVONIA','EXT_BELOOZERO','EXT_VLADIMIR_SUZDAL','EXT_POLOTSK','EXT_FINNISH_SWEDISH','EXT_ROSTOV_SUZDAL_USTYUG'}
transition_ids={t['transition_id'] for t in transitions}
require(required_ext.issubset(transition_ids),f'missing external transitions {sorted(required_ext-transition_ids)}')
cell_ids={c['id'] for c in cells}
require(all(t['from_g1_id'] in cell_ids for t in transitions),'transition points to missing G1')

# 16 conflicts
require(len(conflicts)>=5 and all(c.get('status') and c.get('resolution') and c.get('source_ids') for c in conflicts),'unresolved conflicts incomplete')

# 17 migration old 70
legacy_migrations=[e for e in migrations if e.get('old_id')]
new_migrations=[e for e in migrations if not e.get('old_id')]
require(len(legacy_migrations)==70,'legacy migration map does not contain 70 preserved cells')
require(all(e.get('status')=='preserved_same_grid_cell' and e.get('old_id')==e.get('new_id') for e in legacy_migrations),'legacy migration status invalid')
legacy_ids={e['old_id'] for e in legacy_migrations}
require(len(legacy_ids)==70,'legacy IDs not unique')

# 18 stable new IDs
new=[c for c in cells if c.get('migration_status')=='new_stable_grid_cell']
pat=re.compile(r'^gn_nov_g1_x[pm]\d{3}_y[pm]\d{3}$')
require(all(pat.match(c['id']) for c in new),'new stable ID format invalid')
require(len({c['id'] for c in cells})==len(cells),'duplicate cell IDs')
require(len({(c['global_grid_x'],c['global_grid_y']) for c in cells})==len(cells),'duplicate grid coordinates')

# 19 historical audit
hist=(BASE/'novgorod_1230_historicity_audit.md').read_text(encoding='utf-8')
require('PASS WITH NOTES' in hist and 'Блокирующих исторических ошибок' in hist,'historical audit not passed')

# 20 structural validation
require(validation.get('result')=='PASS' and not validation.get('errors'),'structural validation report failed')

# 21 critic
crit=(BASE/'novgorod_1230_mask_critic_report.md').read_text(encoding='utf-8')
require('PASS WITH NOTES' in crit and 'Блокирующих дефектов нет' in crit,'critic has blockers or missing pass')

criteria={
'all_active_have_activation_reason':all(c.get('activation_reasons') for c in active),
'all_active_have_sources_or_reconstruction':all(c.get('source_ids') or c.get('reconstruction_method') for c in active),
'no_invented_sources':not missing_source_refs,
'no_unsupported_exact_borders':all(c.get('exact_historical_boundary_claimed') is False for c in cells),
'no_modern_boundary_transfer':all('modern GSHHS technical proxy only' in c.get('land_water_basis','') for c in cells),
'no_automatic_late_settlement_transfer':all(f['properties'].get('coordinate_role')=='modern_or_reconstructed_locator_only' for f in anchors),
'retrogression_justified':bool(late_method_conflicts),
'archaeology_dated':all(f['properties'].get('date_range') for f in arch),
'spatial_precision_complete':all(c.get('spatial_precision') for c in cells),
'political_basis_complete':all(c.get('political_basis_claim_ids') for c in cells),
'contested_zones_preserved':bool(contested),
'pskov_beloozero_separate_g0':{'region_pskov_land','region_beloozero'}.issubset(external_regions),
'internal_territories_not_duplicated_as_g0':all(c['region_id']=='region_novgorod_land' for c in cells),
'major_routes_connected':not any('disconnected' in e for e in errors),
'external_transitions_present':required_ext.issubset(transition_ids),
'unresolved_conflicts_recorded':len(conflicts)>=5,
'old_70_migration_status':len(legacy_migrations)==70 and all(e.get('status')=='preserved_same_grid_cell' for e in legacy_migrations),
'new_ids_stable':all(pat.match(c['id']) for c in new),
'historical_audit_completed':'PASS WITH NOTES' in hist,
'structural_validation_passed':validation.get('result')=='PASS',
'critic_has_no_blockers':'Блокирующих дефектов нет' in crit,
}
report={
 'schema_version':'rus.g1_mask_independent_validation.v1',
 'map_revision_id':revision['map_revision_id'],
 'result':'PASS' if not errors and all(criteria.values()) else 'FAIL',
 'errors':errors,
 'warnings':warnings,
 'metrics':{
  'cells_total':len(cells),'active_non_external':sum(c['control_status']!='external' for c in cells),'external':sum(c['control_status']=='external' for c in cells),
  'legacy_preserved':len(legacy_migrations),'new_cells':len(new),'sources':len(sources),'source_references_checked':len(refs),
  'claims':len(claims),'anchors':len(anchors),'corridors':len(corridors),'conflicts':len(conflicts),'contested_cells':len(contested)
 },
 'criteria':criteria,
 'source_reference_failures':missing_source_refs,
 'method_notes':[
  'This validator recomputes criteria from the package instead of trusting boolean flags in the original validation report.',
  'Modern GSHHS geometry is checked only as a marked technical proxy and is not treated as a 1230 shoreline.',
  'Historical content still requires per-cell source refinement during G1 work.'
 ]
}
(BASE/'novgorod_1230_independent_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
if report['result']!='PASS': raise SystemExit(1)
