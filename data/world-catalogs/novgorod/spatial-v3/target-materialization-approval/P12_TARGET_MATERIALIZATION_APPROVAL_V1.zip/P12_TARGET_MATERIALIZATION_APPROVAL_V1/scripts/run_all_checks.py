from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
checks=[
 'validate_package.py',
 'validate_target_projection.py',
 'verify_source_reproduction.py',
 'verify_scene_endpoint_slots.py',
 'verify_direction_ledger.py',
 'verify_workbooks.py',
 'validate_json_schemas.py',
 'verify_repository_branch_binding.py --expect-blocked',
 'validate_artifact_structure.py',
 'semantic_audit.py',
 'verify_manifest.py',
]
for s in checks:
    parts=s.split()
    r=subprocess.run([sys.executable,str(ROOT/'scripts'/parts[0]),*parts[1:]],cwd=ROOT)
    if r.returncode: raise SystemExit(r.returncode)
print('PASS run_all_checks')
