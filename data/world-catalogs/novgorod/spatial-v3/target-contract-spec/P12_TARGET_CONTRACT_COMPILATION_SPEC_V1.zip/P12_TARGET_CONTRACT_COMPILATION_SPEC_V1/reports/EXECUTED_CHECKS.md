# Executed checks

Only the following commands were actually executed in this archive-building environment.

| Command | Actual exit | Expected exit | Result |
|---|---:|---:|---|
| `python scripts/validate_package.py` | 0 | 0 | PASS |
| `python scripts/validate_json_schemas.py` | 0 | 0 | PASS |
| `python scripts/semantic_audit.py` | 0 | 0 | PASS; open findings 0 |
| `python scripts/verify_reproducibility.py` | 0 | 0 | PASS |
| `python scripts/verify_activation_evidence.py <templates> --trust-store <empty template>` | 2 | 2 | PASS_EXPECTED_BLOCK |
| `python scripts/verify_manifest.py` | 0 | 0 | PASS |
| `python scripts/run_all_checks.py` | 0 | 0 | PASS |

Not executed: repository-local RAG/Graphify, project-wide `npm test`, branch DDL generation, PostgreSQL materialization, independent critic, fresh checkout, cryptographic production evidence verification, deployment or P28 activation.
