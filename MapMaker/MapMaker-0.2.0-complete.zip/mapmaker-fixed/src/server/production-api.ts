import type { BuildMapViewInput } from "../domain/types.js";
import { buildMapView } from "../application/build-map-view.js";

export interface MapApiIdentity { userId: string; partyId: string; characterId: string }
export interface ProductionMapApiDependencies {
  authenticate(request: Request): Promise<MapApiIdentity | null>;
  authorize(input: MapApiIdentity): Promise<boolean>;
  loadMapInput(input: MapApiIdentity & { parentNodeId: string; level: BuildMapViewInput["level"] }): Promise<BuildMapViewInput>;
}

const json = (status: number, value: unknown) => new Response(JSON.stringify(value), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "private, no-store" }
});

export function createProductionMapViewHandler(deps: ProductionMapApiDependencies) {
  return async (request: Request): Promise<Response> => {
    const identity = await deps.authenticate(request);
    if (!identity) return json(401, { error: "authentication_required" });
    const url = new URL(request.url);
    const match = url.pathname.match(/^\/api\/parties\/([^/]+)\/map-view$/);
    if (!match) return json(404, { error: "not_found" });
    const requestedPartyId = decodeURIComponent(match[1]!);
    if (requestedPartyId !== identity.partyId) return json(403, { error: "party_access_denied" });
    if (!await deps.authorize(identity)) return json(403, { error: "character_access_denied" });
    const level = url.searchParams.get("level") as BuildMapViewInput["level"] | null;
    const parentNodeId = url.searchParams.get("parentNodeId");
    if (!level || !/^G[1-4]$/.test(level) || !parentNodeId) return json(400, { error: "invalid_map_request" });
    try {
      const input = await deps.loadMapInput({ ...identity, parentNodeId, level });
      return json(200, buildMapView(input));
    } catch (error) {
      return json(422, { error: "map_view_failed", message: error instanceof Error ? error.message : String(error) });
    }
  };
}
