# Source → target compilation specification

## P12-TC01 Source verification

Вход: immutable P12 ZIP, ожидаемый SHA-256, exact file-set и внутренний manifest. Выход: immutable verified snapshot. Любое отличие блокирует весь pipeline.

## P12-TC02 Canonical nodes

32 host G4 и 195 canonical G5 отображаются в proposals `canonical_spatial_node`. Reclassification не создаёт новый топоним или исторический объект. G5 parent всегда exact host G4 version `@1`; host G4 parent G3 version и target world revision обязаны быть разрешены из exact branch version graph. Пока эти pins отсутствуют, write set блокируется.

## P12-TC03 Scene profiles

Каждый canonical G5 получает ровно один approved profile и один candidate. Все 17 scene template families имеют endpoint slots `arrival` и `departure`. Zero/multiple candidate остаётся hard block.

## P12-TC04 Relation reclassification

| Source label | Exact target meaning |
|---|---|
| `intra_g4_site_connection_source` | directed request for `canonical_g5_connection_binding`; не party row до materialization |
| `cross_g4_world_route_source` | directed `world_route_compilation_request`; не route до approved chain/profile |
| `host_entry_site_connection_source` | один non-movement `g4_entry_endpoint_binding` на pair; название source сохраняется только как provenance |
| `corridor_to_host_route_context_source` | staging-only route-context entry link |
| `world_route_segment_context_source` | staging-only route-context adjacency link |

## P12-TC05 Profiles

Connection/segment request становится target proposal только после exact profile resolution. Обязательны environment, orientation, passage/route kind, movement cost или action cost, dynamic recheck, risk/availability policy. Пустое поле не получает default.

## P12-TC06 Routes

Один approved directed route имеет один from endpoint, один to endpoint и конечную непрерывную ordered chain. Reverse route является отдельной записью. Context links не выбирают путь автоматически; они лишь ограничивают editor-approved chain.

## P12-TC07 Branch validation

Compiler получает exact branch contract registry и DDL digest. Несовпадение field/nullability/enum/FK/version semantics создаёт `p12_branch_contract_mismatch`.

## P12-TC08 Isolated DB

Запись разрешена только в isolated PostgreSQL transaction с dry-run, apply, readback digest и rollback. Production/operator DB запрещены.
