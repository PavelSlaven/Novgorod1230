import test from "node:test";
import assert from "node:assert/strict";
import {
  validateMapRequest, loadLocalCanonicalGraph, applyPartyOverlay, applyCharacterKnowledge,
  materializeBoundaryExits, collapseVisualEdges, attachApprovedLayout, attachVisualStyles,
  buildMapViewDTO, validateNoHiddenLeaks, buildMapView
} from "../dist/node.js";
import { baseInput } from "./helpers.mjs";

test("validateMapRequest validates level, layout and exact current position", () => {
  const input = baseInput();
  assert.equal(validateMapRequest(input).parentNodeId, "parent");
  assert.throws(() => validateMapRequest({ ...input, level: "G3" }), /map_layout_mismatch/);
  const changed = baseInput(); changed.nodeKnowledge[0].state = "rumored";
  assert.throws(() => validateMapRequest(changed), /current_position_not_exact/);
});

test("loadLocalCanonicalGraph isolates one parent and keeps boundary edges", () => {
  const input = baseInput();
  input.nodes.push({ id: "other", parentNodeId: "other-parent", level: "G4", title: "Other", nodeType: "yard" });
  const graph = loadLocalCanonicalGraph(input, validateMapRequest(input));
  assert.deepEqual(graph.nodes.map((node) => node.id), ["a", "b"]);
  assert.ok(graph.edges.some((edge) => edge.id === "out"));
});

test("applyPartyOverlay keeps party changes separate", () => {
  const input = baseInput();
  const graph = applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input)));
  assert.equal(graph.nodeStatusById.get("b").changed, true);
  assert.equal(graph.edgeStateById.get("ba").traversalState, "blocked");
});

test("applyCharacterKnowledge uses only player-facing names, icons and child flags", () => {
  const input = baseInput();
  input.nodes[1].title = "Точный тайный монастырский склад";
  input.nodes[1].nodeType = "monastery";
  input.nodeKnowledge[1] = { nodeId: "b", publicId: "rumor-b", state: "rumored", displayTitle: "Неясное строение", displayIconKey: "generic_place", displayPosition: { x: .62, y: .61 }, knownChildMapAvailable: false };
  input.edgeKnowledge[0] = { edgeId: "ab", publicId: "rumor-route", state: "rumored", displayType: "unknown_route", traversalState: "unknown" };
  input.edgeKnowledge[1] = { edgeId: "ba", publicId: "rumor-route-back", state: "doubtful", displayType: "unknown_route", traversalState: "unknown" };
  const visible = applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input))));
  const node = visible.visibleNodes.find((item) => item.canonicalId === "b");
  assert.equal(node.title, "Неясное строение");
  assert.equal(node.iconKey, "generic_place");
  assert.equal(node.hasKnownChildren, false);
  assert.deepEqual(node.displayPosition, { x: .62, y: .61 });
});

test("materializeBoundaryExits creates a schematic public exit without external IDs", () => {
  const input = baseInput();
  const visible = applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input))));
  const result = materializeBoundaryExits(visible);
  assert.equal(result.boundaryNodes.length, 1);
  assert.equal(result.boundaryNodes[0].title, "Выход к дороге");
  assert.ok(!JSON.stringify(result.boundaryNodes).includes("external"));
});

test("collapseVisualEdges joins reverse directions and contains never survives", () => {
  const input = baseInput();
  const visible = materializeBoundaryExits(applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input)))));
  const collapsed = collapseVisualEdges(visible);
  assert.equal(collapsed.collapsedEdges.length, 1);
  assert.ok(collapsed.collapsedEdges[0].reverse);
  assert.ok(collapsed.visibleEdges.every((edge) => edge.canonicalId !== "contains"));
});

test("attachApprovedLayout rejects overlap-approved layouts and uses bend points", () => {
  const input = baseInput();
  const collapsed = collapseVisualEdges(materializeBoundaryExits(applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input))))));
  const positioned = attachApprovedLayout(collapsed);
  assert.equal(positioned.positionedEdges[0].bendPoints.length, 2);
  const bad = baseInput(); bad.layout.qualityReport.nodeOverlapCount = 1;
  const badCollapsed = collapseVisualEdges(materializeBoundaryExits(applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(bad, validateMapRequest(bad))))));
  assert.throws(() => attachApprovedLayout(badCollapsed), /approved_layout_has_overlaps/);
});

test("attachVisualStyles applies safe icon fallback", () => {
  const input = baseInput(); input.nodeKnowledge[1].displayIconKey = "unregistered";
  const graph = attachApprovedLayout(collapseVisualEdges(materializeBoundaryExits(applyCharacterKnowledge(applyPartyOverlay(loadLocalCanonicalGraph(input, validateMapRequest(input)))))));
  assert.equal(attachVisualStyles(graph).positionedNodes.find((node) => node.id === "public-b").iconKey, "generic_place");
});

test("buildMapViewDTO and hidden-leak gate produce a safe immutable DTO", () => {
  const input = baseInput();
  const view = buildMapView(input);
  assert.equal(view.edges.length, 2);
  assert.equal(view.edges.find((edge) => edge.id.includes("route-ab")).directions.reverse.traversalState, "blocked");
  assert.ok(!JSON.stringify(view).includes("canonical"));
  assert.ok(Object.isFrozen(view));
  assert.equal(validateNoHiddenLeaks(view), view);
});
