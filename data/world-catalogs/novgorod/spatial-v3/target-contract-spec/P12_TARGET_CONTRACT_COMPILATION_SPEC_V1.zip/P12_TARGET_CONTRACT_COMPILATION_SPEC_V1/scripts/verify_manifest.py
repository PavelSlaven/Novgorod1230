from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / 'manifest.json'
sidecar_path = ROOT / 'manifest.sha256'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
errors = []
expected = {r['path']: r for r in manifest['files']}
actual = {}
for p in sorted(ROOT.rglob('*')):
    if not p.is_file(): continue
    rel = p.relative_to(ROOT).as_posix()
    if rel in {'manifest.json', 'manifest.sha256'}: continue
    actual[rel] = {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
if set(expected) != set(actual):
    errors.append({'code': 'fileset_mismatch', 'missing': sorted(set(expected)-set(actual)), 'extra': sorted(set(actual)-set(expected))})
for path in sorted(set(expected) & set(actual)):
    if expected[path]['bytes'] != actual[path]['bytes'] or expected[path]['sha256'] != actual[path]['sha256']:
        errors.append({'code': 'file_digest_mismatch', 'path': path})
expected_manifest_digest = sidecar_path.read_text(encoding='ascii').strip().split()[0]
actual_manifest_digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
if expected_manifest_digest != actual_manifest_digest:
    errors.append({'code': 'manifest_sidecar_mismatch'})
print(json.dumps({'schema_version': 'rus.p12_target_manifest_verification.v1', 'result': 'PASS' if not errors else 'FAIL', 'checked_files': len(actual), 'errors': errors}, ensure_ascii=False, indent=2))
sys.exit(0 if not errors else 1)
