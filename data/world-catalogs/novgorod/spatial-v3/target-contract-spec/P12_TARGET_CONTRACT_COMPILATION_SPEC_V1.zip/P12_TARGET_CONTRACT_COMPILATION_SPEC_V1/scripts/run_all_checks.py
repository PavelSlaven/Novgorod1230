from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = [
    ('package', [sys.executable, str(ROOT/'scripts/validate_package.py')], 0),
    ('json_schemas', [sys.executable, str(ROOT/'scripts/validate_json_schemas.py')], 0),
    ('semantic_audit', [sys.executable, str(ROOT/'scripts/semantic_audit.py')], 0),
    ('reproducibility', [sys.executable, str(ROOT/'scripts/verify_reproducibility.py')], 0),
    ('manifest', [sys.executable, str(ROOT/'scripts/verify_manifest.py')], 0),
    ('evidence_template_negative', [
        sys.executable, str(ROOT/'scripts/verify_activation_evidence.py'),
        str(ROOT/'templates/P27_SIGNED_AUDIT_EVIDENCE.template.json'),
        str(ROOT/'templates/FRESH_CHECKOUT_EVIDENCE.template.json'),
        str(ROOT/'templates/P28_ACTIVATION_DECISION.template.json'),
        '--trust-store', str(ROOT/'templates/ACTIVATION_TRUST_STORE.template.json'),
    ], 2),
]
results = []
failed = False
for name, command, expected in checks:
    cp = subprocess.run(command, text=True, capture_output=True)
    ok = cp.returncode == expected
    results.append({'name': name, 'expected_exit': expected, 'actual_exit': cp.returncode, 'ok': ok, 'stdout': cp.stdout.strip(), 'stderr': cp.stderr.strip()})
    failed |= not ok
print(json.dumps({'schema_version': 'rus.p12_target_all_checks.v1', 'result': 'FAIL' if failed else 'PASS', 'checks': results}, ensure_ascii=False, indent=2))
sys.exit(1 if failed else 0)
