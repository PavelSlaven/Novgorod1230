import cytoscape, { type Core, type EdgeSingular, type EventObject } from "cytoscape";
import type { MapDataSource, MapScaleLevel, MapViewDTO, Point } from "../domain/types.js";
import { validateMapView } from "../application/validate-map-view.js";
import { iconDataUri } from "../infrastructure/assets.js";

export interface MapMakerOptions {
  dataSource?: MapDataSource;
  mode?: "compact" | "full";
  onNodeSelect?: (nodeId: string) => void;
  onOpenChildren?: (nodeId: string) => void;
  onEdgeSelect?: (edgeId: string) => void;
  onNavigate?: (parentNodeId: string, level: MapScaleLevel) => void;
}

const MARKER_GLYPHS: Record<string, string> = { bridge: "═", gate: "▥", door: "▯", ford: "⋯", ferry: "◒" };

function segmentData(points: Point[], source: Point, target: Point, size: number): { weights: string; distances: string } {
  if (points.length === 0) return { weights: "", distances: "" };
  const sx = source.x * size, sy = source.y * size, tx = target.x * size, ty = target.y * size;
  const dx = tx - sx, dy = ty - sy;
  const lengthSquared = dx * dx + dy * dy || 1;
  const length = Math.sqrt(lengthSquared);
  const weights: number[] = [], distances: number[] = [];
  for (const point of points) {
    const px = point.x * size, py = point.y * size;
    const weight = ((px - sx) * dx + (py - sy) * dy) / lengthSquared;
    const signedDistance = ((px - sx) * -dy + (py - sy) * dx) / length;
    if (weight > 0.01 && weight < 0.99) {
      weights.push(Number(weight.toFixed(4)));
      distances.push(Number(signedDistance.toFixed(2)));
    }
  }
  return { weights: weights.join(" "), distances: distances.join(" ") };
}

export class MapMaker {
  private readonly root: HTMLElement;
  private readonly graphHost: HTMLElement;
  private readonly markerLayer: SVGSVGElement;
  private readonly title: HTMLElement;
  private readonly breadcrumbs: HTMLElement;
  private readonly details: HTMLElement;
  private readonly keyboardList: HTMLElement;
  private readonly resizeObserver: ResizeObserver;
  private cy?: Core;
  private view?: MapViewDTO;
  private requestId = 0;

  constructor(container: HTMLElement, private readonly options: MapMakerOptions = {}) {
    this.root = document.createElement("section");
    this.root.className = `mm-root mm-${options.mode ?? "full"}`;
    this.root.innerHTML = `<header class="mm-header"><nav class="mm-breadcrumbs" aria-label="Масштаб карты"></nav><strong class="mm-title"></strong></header><div class="mm-square"><div class="mm-graph"></div><svg class="mm-marker-layer" aria-hidden="true"></svg></div><aside class="mm-details" aria-live="polite"></aside><details class="mm-keyboard"><summary>Текстовая навигация по карте</summary><div class="mm-keyboard-list"></div></details>`;
    container.replaceChildren(this.root);
    this.graphHost = this.root.querySelector<HTMLElement>(".mm-graph")!;
    this.markerLayer = this.root.querySelector<SVGSVGElement>(".mm-marker-layer")!;
    this.title = this.root.querySelector<HTMLElement>(".mm-title")!;
    this.breadcrumbs = this.root.querySelector<HTMLElement>(".mm-breadcrumbs")!;
    this.details = this.root.querySelector<HTMLElement>(".mm-details")!;
    this.keyboardList = this.root.querySelector<HTMLElement>(".mm-keyboard-list")!;
    this.resizeObserver = new ResizeObserver(() => {
      this.cy?.resize();
      this.updateMarkers();
    });
    this.resizeObserver.observe(this.root);
  }

  async open(parentNodeId: string, level: MapScaleLevel): Promise<void> {
    if (!this.options.dataSource) throw new Error("map_data_source_missing");
    const id = ++this.requestId;
    this.root.setAttribute("aria-busy", "true");
    try {
      const view = await this.options.dataSource.loadView({ parentNodeId, level });
      if (id === this.requestId) this.setView(view);
    } finally {
      if (id === this.requestId) this.root.removeAttribute("aria-busy");
    }
  }

  setView(view: MapViewDTO): void {
    validateMapView(view);
    this.view = view;
    this.cy?.destroy();
    this.title.textContent = `${view.layout.level} · ${view.layout.status}`;
    this.renderBreadcrumbs(view);
    this.renderKeyboard(view);
    const size = Math.max(320, Math.min(this.graphHost.clientWidth || 720, this.graphHost.clientHeight || 720));
    const nodeById = new Map(view.nodes.map((node) => [node.id, node]));
    const position = (x: number, y: number) => ({ x: x * size, y: y * size });
    this.cy = cytoscape({
      container: this.graphHost,
      elements: [
        ...view.nodes.map((node) => ({
          data: {
            ...node,
            currentFlag: node.current ? "yes" : "no",
            icon: iconDataUri(node.iconKey),
            label: node.shortLabel ?? node.title,
            blockedFlag: node.visibleStatus?.blocked ? "yes" : "no",
            dangerFlag: node.visibleStatus?.dangerous ? "yes" : "no",
            changedFlag: node.visibleStatus?.changed ? "yes" : "no"
          },
          classes: `knowledge-${node.knowledgeState} ${node.synthetic ?? "world-node"}`,
          position: position(node.x, node.y)
        })),
        ...view.edges.map((edge) => {
          const source = nodeById.get(edge.source)!;
          const target = nodeById.get(edge.target)!;
          const segment = segmentData(edge.bendPoints, source, target, size);
          return {
            data: { ...edge, segmentWeights: segment.weights, segmentDistances: segment.distances },
            classes: `${edge.styleKey} knowledge-${edge.knowledgeState} traversal-${edge.traversalState} ${edge.bendPoints.length ? "has-bends" : "straight-edge"}`
          };
        })
      ],
      layout: { name: "preset", fit: true, padding: 34 },
      minZoom: 0.45,
      maxZoom: 3,
      style: [
        { selector: "node", style: { width: 42, height: 42, "background-image": "data(icon)", "background-fit": "cover", "background-opacity": 0,
          label: "", "overlay-opacity": 0, "border-width": 2, "border-color": "#493a2a", "border-opacity": 0.9 } },
        { selector: "node[labelPriority = 3], node[labelPriority = 2]", style: { label: "data(label)", "font-size": "11px", "text-wrap": "wrap", "text-max-width": "110px",
          "text-valign": "bottom", "text-margin-y": 8, color: "#2c241b", "text-background-color": "#f4ead0", "text-background-opacity": 0.9, "text-background-padding": "3px" } },
        { selector: "node.knowledge-known_roughly", style: { opacity: 0.75, "border-style": "dashed" } },
        { selector: "node.knowledge-rumored", style: { opacity: 0.58, "border-style": "dotted", "border-width": 3 } },
        { selector: "node.knowledge-doubtful", style: { opacity: 0.42, "border-style": "dotted", "border-color": "#725d87" } },
        { selector: "node[currentFlag = 'yes']", style: { "border-width": 4, "border-color": "#b92722", "border-opacity": 1, opacity: 1 } },
        { selector: "node[blockedFlag = 'yes']", style: { "border-color": "#a72d27", "border-width": 4 } },
        { selector: "node[dangerFlag = 'yes']", style: { "underlay-color": "#d68d2e", "underlay-opacity": 0.22, "underlay-padding": 8 } },
        { selector: "node[changedFlag = 'yes']", style: { "overlay-color": "#4b7f55", "overlay-opacity": 0.16, "overlay-padding": 6 } },
        { selector: "node.boundary_exit", style: { width: 34, height: 34, shape: "diamond" } },
        { selector: "edge", style: { width: 3, "line-color": "#7c674b", "curve-style": "round-segments", opacity: 0.9 } },
        { selector: "edge.has-bends", style: { "curve-style": "segments", "segment-weights": "data(segmentWeights)", "segment-distances": "data(segmentDistances)" } },
        { selector: "edge.path, edge.forest_track, edge.offroad_crossing", style: { width: 2, "line-style": "dashed" } },
        { selector: "edge.river, edge.lake_route", style: { width: 7, "line-color": "#5795a8" } },
        { selector: "edge.street", style: { width: 6, "line-color": "#9b886b" } },
        { selector: "edge.door, edge.gate, edge.yard_passage", style: { width: 2 } },
        { selector: "edge.traversal-blocked", style: { "line-color": "#a72d27", "line-style": "dashed" } },
        { selector: "edge.traversal-restricted", style: { "line-color": "#9a6b2f", "line-style": "dashed" } },
        { selector: "edge.traversal-seasonal", style: { "line-color": "#6b7f8d", "line-style": "dotted" } },
        { selector: "edge.traversal-unknown", style: { opacity: 0.35, "line-style": "dotted" } },
        { selector: "edge.knowledge-known_roughly", style: { opacity: 0.72 } },
        { selector: "edge.knowledge-rumored, edge.knowledge-doubtful", style: { opacity: 0.45, "line-style": "dotted" } },
        { selector: ":selected", style: { "overlay-color": "#c99b3d", "overlay-opacity": 0.2, "overlay-padding": 8 } }
      ]
    });
    this.cy.on("tap", "node", (event: EventObject) => this.selectNode(event.target.data().id));
    this.cy.on("dbltap", "node", (event: EventObject) => {
      const data = event.target.data();
      if (data.hasKnownChildren) this.options.onOpenChildren?.(data.id);
    });
    this.cy.on("tap", "edge", (event: EventObject) => this.selectEdge(event.target.data().id));
    this.cy.on("pan zoom render", () => this.updateMarkers());
    queueMicrotask(() => this.updateMarkers());
  }

  private selectNode(nodeId: string): void {
    const node = this.view?.nodes.find((item) => item.id === nodeId);
    if (!node) return;
    this.cy?.nodes().unselect();
    this.cy?.getElementById(nodeId).select();
    this.details.textContent = `${node.title} · ${node.knowledgeState}${node.description ? ` · ${node.description}` : ""}`;
    this.options.onNodeSelect?.(nodeId);
  }

  private selectEdge(edgeId: string): void {
    const edge = this.view?.edges.find((item) => item.id === edgeId);
    if (!edge) return;
    this.cy?.edges().unselect();
    this.cy?.getElementById(edgeId).select();
    this.details.textContent = edge.knownSummary ?? `${edge.edgeType} · ${edge.knowledgeState} · ${edge.traversalState}`;
    this.options.onEdgeSelect?.(edgeId);
  }

  private updateMarkers(): void {
    if (!this.cy || !this.view) return;
    const rect = this.graphHost.getBoundingClientRect();
    this.markerLayer.setAttribute("viewBox", `0 0 ${Math.max(1, rect.width)} ${Math.max(1, rect.height)}`);
    this.markerLayer.replaceChildren(...this.view.edges.flatMap((edge) => {
      if (!edge.markerKey) return [];
      const cyEdge = this.cy!.getElementById(edge.id) as EdgeSingular;
      if (cyEdge.empty()) return [];
      const point = cyEdge.renderedMidpoint();
      const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
      group.setAttribute("class", `mm-marker mm-marker-${edge.markerKey}`);
      group.setAttribute("transform", `translate(${point.x} ${point.y})`);
      const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      circle.setAttribute("r", "10");
      const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("dominant-baseline", "central");
      text.textContent = MARKER_GLYPHS[edge.markerKey] ?? "•";
      group.append(circle, text);
      return [group];
    }));
  }

  private renderKeyboard(view: MapViewDTO): void {
    const nodeHeading = document.createElement("h3"); nodeHeading.textContent = "Места";
    const nodeList = document.createElement("ul");
    for (const node of view.nodes) {
      const item = document.createElement("li");
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = `${node.title} — ${node.knowledgeState}${node.current ? " — текущее положение" : ""}`;
      button.addEventListener("click", () => this.selectNode(node.id));
      button.addEventListener("dblclick", () => { if (node.hasKnownChildren) this.options.onOpenChildren?.(node.id); });
      item.append(button); nodeList.append(item);
    }
    const edgeHeading = document.createElement("h3"); edgeHeading.textContent = "Пути";
    const edgeList = document.createElement("ul");
    for (const edge of view.edges) {
      const item = document.createElement("li");
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = `${edge.knownSummary ?? edge.edgeType} — ${edge.traversalState}`;
      button.addEventListener("click", () => this.selectEdge(edge.id));
      item.append(button); edgeList.append(item);
    }
    this.keyboardList.replaceChildren(nodeHeading, nodeList, edgeHeading, edgeList);
  }

  private renderBreadcrumbs(view: MapViewDTO): void {
    this.breadcrumbs.replaceChildren(...view.breadcrumbs.map((crumb, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = crumb.title;
      button.className = "mm-crumb";
      button.disabled = index === view.breadcrumbs.length - 1;
      button.addEventListener("click", () => this.options.onNavigate?.(crumb.publicNodeId, crumb.level));
      return button;
    }));
  }

  focusCurrent(): void {
    const current = this.view?.currentPosition.nodeId;
    if (current) this.selectNode(current);
  }

  destroy(): void {
    this.requestId += 1;
    this.resizeObserver.disconnect();
    this.cy?.destroy();
    this.root.remove();
  }
}
