# P12 gap-closure rule

The previously missing authoring values are present in this bundle, so the data gaps are editorially resolved.

A repository gap may be changed to `closed` only after the exact approved bundle is compiled and imported into isolated PostgreSQL, all FK/count/digest/readback checks pass, rollback succeeds and the independent critic accepts the implementation.

A document declaration alone is not proof of DDL materialization. Failed or absent materialization evidence leaves the operational gap open.
