from pathlib import Path
import json
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
def load(rel): return json.loads((ROOT/rel).read_text(encoding='utf-8'))
def fail(msg): print('FAIL JSON Schema:',msg); raise SystemExit(1)
checks=[
 ('schemas/approval-decision.schema.json','APPROVAL_DECISION.json',False),
 ('schemas/gap-closure-ledger.schema.json','data/gap-closure-ledger.json',False),
 ('schemas/connection-profile.schema.json','data/approved-connection-profiles.json',True),
 ('schemas/canonical-spatial-node-row.schema.json','target/canonical-spatial-nodes.json',True),
 ('schemas/world-route-segment-row.schema.json','target/world-route-segments.json',True),
 ('schemas/world-route.schema.json','data/approved-world-routes.json',True),
 ('schemas/repository-branch-binding.schema.json','templates/repository-branch-binding.template.json',False),
]
validated=0
for srel,drel,records in checks:
    schema=load(srel); Draft202012Validator.check_schema(schema); validator=Draft202012Validator(schema)
    data=load(drel); instances=data['records'] if records else [data]
    for i,x in enumerate(instances):
        errors=sorted(validator.iter_errors(x),key=lambda e:list(e.path))
        if errors: fail(f'{drel}[{i}] '+errors[0].message)
        validated+=1
print(f'PASS validate_json_schemas 7 schemas / {validated} instances')
