export function baseInput() {
  return {
    parentNodeId: "parent",
    level: "G4",
    nodes: [
      { id: "a", parentNodeId: "parent", level: "G4", title: "Канонический двор", nodeType: "yard" },
      { id: "b", parentNodeId: "parent", level: "G4", title: "Каноническая часовня", nodeType: "church" }
    ],
    edges: [
      { id: "ab", reverseEdgeId: "ba", source: "a", target: "b", edgeType: "road" },
      { id: "ba", reverseEdgeId: "ab", source: "b", target: "a", edgeType: "road" },
      { id: "contains", source: "a", target: "b", edgeType: "contains" },
      { id: "out", reverseEdgeId: "out-rev", source: "a", target: "external", edgeType: "path" }
    ],
    boundaryExits: [{ id: "boundary:out", edgeIds: ["out", "out-rev"], sourceNodeId: "a", externalNodeId: "external", side: "east", edgeType: "path" }],
    nodeKnowledge: [
      { nodeId: "a", publicId: "public-a", state: "visited", displayTitle: "Двор", displayIconKey: "yard", knownChildMapAvailable: false },
      { nodeId: "b", publicId: "public-b", state: "known_exactly", displayTitle: "Часовня", displayIconKey: "church", knownChildMapAvailable: true }
    ],
    edgeKnowledge: [
      { edgeId: "ab", publicId: "route-ab", state: "traversed", displayType: "road", traversalState: "open", knownSummary: "Знакомая дорога" },
      { edgeId: "ba", publicId: "route-ba", state: "known_exactly", displayType: "road", traversalState: "restricted" },
      { edgeId: "contains", publicId: "structural", state: "known_exactly", displayType: "passage", traversalState: "open" },
      { edgeId: "out", publicId: "route-out", state: "known_exactly", displayType: "path", displayLabel: "Выход к дороге", traversalState: "open", knownTargetMapAvailable: true }
    ],
    partyOverlay: { nodes: [{ nodeId: "b", visibleStatus: { changed: true } }], edges: [{ edgeId: "ba", traversalState: "blocked" }] },
    layout: {
      id: "layout", parentNodeId: "parent", level: "G4", version: 2, profile: "settlement", status: "approved",
      positions: { a: { x: .2, y: .3 }, b: { x: .8, y: .7 } },
      boundaryPositions: { "boundary:out": { x: .98, y: .4 } },
      edgeGeometry: { ab: [{ x: .2, y: .5 }, { x: .8, y: .5 }], "boundary:out": [{ x: .8, y: .3 }] },
      qualityReport: { nodeOverlapCount: 0, minimumNodeDistance: .7, edgeCrossingCount: 0, labelCollisionCount: 0, boundaryExitConflictCount: 0, invalidCoordinateCount: 0, duplicateCoordinateCount: 0, missingGeometryCount: 0, totalEdgeBends: 3, aspectRatio: 1 },
      semanticReview: { required: true, decision: "approved", reviewerType: "llm", reviewerId: "test", reviewedAt: "2026-07-11T00:00:00Z", rationale: ["fixture"] }
    },
    currentNodeId: "a",
    breadcrumbs: [{ publicNodeId: "parent-public", title: "Место", level: "G4" }]
  };
}
