import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";
import http from "node:http";
import { resolveInsideRoot } from "../scripts/static-security.mjs";
import { startDemoServer } from "../scripts/demo-server.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function rawRequest(port, requestPath) {
  return new Promise((resolve, reject) => {
    const request = http.get({ host: "127.0.0.1", port, path: requestPath }, (response) => {
      response.resume(); response.on("end", () => resolve(response.statusCode));
    });
    request.on("error", reject);
  });
}

test("path resolver rejects traversal, encoded separators and NUL", () => {
  const staticRoot = path.join(root, "examples");
  for (const attack of [
    "../private-generated/server/manifest.json",
    "%2e%2e/private-generated/server/manifest.json",
    "..%2fprivate-generated/server/manifest.json",
    "%252e%252e%252fprivate-generated/server/manifest.json",
    "..\\private-generated\\server\\manifest.json",
    "index.html%00.js"
  ]) assert.equal(resolveInsideRoot(staticRoot, attack), null, attack);
  assert.ok(resolveInsideRoot(staticRoot, "index.html"));
});

test("demo server never exposes generated graph or node_modules", async (t) => {
  const started = await startDemoServer({ root, generatedRoot: path.join(root, "test/fixtures/generated"), port: 0 });
  t.after(() => new Promise((resolve) => started.server.close(resolve)));
  const port = started.address.port;
  for (const attack of [
    "/private-generated/server/manifest.json",
    "/node_modules/cytoscape/dist/cytoscape.esm.min.mjs",
    "/examples/%2e%2e/private-generated/server/manifest.json",
    "/examples/..%2fprivate-generated/server/manifest.json",
    "/examples/%252e%252e%252fprivate-generated/server/manifest.json"
  ]) {
    const status = await rawRequest(port, attack);
    assert.ok(status === 403 || status === 404, `${attack} returned ${status}`);
  }
  assert.equal(await rawRequest(port, "/dev-api/manifest"), 200);
  assert.equal(await rawRequest(port, "/dev-api/view?level=G4&parentNodeId=parent"), 200);
});
