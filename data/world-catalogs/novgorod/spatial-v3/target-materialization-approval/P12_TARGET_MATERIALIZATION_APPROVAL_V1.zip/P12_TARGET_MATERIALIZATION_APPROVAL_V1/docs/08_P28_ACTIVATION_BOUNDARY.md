# P28 and production boundary

This bundle does not activate P28. Production v2 must remain unchanged.

P28 requires one exact 40-hex activation candidate commit containing the implemented DDL/compiler/importer and composition switch, plus role-bound Ed25519-signed P27, fresh-checkout and release evidence for the exact same commit and evidence-file digests.

No approval text, completed JSON shape or internal audit can substitute for those signatures. Deployment remains prohibited until the repository-owned trust verifier passes.
