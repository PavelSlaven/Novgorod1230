# Branch and version binding

The semantic target version graph is approved: target world revision `novgorod_spatial_v3_target_contract_approval_001@1`, region `region_novgorod_land@1`, G1 `gn_nov_g1_xp017_yp026@1`, 15 retained G2 versions, 32 retained G3 versions, 32 target G4 versions and 195 target G5 versions.

A Git branch name and HEAD SHA are repository facts, not authoring content. The available canonical `main` was observed at `9f2a8c1477793e3baac376d558a64b1b2272cc4a` and did not expose the reported integration branch. Therefore this bundle does not invent a branch name.

Before repository DDL apply, the existing single P12 PR branch must be bound in the repository integration manifest with exact branch name, 40-hex HEAD, the two accepted input ZIP digests and this approval-bundle digest. A mismatch blocks repository apply. This binding is not the later P28 activation commit.


The dated repository observation is recorded in `data/repository-observation.json`. The fail-closed handoff shape is `templates/repository-branch-binding.template.json`; it is intentionally invalid for repository apply until a pushed branch, PR number, exact 40-hex HEAD and final approval-bundle SHA-256 are supplied.
