from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
findings=[]
a=load('data/target-ddl-materialization-authorization.json')
for denial in ['no P28 activation','no production database write','no production composition switch','no substitution for signed P27/fresh-checkout/P28 evidence']:
    if denial not in a['explicit_denials']: findings.append('missing denial: '+denial)
if a.get('contract_amendment_ref')!='rus.p12_target_contract_amendment@1.2.0': findings.append('wrong amendment ref')
am=load('data/approved-contract-amendment.json')
if am.get('status')!='approved_for_implementation' or am.get('amendment_ref')!='rus.p12_target_contract_amendment@1.2.0': findings.append('amendment not active for isolated implementation')
if am.get('runtime_activation_status')!='inactive_until_integrated_ddl_tests_signed_p27_fresh_checkout_p28': findings.append('runtime boundary missing')
for p in load('target/topological-movement-orientation-profiles.json')['records']:
    if not p['forbids_compass_inference'] or any(k in p for k in ['azimuth','bearing_center_mdeg','fixed_local_azimuth_mdeg']): findings.append('topological profile leaks geometry')
for p in load('target/canonical-g5-connection-profiles.json')['records']:
    if p['profile_scope']=='world_route_segment' and p['cost_kind']!='time': findings.append('route profile not time')
for r in load('data/gap-closure-ledger.json')['records']:
    if r['code'].startswith('p12_') and 'after' not in r.get('operational_state',''): findings.append('P12 closure lacks gate: '+r['code'])
if load('data/p28-production-activation-status.json')['status']!='BLOCKED': findings.append('P28 must remain blocked')

pre=a.get('preconditions',[])
if len(pre)!=len(set(pre)): findings.append('duplicate DDL preconditions')
if load('data/version-pins.json').get('status')!='approved' or len(load('data/version-pins.json')['records'])!=50: findings.append('version pin graph is not exact 50 approved pins')
for c in am.get('contracts',[]):
    inv=c.get('invariants',[])
    if len(inv)!=len(set(inv)): findings.append('duplicate amendment invariant: '+c.get('contract_name','unknown'))
obs=load('data/repository-observation.json')
bind=load('templates/repository-branch-binding.template.json')
if obs.get('conclusion') is None or bind.get('status')!='BLOCKED_UNBOUND': findings.append('repository branch boundary is not fail-closed')
if any(bind.get(k) is not None for k in ['pr_number','branch_name','head_sha','approval_bundle_sha256']): findings.append('branch template fabricates repository facts')
if load('APPROVAL_DECISION.json')['scope'].get('p28_production_activation')!='not_authorized': findings.append('approval decision leaks P28 authority')

if findings:
    print(json.dumps({'result':'CHANGES REQUIRED','open_findings':findings},ensure_ascii=False,indent=2)); raise SystemExit(1)
print(json.dumps({'result':'PASS','open_findings':0},ensure_ascii=False,indent=2))
