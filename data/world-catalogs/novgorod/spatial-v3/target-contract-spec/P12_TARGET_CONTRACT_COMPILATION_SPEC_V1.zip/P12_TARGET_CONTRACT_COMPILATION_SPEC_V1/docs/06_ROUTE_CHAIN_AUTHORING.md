# Route-chain authoring specification

## Scope

43 bidirectional cross-G4 source pairs дают 86 directed route requests. Они не дают 86 готовых routes.

## Для каждой direction требуется

- exact from/to canonical G5;
- exact from `g4_directional_exit`;
- route kind;
- ordered route context links;
- ordered points and segments;
- exact profile per segment;
- from/to scene endpoint slots;
- reciprocal reverse route либо explicit one-way declaration;
- provenance, version, status and canonical digest.

## Запреты

- shortest path по staging context graph;
- nearest endpoint;
- first-row selection;
- создание segment из G2 adjacency без editor-approved route chain;
- перенос layout bearing в factual orientation;
- один route с branch/cycle.

Рабочая форма: `templates/route-chain-authoring.csv`. Пустая ordered chain создаёт `p12_route_chain_missing`.
