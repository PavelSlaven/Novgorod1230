# Proposed target-contract amendment

## Обнаруженный нормативный пробел

Target standard определяет mutable party contract `g5_site_connection`, но не определяет нормализованный world-base authoring contract, из которого materializer обязан детерминированно создать canonical-G5 connection и два endpoint bindings. Поэтому P12 source pairs нельзя безопасно импортировать напрямую.

## Предлагаемые contracts

### `canonical_g5_connection_profile`

Хранит только механический профиль связи: passage type, environment, orientation, action/time XOR, method/cost/recheck, capacity, risk и availability. Не содержит endpoints.

### `canonical_g5_connection_binding`

Связывает два canonical G5 одного G4 с exact profile и scene endpoint slots. Reverse binding — отдельная reciprocal versioned relation. Materializer проецирует binding в party `g5_site_connection`.

### `g4_entry_endpoint_binding`

Связывает G4 с canonical entry G5 и endpoint slots. Это non-movement relation: zero time, zero cost, no party connection. Она нужна для route endpoint projection и initial-entry validation.

### `route_context_link`

Staging-only relation между retained G2/G3 contexts. Она не является route, segment или movement edge и никогда не доступна runtime. Её потребляет только route-chain compiler.

Полные поля и invariants находятся в `data/contract-amendment.json`. Amendment имеет статус `proposed_not_active`; интеграция требует обновления target standard, contract matrix, DDL, schemas, validators, docs registries и независимого critic cycle.
