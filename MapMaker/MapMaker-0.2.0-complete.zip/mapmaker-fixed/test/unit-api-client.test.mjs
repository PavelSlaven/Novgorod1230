import test from "node:test";
import assert from "node:assert/strict";
import { HttpMapDataSource } from "../dist/node.js";

test("browser API accepts a relative base URL", async () => {
  let requested;
  const source = new HttpMapDataSource("/api/", async (url) => {
    requested = String(url);
    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  });
  await source.loadView({ parentNodeId: "p", level: "G4" });
  assert.equal(requested, "http://localhost/api/map/view?parentNodeId=p&level=G4");
});
