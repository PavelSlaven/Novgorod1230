import { markerForEdge, styleForEdge } from "../../domain/catalog.js";
import type { MapEdgeDTO, MapNodeDTO, Point } from "../../domain/types.js";
import type { CollapsedGraph, PositionedGraph } from "./internal.js";

const clamp = (value: number) => Math.min(0.98, Math.max(0.02, value));
const cleanPoint = (point: Point): Point => ({ x: clamp(point.x), y: clamp(point.y) });

export function attachApprovedLayout(graph: CollapsedGraph): PositionedGraph {
  if (graph.layout.status !== "approved" && !graph.request.allowUnapprovedLayout) throw new Error("map_layout_not_approved");
  if (graph.layout.status === "approved" && graph.layout.qualityReport?.nodeOverlapCount !== 0) throw new Error("approved_layout_has_overlaps");

  const positionedNodes: MapNodeDTO[] = graph.visibleNodes.map((node) => {
    const canonicalPosition = graph.layout.positions[node.canonicalId];
    const position = node.displayPosition ?? canonicalPosition;
    if (!position) throw new Error(`map_layout_missing_position:${node.canonicalId}`);
    return {
      id: node.publicId,
      title: node.title,
      shortLabel: node.shortLabel,
      description: node.description,
      iconKey: node.iconKey,
      x: clamp(position.x),
      y: clamp(position.y),
      labelPriority: node.current ? 3 : node.hasKnownChildren ? 2 : 1,
      knowledgeState: node.knowledgeState,
      current: node.current,
      selectable: true,
      hasKnownChildren: node.hasKnownChildren,
      visibleStatus: node.visibleStatus
    };
  });
  positionedNodes.push(...graph.boundaryNodes);

  const positionedEdges: MapEdgeDTO[] = graph.collapsedEdges.map((edge) => {
    const source = graph.publicNodeIdByCanonicalId.get(edge.sourceCanonicalId);
    const target = graph.publicNodeIdByCanonicalId.get(edge.targetCanonicalId);
    if (!source || !target) throw new Error(`hidden_edge_endpoint:${edge.canonicalId}`);
    const styleKey = styleForEdge(edge.displayType);
    return {
      id: edge.publicId,
      source,
      target,
      edgeType: edge.displayType,
      styleKey,
      markerKey: markerForEdge(edge.displayType),
      knowledgeState: edge.knowledgeState,
      traversalState: edge.traversalState,
      bendPoints: (graph.layout.edgeGeometry?.[edge.canonicalId] ?? []).map(cleanPoint),
      knownSummary: edge.knownSummary,
      directions: edge.reverse ? {
        forward: { traversalState: edge.traversalState, knownSummary: edge.knownSummary },
        reverse: { traversalState: edge.reverse.traversalState, knownSummary: edge.reverse.knownSummary }
      } : undefined
    };
  });
  positionedEdges.push(...graph.boundaryEdges);
  return { ...graph, positionedNodes, positionedEdges };
}
