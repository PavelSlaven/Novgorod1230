from __future__ import annotations
import csv, hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors = []
def err(x): errors.append(x)
def load(path):
    try: return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))
    except Exception as exc: err(f'json:{path}:{exc}'); return None
def rows(path):
    with (ROOT/path).open(encoding='utf-8-sig', newline='') as fh: return list(csv.DictReader(fh))
for p in ROOT.rglob('*.json'): load(p.relative_to(ROOT))
cl = load(Path('data/count-ledger.json'))
if cl:
    checks = {
        'data/canonical-node-compilation.csv': 227,
        'data/source-direction-ledger.csv': 716,
        'data/scene-profile-compilation.csv': 195,
        'data/g4-entry-endpoint-bindings.csv': 32,
        'data/route-context-links.csv': 56,
        'templates/route-chain-authoring.csv': 86,
        'templates/version-pin-resolution.csv': 48,
    }
    for path, count in checks.items():
        if len(rows(path)) != count: err(f'row-count:{path}:expected={count}')
    z = ROOT/'inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip'
    if hashlib.sha256(z.read_bytes()).hexdigest() != cl['p12_source_zip_sha256']: err('source-zip-digest')
st = load(Path('inputs/approved-scene-template-families.json'))
if st:
    for record in st['records']:
        if {x['slot_key'] for x in record['endpoint_slots']} != {'arrival','departure'}:
            err('scene-template-slots:' + record['id'])
src = load(Path('inputs/physical-exit-source-pairs.json'))
if src:
    allowed = {'intra_g4_site_connection_source','cross_g4_world_route_source','host_entry_site_connection_source','corridor_to_host_route_context_source','world_route_segment_context_source'}
    for pair in src['records']:
        if pair['target_mapping_kind'] not in allowed: err('unknown-source-kind:' + pair['physical_exit_pair_id'])
        if len(pair['directions']) != 2: err('direction-count:' + pair['physical_exit_pair_id'])
        else:
            a,b = pair['directions']
            if a['from'] != b['to'] or a['to'] != b['from']: err('reverse-mismatch:' + pair['physical_exit_pair_id'])
for p in [ROOT/'README.md', ROOT/'PLAN.md', *sorted((ROOT/'docs').glob('*.md')), *sorted((ROOT/'reports').glob('*.md'))]:
    text = p.read_text(encoding='utf-8')
    for token in ('TBD','TODO','FIXME','как-нибудь','и т. п. без определения'):
        if token in text: err('placeholder:' + str(p.relative_to(ROOT)) + ':' + token)
for req in [
    'scripts/validate_package.py','scripts/validate_json_schemas.py','scripts/semantic_audit.py','scripts/verify_reproducibility.py',
    'scripts/verify_manifest.py','scripts/verify_activation_evidence.py','scripts/run_all_checks.py',
    'templates/P27_SIGNED_AUDIT_EVIDENCE.template.json','templates/FRESH_CHECKOUT_EVIDENCE.template.json',
    'templates/P28_ACTIVATION_DECISION.template.json','templates/ACTIVATION_TRUST_STORE.template.json',
    'templates/version-pin-resolution.csv','data/reference-digests.json'
]:
    if not (ROOT/req).exists(): err('missing:' + req)
if errors:
    print(json.dumps({'result':'FAIL','errors':errors}, ensure_ascii=False, indent=2)); sys.exit(1)
print(json.dumps({'result':'PASS','counts':{'canonical_nodes':227,'source_directions':716,'scene_profiles':195,'entry_bindings':32,'context_links':56,'route_requests':86,'version_pin_rows':48},'errors':[]}, ensure_ascii=False, indent=2))
