# Historical audit: gn_nov_g1_xp017_yp025

Result: **PASS WITH NOTES**.

## Passed
- Activation is based on the approved lower-Dvina corridor and basin-scale tribute evidence.
- No settlement, church, monastery, fortification, estate, port or named landing is created.
- Tributary status is not upgraded to direct administration.
- Modern settlements and modern channel geometry are not projected into 1230.
- The GSHHS land/water proxy is explicitly prevented from erasing the internal river corridor.

## Notes
- Exact 1230 channels, banks, islands and occupation remain unknown.
- The package is a conservative functional reconstruction, not an exact topographic reconstruction.
