import { EDGE_LABELS } from "../../domain/catalog.js";
import type { MapViewDTO } from "../../domain/types.js";
import type { PositionedGraph } from "./internal.js";

export function buildMapViewDTO(graph: PositionedGraph): MapViewDTO {
  const usedStyles = [...new Set(graph.positionedEdges.map((edge) => edge.styleKey))];
  const currentPublicId = graph.publicNodeIdByCanonicalId.get(graph.request.currentNodeId);
  if (!currentPublicId) throw new Error("current_position_not_visible");
  return Object.freeze({
    layout: {
      id: graph.layout.id,
      level: graph.request.level,
      parentNodeId: graph.request.parentNodeId,
      version: graph.layout.version,
      widthRatio: 1,
      heightRatio: 1,
      status: graph.layout.status,
      qualityReport: graph.layout.qualityReport,
      semanticReview: graph.layout.semanticReview
    },
    breadcrumbs: graph.request.breadcrumbs,
    currentPosition: { nodeId: currentPublicId },
    nodes: graph.positionedNodes,
    edges: graph.positionedEdges,
    legend: usedStyles.map((key) => ({ key, label: EDGE_LABELS[key] ?? EDGE_LABELS.other!, kind: "edge" as const })),
    viewPermissions: {
      canZoomOut: graph.request.level !== "G1",
      canOpenParent: graph.request.level !== "G1",
      canOpenChildren: graph.positionedNodes.some((node) => node.hasKnownChildren)
    }
  });
}
