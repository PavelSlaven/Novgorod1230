# Connection-profile decision

The package approves 12 profiles: three same-G4 action profiles and nine cross-G4 segment profiles. Profiles are keyed by target scope and source edge type.

Local G5 transitions cost one local action. River, side-channel and land routes use versioned baseline minutes plus dynamic rechecks. A water/land transition uses the approved 15-minute shore-transfer time profile rather than an invented distance. It remains subject to bank, craft/landing, load, water and ice checks.

All bearings are topological ordered-endpoint orientations. No compass azimuth, exact medieval distance or measured historical duration is asserted. Minutes are gameplay calibration values. Unknown or failed availability checks block traversal; no fallback route is selected.
