import test from "node:test";
import assert from "node:assert/strict";
import { buildMapView } from "../dist/node.js";
import { baseInput } from "./helpers.mjs";

test("rumored and rough nodes never reveal canonical title, type, id, position or hidden children", () => {
  for (const state of ["rumored", "known_roughly", "doubtful"]) {
    const input = baseInput();
    input.nodes[1].title = "Точный тайный монастырский склад";
    input.nodes[1].nodeType = "monastery";
    input.layout.positions.b = { x: .91, y: .91 };
    input.nodeKnowledge[1] = { nodeId: "b", publicId: `opaque-${state}`, state, displayTitle: "Неясное место", displayIconKey: "generic_place", displayPosition: { x: .55, y: .45 }, knownChildMapAvailable: false };
    input.edgeKnowledge[0] = { edgeId: "ab", publicId: `edge-${state}`, state, displayType: "unknown_route", traversalState: "unknown" };
    input.edgeKnowledge[1] = { edgeId: "ba", publicId: `edge-back-${state}`, state, displayType: "unknown_route", traversalState: "unknown" };
    const view = buildMapView(input);
    const serialized = JSON.stringify(view);
    const node = view.nodes.find((item) => item.id === `opaque-${state}`);
    assert.equal(node.title, "Неясное место");
    assert.equal(node.iconKey, "generic_place");
    assert.equal(node.hasKnownChildren, false);
    assert.deepEqual({ x: node.x, y: node.y }, { x: .55, y: .45 });
    assert.ok(!serialized.includes("Точный тайный"));
    assert.ok(!serialized.includes("monastery"));
    assert.ok(!serialized.includes('"b"'));
  }
});

test("false belief is presented without revealing that it is false", () => {
  const input = baseInput();
  input.nodeKnowledge[1] = { nodeId: "b", publicId: "belief", state: "false_belief", presentationState: "known_exactly", displayTitle: "Мельница", displayIconKey: "workshop", displayPosition: { x: .4, y: .6 }, knownChildMapAvailable: false };
  const view = buildMapView(input);
  assert.equal(view.nodes.find((node) => node.id === "belief").knowledgeState, "known_exactly");
  assert.ok(!JSON.stringify(view).includes("false_belief"));
});
