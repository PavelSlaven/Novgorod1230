from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
actual=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name not in ('manifest.json','manifest.sha256'):
        actual.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
if actual!=m['files']:
    print('FAIL manifest mismatch'); raise SystemExit(1)
print('PASS verify_manifest',len(actual))
