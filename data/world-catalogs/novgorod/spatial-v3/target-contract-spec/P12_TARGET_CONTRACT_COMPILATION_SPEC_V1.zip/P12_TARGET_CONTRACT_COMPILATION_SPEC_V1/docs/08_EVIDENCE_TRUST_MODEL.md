# Evidence trust model

## Evidence is not a completed JSON shape

A file becomes admissible activation evidence only when all of the following hold:

1. It is bound to one exact 40-hex integration commit.
2. Every referenced payload, changed-file manifest, test manifest and compiled bundle has a verified SHA-256 digest.
3. The signer key is present exactly once in a repository-owned active trust store.
4. The trust-store role matches the evidence role: `p27_critic`, `fresh_checkout_attestor` or `p28_release_authority`.
5. The signature algorithm is `ed25519` and verification succeeds over canonical JSON with the signature field removed.
6. P28 binds the exact bytes of the P27 and fresh-checkout evidence files by SHA-256.
7. Revoked, unknown, duplicated or role-mismatched keys fail closed.

## Canonical signing payload

For P27 and fresh-checkout evidence, the signing payload is the whole JSON object with the top-level `signature` member removed. For P28 it is the whole object with `signed_by` removed. The remaining object is encoded as UTF-8 JSON with sorted keys and separators `,` and `:` and without ASCII escaping.

## Trust-root boundary

This archive deliberately contains only `ACTIVATION_TRUST_STORE.template.json` with no keys and status `template_not_trust_store`. It cannot validate or create a production signature. A real trust store must be supplied by the repository-owned release process and reviewed independently.

## Fail-closed command

```bash
python scripts/verify_activation_evidence.py P27.json FRESH.json P28.json --trust-store ACTIVE_TRUST_STORE.json
```

The bundled templates must return exit code `2` and `BLOCKED`. Structural completeness without cryptographic verification is never `PASS`.
