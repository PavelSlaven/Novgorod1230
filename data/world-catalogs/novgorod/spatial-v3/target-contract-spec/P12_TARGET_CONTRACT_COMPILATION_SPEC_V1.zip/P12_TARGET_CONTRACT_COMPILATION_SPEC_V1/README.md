# P12 target-contract compilation and P28 evidence specification

## Purpose

This archive defines the deterministic and fail-closed transition from the approved P12 source-level package to spatial-v3 target authoring contracts. It also defines the endpoint/profile DDL materialization boundary and a cryptographically verifiable P27/fresh-checkout/P28 evidence protocol.

It does **not** claim that the target contracts, DDL, importer, PostgreSQL rows, signatures or production activation already exist.

## Fixed source facts

- 32 migration host G4 records;
- 195 canonical G5 records;
- 358 bidirectional physical source pairs;
- 716 derived source directions;
- 600 source mappings = 242 hierarchy mappings + 358 physical pairs;
- 195 scene profiles and 195 single candidates across 17 scene-template families.

## Deterministic outputs in this archive

- 227 canonical-node compilation proposals;
- 716 typed source-direction ledger rows;
- 195 scene-profile compilation rows;
- 32 non-movement G4 entry endpoint bindings;
- 56 staging-only route-context links;
- 86 directed cross-G4 route authoring requests;
- proposed world-base authoring contracts for canonical G5 connections;
- typed gap ledger, authoring workbooks and evidence schemas.

## Non-negotiable blocks

Empty profile fields, unresolved version pins, missing route chains, absent signatures or unavailable trusted keys remain hard blocks. No value is inferred from titles, layout, nearest geometry, first row, plausibility or a fallback.

## Reproducible checks

```bash
python scripts/validate_package.py
python scripts/validate_json_schemas.py
python scripts/semantic_audit.py
python scripts/verify_reproducibility.py
python scripts/verify_manifest.py
python scripts/run_all_checks.py
```

`run_all_checks.py` expects the evidence-template test to return `BLOCKED` with exit code `2`; that negative result is part of a successful package check.

A real activation check requires a repository-owned active trust store:

```bash
python scripts/verify_activation_evidence.py P27.json FRESH.json P28.json --trust-store ACTIVE_TRUST_STORE.json
```

## Canonical-state limitation

The observed GitHub `main` commit during package preparation was `9f2a8c1477793e3baac376d558a64b1b2272cc4a`. That observed state did not expose the user-reported P12 integration. Therefore `canonical_integration_commit_unverified` remains a blocking gap in this standalone archive.

## Status

- Specification internal audit: `PASS`, open findings `0`.
- Source and derived-artifact validation: executable in this archive.
- Repository integration: not performed here.
- Independent critic: not invoked here.
- PostgreSQL materialization: not performed here.
- Production composition: unchanged.
- P28 activation: `BLOCKED`.
