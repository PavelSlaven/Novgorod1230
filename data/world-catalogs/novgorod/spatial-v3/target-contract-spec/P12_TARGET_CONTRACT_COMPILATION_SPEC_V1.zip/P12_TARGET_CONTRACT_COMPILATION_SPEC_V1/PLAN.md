# План работы

## Цель

Создать нулево-двусмысленную спецификацию перехода от P12 source approval к target spatial v3 authoring data и P28 activation evidence.

## Шаги

1. Зафиксировать source ZIP, digest, counts и ограничения canonical verification.
2. Разделить source count semantics и target logical row semantics.
3. Скомпилировать без новых смысловых решений canonical nodes, scene profiles, entry bindings и staging context links.
4. Определить отсутствующие world-base authoring contracts для canonical G5 connections.
5. Подготовить endpoint-profile и route-chain authoring workbooks без fallback/default values.
6. Описать DDL, importer, readback, rollback и no-mixing gates.
7. Описать криптографически проверяемые P27/fresh-checkout/P28 evidence contracts.
8. Выполнить циклы аудита до нуля замечаний по внутренней ясности пакета.

## Definition of Done пакета

- Все количества имеют однозначную семантику.
- Каждый source mapping class имеет ровно один target compilation class.
- Каждый нерешённый семантический параметр имеет typed gap и hard block.
- Нет утверждений о фактически не выполненной интеграции, подписи, PostgreSQL или fresh checkout.
- Все JSON/CSV/Markdown, digests и cross-references проходят локальную проверку.
