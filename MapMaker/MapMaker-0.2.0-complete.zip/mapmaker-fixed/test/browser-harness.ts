import { MapMaker } from "../src/ui/map-maker.js";
import type { MapViewDTO } from "../src/domain/types.js";

declare global {
  interface Window {
    renderMapFixture: () => void;
    fixtureReady?: boolean;
    knowledgeStyleApplied?: boolean;
    mapMaker?: MapMaker;
  }
}

window.renderMapFixture = () => {
  const view: MapViewDTO = {
    layout: { id: "fixture", level: "G4", parentNodeId: "parent", version: 2, widthRatio: 1, heightRatio: 1, status: "approved",
      qualityReport: { nodeOverlapCount: 0, minimumNodeDistance: .7, edgeCrossingCount: 0, labelCollisionCount: 0, boundaryExitConflictCount: 0, invalidCoordinateCount: 0, duplicateCoordinateCount: 0, missingGeometryCount: 0, totalEdgeBends: 2, aspectRatio: 1 },
      semanticReview: { required: true, decision: "approved", reviewerType: "llm", reviewerId: "fixture", reviewedAt: "2026-07-11T00:00:00Z", rationale: ["fixture"] } },
    breadcrumbs: [], currentPosition: { nodeId: "a" },
    nodes: [
      { id: "a", title: "Двор", iconKey: "yard", x: .2, y: .3, labelPriority: 3, knowledgeState: "visited", current: true, selectable: true, hasKnownChildren: false },
      { id: "b", title: "Мост", iconKey: "bridge", x: .8, y: .7, labelPriority: 2, knowledgeState: "known_roughly", current: false, selectable: true, hasKnownChildren: false, visibleStatus: { changed: true } }
    ],
    edges: [{ id: "ab", source: "a", target: "b", edgeType: "bridge", styleKey: "bridge", markerKey: "bridge", knowledgeState: "known_roughly", traversalState: "seasonal", bendPoints: [{ x: .2, y: .5 }, { x: .8, y: .5 }], knownSummary: "Известный мост" }],
    legend: [{ key: "bridge", label: "Мост", kind: "edge" }], viewPermissions: { canZoomOut: true, canOpenParent: true, canOpenChildren: false }
  };
  const map = new MapMaker(document.querySelector<HTMLElement>("#map")!, { mode: "full" });
  map.setView(view);
  window.mapMaker = map;
  window.knowledgeStyleApplied = Boolean((map as unknown as { cy?: import("cytoscape").Core }).cy?.getElementById("b").hasClass("knowledge-known_roughly"));
  window.fixtureReady = true;
};
