# Work plan and Definition of Done

1. Verify immutable source/specification digests.
2. Resolve target world and retained G2/G3 version graph.
3. Approve mechanical profile component registries and 12 connection profiles.
4. Compile 227 canonical nodes and 195 scene profiles.
5. Compile 454 same-G4 directed bindings and 86 cross-G4 route directions.
6. Resolve every one of the 716 source directions to an exact target class.
7. Define DDL authorization and P12 closure gates without granting production activation.
8. Run structural, referential, reciprocity, count, digest and semantic audits until zero findings.
