import test from "node:test";
import assert from "node:assert/strict";
import { createProductionMapViewHandler } from "../dist/node.js";
import { baseInput } from "./helpers.mjs";

function deps(identity, authorized = true) {
  return {
    authenticate: async () => identity,
    authorize: async () => authorized,
    loadMapInput: async () => baseInput()
  };
}

test("production API requires authentication and matching party/character authorization", async () => {
  let handler = createProductionMapViewHandler(deps(null));
  assert.equal((await handler(new Request("http://x/api/parties/p/map-view?level=G4&parentNodeId=parent"))).status, 401);
  handler = createProductionMapViewHandler(deps({ userId: "u", partyId: "p1", characterId: "c" }));
  assert.equal((await handler(new Request("http://x/api/parties/p2/map-view?level=G4&parentNodeId=parent"))).status, 403);
  handler = createProductionMapViewHandler(deps({ userId: "u", partyId: "p1", characterId: "c" }, false));
  assert.equal((await handler(new Request("http://x/api/parties/p1/map-view?level=G4&parentNodeId=parent"))).status, 403);
  handler = createProductionMapViewHandler(deps({ userId: "u", partyId: "p1", characterId: "c" }, true));
  assert.equal((await handler(new Request("http://x/api/parties/p1/map-view?level=G4&parentNodeId=parent"))).status, 200);
});
