import type { CanonicalEdge, CanonicalNode, LayoutQualityReport, Point } from "../domain/types.js";

const EPSILON = 1e-9;
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
const orientation = (a: Point, b: Point, c: Point) => Math.sign((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x));

function intersects(a: Point, b: Point, c: Point, d: Point): boolean {
  const o1 = orientation(a, b, c), o2 = orientation(a, b, d), o3 = orientation(c, d, a), o4 = orientation(c, d, b);
  return o1 !== o2 && o3 !== o4;
}

function edgeSegments(edge: CanonicalEdge, positions: Record<string, Point>, geometry: Record<string, Point[]>): Array<[Point, Point]> {
  const source = positions[edge.source], target = positions[edge.target];
  if (!source || !target) return [];
  const points = [source, ...(geometry[edge.id] ?? []), target];
  return points.slice(0, -1).map((point, index) => [point, points[index + 1]!] as [Point, Point]);
}

export function calculateLayoutQuality(
  nodes: CanonicalNode[],
  edges: CanonicalEdge[],
  positions: Record<string, Point>,
  edgeGeometry: Record<string, Point[]> = {},
  minimumAllowedDistance = 0.065,
  boundaryPositions: Record<string, Point> = {}
): LayoutQualityReport {
  let invalidCoordinateCount = 0, duplicateCoordinateCount = 0, nodeOverlapCount = 0;
  let minimumNodeDistance = nodes.length < 2 ? 1 : Number.POSITIVE_INFINITY;
  const seen = new Set<string>();
  for (const node of nodes) {
    const p = positions[node.id];
    if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < 0 || p.x > 1 || p.y < 0 || p.y > 1) {
      invalidCoordinateCount += 1;
      continue;
    }
    const key = `${p.x.toFixed(8)}:${p.y.toFixed(8)}`;
    if (seen.has(key)) duplicateCoordinateCount += 1;
    seen.add(key);
  }
  for (let i = 0; i < nodes.length; i += 1) {
    const a = positions[nodes[i]!.id]; if (!a) continue;
    for (let j = i + 1; j < nodes.length; j += 1) {
      const b = positions[nodes[j]!.id]; if (!b) continue;
      const d = distance(a, b); minimumNodeDistance = Math.min(minimumNodeDistance, d);
      if (d + EPSILON < minimumAllowedDistance) nodeOverlapCount += 1;
    }
  }
  let edgeCrossingCount = 0, missingGeometryCount = 0, totalEdgeBends = 0;
  const segments = edges.map((edge) => ({ edge, segments: edgeSegments(edge, positions, edgeGeometry) }));
  for (const item of segments) {
    if (!positions[item.edge.source] || !positions[item.edge.target]) missingGeometryCount += 1;
    totalEdgeBends += edgeGeometry[item.edge.id]?.length ?? 0;
  }
  for (let i = 0; i < segments.length; i += 1) {
    for (let j = i + 1; j < segments.length; j += 1) {
      const a = segments[i]!.edge, b = segments[j]!.edge;
      if (a.source === b.source || a.source === b.target || a.target === b.source || a.target === b.target) continue;
      if (segments[i]!.segments.some(([p1, p2]) => segments[j]!.segments.some(([q1, q2]) => intersects(p1, p2, q1, q2)))) edgeCrossingCount += 1;
    }
  }
  const boundaryValues = Object.values(boundaryPositions);
  let boundaryExitConflictCount = 0;
  for (let i = 0; i < boundaryValues.length; i += 1) for (let j = i + 1; j < boundaryValues.length; j += 1) {
    if (distance(boundaryValues[i]!, boundaryValues[j]!) < 0.035) boundaryExitConflictCount += 1;
  }
  const values = Object.values(positions);
  const xs = values.map((p) => p.x), ys = values.map((p) => p.y);
  const width = values.length ? Math.max(...xs) - Math.min(...xs) : 1;
  const height = values.length ? Math.max(...ys) - Math.min(...ys) : 1;
  return {
    nodeOverlapCount,
    minimumNodeDistance: Number.isFinite(minimumNodeDistance) ? minimumNodeDistance : 1,
    edgeCrossingCount,
    labelCollisionCount: 0,
    boundaryExitConflictCount,
    invalidCoordinateCount,
    duplicateCoordinateCount,
    missingGeometryCount,
    totalEdgeBends,
    aspectRatio: height > EPSILON ? width / height : 1
  };
}
