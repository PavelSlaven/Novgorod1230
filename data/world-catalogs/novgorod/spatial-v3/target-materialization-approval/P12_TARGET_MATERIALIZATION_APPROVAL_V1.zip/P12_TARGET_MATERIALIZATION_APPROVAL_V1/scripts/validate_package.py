from pathlib import Path
import csv, hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def fail(msg): print('FAIL:',msg); raise SystemExit(1)
inputs=load('inputs/input-digests.json')
for key,rel in [('target_contract_spec_zip','inputs/P12_TARGET_CONTRACT_COMPILATION_SPEC_V1.zip'),('embedded_source_approval_zip','inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip')]:
    got=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
    if got!=inputs[key]['sha256']: fail(f'{key} digest {got}')
counts=load('APPROVAL_DECISION.json')['counts']
files={
 'canonical_nodes_total':('data/approved-canonical-node-compilation.json',227),
 'scene_profiles':('data/approved-scene-profiles.json',195),
 'connection_profiles':('data/approved-connection-profiles.json',12),
 'canonical_g5_connection_bindings_directed':('data/approved-canonical-g5-connection-bindings.json',454),
 'g4_entry_bindings_non_movement':('data/approved-g4-entry-endpoint-bindings.json',32),
 'staging_route_context_links':('data/approved-route-context-links.json',56),
 'g4_directional_exits':('data/approved-g4-directional-exits.json',86),
 'world_routes_directed':('data/approved-world-routes.json',86),
 'world_route_points':('data/approved-world-route-points.json',172),
 'world_route_segments':('data/approved-world-route-segments.json',86),
 'world_route_endpoint_bindings':('data/approved-world-route-endpoint-bindings.json',172),
 'source_directions':('data/direction-resolution-ledger.json',716)}
for key,(p,n) in files.items():
    rows=load(p)['records']
    if len(rows)!=n or counts[key]!=n: fail(f'{key}: {len(rows)} / {counts[key]} expected {n}')
def canon_sha(row):
    return hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()
for rel in ['data/approved-connection-profiles.json','data/approved-canonical-g5-connection-bindings.json','data/approved-world-routes.json']:
    for row in load(rel)['records']:
        expected=row.get('content_digest')
        if not expected or expected!=canon_sha({k:v for k,v in row.items() if k!='content_digest'}): fail(rel+' content_digest '+str(row.get('id')))
profiles=load('data/approved-connection-profiles.json')['records']
for p in profiles:
    if p['status']!='approved': fail('profile not approved')
    if p['cost_kind']=='action':
        if not p['action_units'] or any(p[x] is not None for x in ['baseline_movement_method_ref','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref']): fail('action/time XOR')
    elif p['cost_kind']=='time':
        if p['action_units'] is not None or any(p[x] is None for x in ['baseline_movement_method_ref','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref']): fail('time/action XOR')
    else: fail('unknown cost kind')
routes=load('data/approved-world-routes.json')['records']; rmap={r['id']+'@'+r['version']:r for r in routes}
for r in routes:
    if len(r['ordered_point_refs'])!=2 or len(r['ordered_segment_refs'])!=1: fail('route chain cardinality')
    rev=rmap.get(r['reverse_route_ref'])
    if not rev or rev['reverse_route_ref']!=r['id']+'@'+r['version'] or rev['from_canonical_g5_ref']!=r['to_canonical_g5_ref'] or rev['to_canonical_g5_ref']!=r['from_canonical_g5_ref']: fail('route reciprocity')
binds=load('data/approved-canonical-g5-connection-bindings.json')['records']; bmap={r['id']+'@'+r['version']:r for r in binds}
for b in binds:
    rev=bmap.get(b['reverse_binding_ref'])
    if not rev or rev['reverse_binding_ref']!=b['id']+'@'+b['version'] or rev['from_canonical_g5_ref']!=b['to_canonical_g5_ref']: fail('binding reciprocity')
res=load('data/direction-resolution-ledger.json')['records']
if any(r['resolution_status']!='approved_resolved' or r['blocking_gap_code'] for r in res): fail('unresolved direction')
if load('data/p28-production-activation-status.json')['status']!='BLOCKED': fail('P28 must remain blocked')
print('PASS validate_package')
