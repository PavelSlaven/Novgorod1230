# DDL contract matrix

`data/ddl-contract-matrix.json` lists every normalized contract, approved row file, expected count and mandatory constraints. Physical table and migration names are deliberately not invented: they must be reconciled with the exact existing P12 branch DDL.

DDL implementation is rejected if it flattens versioned identities, stores route chains as opaque JSON without relational constraints, exposes staging context to runtime roles, omits segment spatial context, permits action fields on world-route segments, resolves bare IDs through latest/first-row queries, or permits nonreciprocal records where this bundle declares reciprocity.
