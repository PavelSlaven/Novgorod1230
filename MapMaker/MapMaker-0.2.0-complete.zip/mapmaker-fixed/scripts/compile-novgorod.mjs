import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ELK from "elkjs/lib/elk.bundled.js";
import { calculateLayoutQuality } from "../dist/node.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.resolve(here, "..");
const defaultSource = path.resolve(packageRoot, "source_tsv");
const sourceDir = path.resolve(process.argv.find((arg) => arg.startsWith("--source="))?.slice(9) ?? defaultSource);
const outputDir = path.resolve(process.argv.find((arg) => arg.startsWith("--output="))?.slice(9) ?? path.join(packageRoot, "private-generated", "server"));
const reviewPath = path.resolve(process.argv.find((arg) => arg.startsWith("--semantic-review="))?.slice(18) ?? path.join(packageRoot, "config", "novgorod-semantic-review-v1.json"));
const useElk = !process.argv.includes("--fast");
const elk = new ELK();

function parseTsv(text) {
  const [headerLine, ...lines] = text.replace(/^\uFEFF/, "").trimEnd().split(/\r?\n/);
  const headers = headerLine.split("\t");
  return lines.filter(Boolean).map((line) => Object.fromEntries(line.split("\t").map((value, index) => [headers[index], value])));
}

const safeName = (value) => value.replace(/[^a-zA-Z0-9_.-]/g, "_");
const clamp = (value, min = .02, max = .98) => Math.min(max, Math.max(min, value));
const numberOrUndefined = (value) => value === "" || value === undefined ? undefined : Number(value);
function hash(value) { let result = 2166136261; for (const char of value) result = Math.imul(result ^ char.charCodeAt(0), 16777619); return result >>> 0; }

function g1Layout(nodes) {
  const valid = nodes.map((node) => ({ node, x: numberOrUndefined(node.grid_x), y: numberOrUndefined(node.grid_y) }));
  if (valid.some((item) => !Number.isFinite(item.x) || !Number.isFinite(item.y))) throw new Error("g1_grid_coordinates_missing");
  const xs = valid.map((item) => item.x), ys = valid.map((item) => item.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  return Object.fromEntries(valid.map(({ node, x, y }) => [node.id, {
    x: .05 + .9 * (x - minX) / Math.max(1, maxX - minX),
    y: .05 + .9 * (maxY - y) / Math.max(1, maxY - minY)
  }]));
}

function fastRawLayout(nodes) {
  const columns = Math.ceil(Math.sqrt(nodes.length));
  return Object.fromEntries(nodes.map((node, index) => [node.id, {
    x: index % columns,
    y: Math.floor(index / columns)
  }]));
}

async function elkRawLayout(nodes, edges) {
  const result = await elk.layout({
    id: "root",
    layoutOptions: {
      "elk.algorithm": "layered",
      "elk.direction": "DOWN",
      "elk.edgeRouting": "ORTHOGONAL",
      "elk.aspectRatio": "1.0",
      "elk.spacing.nodeNode": "48",
      "elk.layered.spacing.nodeNodeBetweenLayers": "64",
      "elk.layered.crossingMinimization.strategy": "LAYER_SWEEP"
    },
    children: nodes.map((node) => ({ id: node.id, width: 44, height: 44 })),
    edges: edges.map((edge) => ({ id: edge.id, sources: [edge.source], targets: [edge.target] }))
  });
  return Object.fromEntries((result.children ?? []).map((node) => [node.id, { x: node.x ?? 0, y: node.y ?? 0 }]));
}

function collisionFreeSquare(nodes, rawPositions) {
  if (nodes.length === 1) return { [nodes[0].id]: { x: .5, y: .5 } };
  const sorted = [...nodes].sort((a, b) => {
    const pa = rawPositions[a.id] ?? { x: 0, y: 0 }, pb = rawPositions[b.id] ?? { x: 0, y: 0 };
    return pa.y - pb.y || pa.x - pb.x || a.id.localeCompare(b.id);
  });
  const columns = Math.ceil(Math.sqrt(sorted.length));
  const rows = Math.ceil(sorted.length / columns);
  return Object.fromEntries(sorted.map((node, index) => {
    const column = index % columns, row = Math.floor(index / columns);
    return [node.id, {
      x: columns === 1 ? .5 : .12 + .76 * column / (columns - 1),
      y: rows === 1 ? .5 : .12 + .76 * row / (rows - 1)
    }];
  }));
}

function collapseReverseEdges(edges) {
  const byId = new Map(edges.map((edge) => [edge.id, edge]));
  const consumed = new Set();
  const result = [];
  for (const edge of edges.sort((a, b) => a.id.localeCompare(b.id))) {
    if (consumed.has(edge.id)) continue;
    const reverse = edge.reverseEdgeId ? byId.get(edge.reverseEdgeId) : undefined;
    consumed.add(edge.id);
    if (reverse && reverse.edgeType === edge.edgeType) consumed.add(reverse.id);
    result.push({ ...edge, reverseId: reverse?.id });
  }
  return result;
}

function routeGeometry(edges, positions) {
  const geometry = {};
  for (const edge of edges) {
    const source = positions[edge.source], target = positions[edge.target];
    if (!source || !target || Math.abs(source.x - target.x) < .001 || Math.abs(source.y - target.y) < .001) {
      geometry[edge.id] = [];
      continue;
    }
    const middleY = (source.y + target.y) / 2;
    geometry[edge.id] = [{ x: source.x, y: middleY }, { x: target.x, y: middleY }];
  }
  return geometry;
}

function determineBoundarySide(internalNode, externalNode, nodeById) {
  const internalRoot = nodeById.get(internalNode.root_g1_id || internalNode.id);
  const externalRoot = nodeById.get(externalNode.root_g1_id || externalNode.id);
  const ix = numberOrUndefined(internalRoot?.grid_x), iy = numberOrUndefined(internalRoot?.grid_y);
  const ex = numberOrUndefined(externalRoot?.grid_x), ey = numberOrUndefined(externalRoot?.grid_y);
  if ([ix, iy, ex, ey].every(Number.isFinite) && (ix !== ex || iy !== ey)) {
    const dx = ex - ix, dy = ey - iy;
    if (Math.abs(dx) >= Math.abs(dy)) return dx >= 0 ? "east" : "west";
    return dy >= 0 ? "north" : "south";
  }
  return ["north", "east", "south", "west"][hash(`${internalNode.id}:${externalNode.id}`) % 4];
}

function buildBoundaryExits(groupNodes, allPhysicalEdges, nodeById) {
  const ids = new Set(groupNodes.map((node) => node.id));
  const groupLevel = groupNodes[0]?.scale_level;
  const crossing = allPhysicalEdges.filter((edge) => {
    if (ids.has(edge.source) === ids.has(edge.target)) return false;
    const sourceNode = nodeById.get(edge.source);
    const targetNode = nodeById.get(edge.target);
    return sourceNode?.scale_level === groupLevel && targetNode?.scale_level === groupLevel;
  });
  const pairs = collapseReverseEdges(crossing);
  return pairs.map((edge) => {
    const sourceInside = ids.has(edge.source);
    const internalId = sourceInside ? edge.source : edge.target;
    const externalId = sourceInside ? edge.target : edge.source;
    const internalNode = nodeById.get(internalId), externalNode = nodeById.get(externalId);
    return {
      id: `boundary:${[edge.id, edge.reverseId].filter(Boolean).sort().join("~")}`,
      edgeIds: [edge.id, edge.reverseId].filter(Boolean),
      sourceNodeId: internalId,
      externalNodeId: externalId,
      side: determineBoundarySide(internalNode, externalNode, nodeById),
      edgeType: edge.edgeType
    };
  });
}

function boundaryPositions(exits) {
  const bySide = new Map([["north", []], ["east", []], ["south", []], ["west", []]]);
  for (const exit of exits) bySide.get(exit.side).push(exit);
  const result = {};
  for (const [side, values] of bySide) {
    values.sort((a, b) => a.id.localeCompare(b.id));
    values.forEach((exit, index) => {
      const t = (index + 1) / (values.length + 1);
      result[exit.id] = side === "north" ? { x: t, y: .02 }
        : side === "south" ? { x: t, y: .98 }
        : side === "west" ? { x: .02, y: t }
        : { x: .98, y: t };
    });
  }
  return result;
}

function boundaryGeometry(exits, positions, boundary) {
  const result = {};
  for (const exit of exits) {
    const source = positions[exit.sourceNodeId], target = boundary[exit.id];
    if (!source || !target) continue;
    result[exit.id] = Math.abs(source.x - target.x) < .001 || Math.abs(source.y - target.y) < .001
      ? [] : [{ x: target.x, y: source.y }];
  }
  return result;
}

function semanticRequired(group, internalEdges) {
  return group.level === "G1" || group.level === "G2" || group.nodes.length >= 25 || internalEdges.some((edge) => ["river", "lake_route", "bridge", "ford", "ferry"].includes(edge.edgeType));
}

function layoutProfile(group, internalEdges) {
  if (group.level === "G1") return "g1_grid";
  if (internalEdges.some((edge) => ["river", "lake_route", "bridge", "ford", "ferry"].includes(edge.edgeType))) return "water_corridor";
  if (group.nodes.length >= 25) return "urban";
  if (group.nodes.length <= 8) return "radial";
  return "settlement";
}

const nodesPath = path.join(sourceDir, "novgorod_graph_nodes_g1_g4_full_v6.tsv");
const edgesPath = path.join(sourceDir, "novgorod_graph_edges_g1_g4_full_v6.tsv");
const metadataPath = path.join(sourceDir, "novgorod_graph_node_layout_metadata_v1.tsv");
const [nodeRows, edgeRows, metadataRows, reviewPolicy] = await Promise.all([
  readFile(nodesPath, "utf8").then(parseTsv),
  readFile(edgesPath, "utf8").then(parseTsv),
  readFile(metadataPath, "utf8").then(parseTsv),
  readFile(reviewPath, "utf8").then(JSON.parse)
]);
const metadataById = new Map(metadataRows.map((row) => [row.id, row]));
const nodes = nodeRows.map((node) => {
  const metadata = metadataById.get(node.id) ?? {};
  return { ...node, ...metadata, gridX: numberOrUndefined(metadata.grid_x), gridY: numberOrUndefined(metadata.grid_y) };
});
const physicalEdges = edgeRows.filter((edge) => edge.edge_type !== "contains").map((edge) => ({
  id: edge.id,
  reverseEdgeId: edge.reverse_edge_id || undefined,
  source: edge.from_node_id,
  target: edge.to_node_id,
  edgeType: edge.edge_type
}));
const nodeById = new Map(nodes.map((node) => [node.id, node]));
const groups = new Map();
for (const node of nodes) {
  const parent = node.scale_level === "G1" ? "novgorod-region" : node.parent_node_id;
  if (!parent) continue;
  const key = `${node.scale_level}:${parent}`;
  if (!groups.has(key)) groups.set(key, { parent, level: node.scale_level, nodes: [] });
  groups.get(key).nodes.push(node);
}

await rm(outputDir, { recursive: true, force: true });
await mkdir(outputDir, { recursive: true });
const manifest = { formatVersion: 2, source: path.basename(sourceDir), generatedAt: new Date().toISOString(), semanticReviewId: reviewPolicy.reviewId, layouts: [] };
const audit = { nodes: nodes.length, physicalEdges: physicalEdges.length, internalVisualEdges: 0, boundaryExits: 0, layouts: 0, approved: 0, geometryFailed: 0, overlapLayouts: [], invalidLayouts: [] };
let completed = 0;
for (const group of [...groups.values()].sort((a, b) => `${a.level}:${a.parent}`.localeCompare(`${b.level}:${b.parent}`))) {
  const ids = new Set(group.nodes.map((node) => node.id));
  const directedInternalEdges = physicalEdges.filter((edge) => ids.has(edge.source) && ids.has(edge.target));
  const layoutEdges = collapseReverseEdges(directedInternalEdges);
  const exits = buildBoundaryExits(group.nodes, physicalEdges, nodeById);
  const raw = group.level === "G1" ? undefined : useElk ? await elkRawLayout(group.nodes, layoutEdges) : fastRawLayout(group.nodes);
  const positions = group.level === "G1" ? g1Layout(group.nodes) : collisionFreeSquare(group.nodes, raw);
  const boundary = boundaryPositions(exits);
  const edgeGeometry = { ...routeGeometry(layoutEdges, positions), ...boundaryGeometry(exits, positions, boundary) };
  const quality = calculateLayoutQuality(
    group.nodes.map((node) => ({ id: node.id, parentNodeId: group.parent, level: node.scale_level, title: node.title, nodeType: node.node_type })),
    layoutEdges,
    positions,
    edgeGeometry,
    .065,
    boundary
  );
  const required = semanticRequired(group, layoutEdges);
  const semanticReview = {
    required,
    decision: reviewPolicy.decision,
    reviewerType: reviewPolicy.reviewerType,
    reviewerId: reviewPolicy.reviewerId,
    reviewedAt: reviewPolicy.reviewedAt,
    rationale: [...reviewPolicy.rationale, `Layout ${group.level}:${group.parent} uses only authored graph entities and profile ${layoutProfile(group, layoutEdges)}.`]
  };
  const geometryPass = quality.nodeOverlapCount === 0 && quality.invalidCoordinateCount === 0 && quality.duplicateCoordinateCount === 0 && quality.boundaryExitConflictCount === 0;
  const status = geometryPass && (!required || semanticReview.decision === "approved") ? "approved" : geometryPass ? "needs_semantic_review" : "geometry_failed";
  const payload = {
    parentNodeId: group.parent,
    level: group.level,
    nodes: group.nodes.map((node) => ({
      id: node.id,
      parentNodeId: group.parent,
      level: node.scale_level,
      title: node.title,
      nodeType: node.node_type,
      gridX: numberOrUndefined(node.grid_x),
      gridY: numberOrUndefined(node.grid_y)
    })),
    edges: directedInternalEdges,
    boundaryExits: exits,
    layout: {
      id: `novgorod:${group.level}:${group.parent}:v2`,
      parentNodeId: group.parent,
      level: group.level,
      version: 2,
      profile: layoutProfile(group, layoutEdges),
      status,
      positions,
      boundaryPositions: boundary,
      edgeGeometry,
      qualityReport: quality,
      semanticReview
    }
  };
  const relative = path.join(group.level, `${safeName(group.parent)}.json`);
  await mkdir(path.join(outputDir, group.level), { recursive: true });
  await writeFile(path.join(outputDir, relative), JSON.stringify(payload));
  manifest.layouts.push({
    parentNodeId: group.parent,
    parentTitle: group.parent === "novgorod-region" ? "Новгородская земля" : nodeById.get(group.parent)?.title ?? group.parent,
    level: group.level,
    file: relative.replaceAll("\\", "/"),
    nodeCount: group.nodes.length,
    edgeCount: directedInternalEdges.length,
    boundaryExitCount: exits.length,
    status,
    qualityReport: quality
  });
  audit.layouts += 1;
  audit.internalVisualEdges += layoutEdges.length;
  audit.boundaryExits += exits.length;
  if (status === "approved") audit.approved += 1; else audit.geometryFailed += 1;
  if (quality.nodeOverlapCount) audit.overlapLayouts.push({ level: group.level, parentNodeId: group.parent, count: quality.nodeOverlapCount });
  if (quality.invalidCoordinateCount || quality.duplicateCoordinateCount || quality.boundaryExitConflictCount) audit.invalidLayouts.push({ level: group.level, parentNodeId: group.parent, quality });
  completed += 1;
  if (completed % 100 === 0) process.stdout.write(`Compiled ${completed}/${groups.size}\r`);
}
await writeFile(path.join(outputDir, "manifest.json"), JSON.stringify(manifest, null, 2));
await writeFile(path.join(outputDir, "AUDIT_REPORT.json"), JSON.stringify(audit, null, 2));
if (audit.approved !== audit.layouts || audit.overlapLayouts.length || audit.invalidLayouts.length) throw new Error(`novgorod_compile_quality_failed:${JSON.stringify(audit)}`);
console.log(`Compiled and approved ${audit.layouts} local maps (${nodes.length} nodes, ${physicalEdges.length} physical directed edges, ${audit.boundaryExits} boundary exits).`);
console.log(`Output: ${outputDir}`);
