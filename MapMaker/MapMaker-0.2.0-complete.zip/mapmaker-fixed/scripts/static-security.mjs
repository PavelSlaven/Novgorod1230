import path from "node:path";

function decodeSafely(value) {
  let decoded = value;
  for (let i = 0; i < 3; i += 1) {
    let next;
    try { next = decodeURIComponent(decoded); } catch { return null; }
    if (next === decoded) break;
    decoded = next;
  }
  return decoded;
}

export function resolveInsideRoot(root, requestPath) {
  const decoded = decodeSafely(requestPath);
  if (decoded === null || decoded.includes("\0") || decoded.includes("\\")) return null;
  const normalized = decoded.replace(/^\/+/, "");
  const segments = normalized.split("/");
  if (segments.some((segment) => segment === "" || segment === "." || segment === "..")) return null;
  const resolvedRoot = path.resolve(root);
  const resolved = path.resolve(resolvedRoot, ...segments);
  const relative = path.relative(resolvedRoot, resolved);
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) return null;
  return resolved;
}

export function selectStaticRoot(root, pathname, allowedRoots) {
  const decoded = decodeSafely(pathname);
  if (decoded === null || decoded.includes("\0") || decoded.includes("\\")) return null;
  const relative = decoded.replace(/^\/+/, "");
  const first = relative.split("/")[0];
  if (!allowedRoots.includes(first)) return null;
  const staticRoot = path.resolve(root, first);
  const remainder = relative.slice(first.length).replace(/^\/+/, "");
  if (!remainder) return null;
  return resolveInsideRoot(staticRoot, remainder);
}
