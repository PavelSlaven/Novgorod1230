from __future__ import annotations
import csv, json, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
findings = []
def finding(code, detail): findings.append({'code': code, 'detail': detail})
def load_json(path): return json.loads((ROOT / path).read_text(encoding='utf-8-sig'))
def load_csv(path):
    with (ROOT / path).open(encoding='utf-8-sig', newline='') as fh:
        return list(csv.DictReader(fh))
def unique(values, code):
    values = list(values)
    if len(values) != len(set(values)): finding(code, 'duplicates detected')

g4s = load_json('inputs/g4-host-sectors.json')['records']
g5s = load_json('inputs/canonical-g5-inventory.json')['records']
pairs = load_json('inputs/physical-exit-source-pairs.json')['records']
profiles = load_json('inputs/scene-materialization-profiles.json')['records']
candidates = load_json('inputs/scene-materialization-candidates.json')['records']
assignments = load_json('inputs/scene-profile-assignments.json')['records']
templates = load_json('inputs/approved-scene-template-families.json')['records']

unique((r['id'] for r in g4s), 'duplicate_g4_id')
unique((r['id'] for r in g5s), 'duplicate_g5_id')
unique((r['physical_exit_pair_id'] for r in pairs), 'duplicate_pair_id')
unique((d['direction_id'] for p in pairs for d in p['directions']), 'duplicate_direction_id')

g4_by_id = {r['id']: r for r in g4s}
g5_by_id = {r['id']: r for r in g5s}
for g5 in g5s:
    if g5['parent_g4_id'] not in g4_by_id:
        finding('g5_parent_missing', g5['id'])

class_counts = Counter(p['target_mapping_kind'] for p in pairs)
expected_counts = {
    'intra_g4_site_connection_source': 227,
    'cross_g4_world_route_source': 43,
    'host_entry_site_connection_source': 32,
    'corridor_to_host_route_context_source': 32,
    'world_route_segment_context_source': 24,
}
if dict(class_counts) != expected_counts:
    finding('source_class_count_mismatch', {'actual': dict(class_counts), 'expected': expected_counts})

def resolve_g5(endpoint):
    if endpoint.get('kind') == 'canonical_g5': return endpoint.get('id', '')
    if endpoint.get('kind') == 'retained_g3_with_host_g4': return endpoint.get('entry_canonical_g5_id', '')
    return ''

for pair in pairs:
    kind = pair['target_mapping_kind']
    if len(pair['directions']) != 2:
        finding('pair_not_bidirectional', pair['physical_exit_pair_id'])
        continue
    a, b = pair['directions']
    if a['from'] != b['to'] or a['to'] != b['from']:
        finding('pair_reverse_mismatch', pair['physical_exit_pair_id'])
    if kind == 'intra_g4_site_connection_source':
        ids = [resolve_g5(pair['source_from']), resolve_g5(pair['source_to'])]
        if not all(i in g5_by_id for i in ids):
            finding('intra_endpoint_missing', {'pair': pair['physical_exit_pair_id'], 'ids': ids})
        elif g5_by_id[ids[0]]['parent_g4_id'] != g5_by_id[ids[1]]['parent_g4_id']:
            finding('intra_parent_mismatch', pair['physical_exit_pair_id'])
    elif kind == 'cross_g4_world_route_source':
        ids = [resolve_g5(pair['source_from']), resolve_g5(pair['source_to'])]
        if not all(i in g5_by_id for i in ids):
            finding('route_endpoint_missing', {'pair': pair['physical_exit_pair_id'], 'ids': ids})
        elif g5_by_id[ids[0]]['parent_g4_id'] == g5_by_id[ids[1]]['parent_g4_id']:
            finding('route_not_cross_g4', pair['physical_exit_pair_id'])
    elif kind == 'host_entry_site_connection_source':
        endpoints = [pair['source_from'], pair['source_to']]
        host = next((x for x in endpoints if x.get('kind') == 'retained_g3_with_host_g4'), None)
        local = next((x for x in endpoints if x.get('kind') == 'canonical_g5'), None)
        if not host or not local:
            finding('entry_endpoint_shape_invalid', pair['physical_exit_pair_id'])
        else:
            if host.get('entry_canonical_g5_id') != local.get('id'):
                finding('entry_g5_mismatch', pair['physical_exit_pair_id'])
            gid = local.get('id')
            if gid not in g5_by_id or g5_by_id[gid]['parent_g4_id'] != host.get('host_g4_id'):
                finding('entry_parent_mismatch', pair['physical_exit_pair_id'])

entry_rows = load_csv('data/g4-entry-endpoint-bindings.csv')
unique((r['g4_id'] for r in entry_rows), 'duplicate_entry_binding_g4')
for r in entry_rows:
    gid = r['canonical_g5_id']
    if gid not in g5_by_id or g5_by_id[gid]['parent_g4_id'] != r['g4_id']:
        finding('compiled_entry_parent_mismatch', r['id'])

profile_by_id = {r['id']: r for r in profiles}
if len(profile_by_id) != 195: finding('profile_identity_count', len(profile_by_id))
candidates_by_profile = defaultdict(list)
for c in candidates: candidates_by_profile[(c['profile_id'], c['profile_version'])].append(c)
template_refs = {f"{r['id']}@{r['version']}" for r in templates}
for p in profiles:
    expected_ref = p['source_ref'].split('@')[0]
    if expected_ref not in g5_by_id:
        finding('profile_source_g5_missing', p['id'])
    cs = candidates_by_profile[(p['id'], p['version'])]
    if len(cs) != 1:
        finding('profile_candidate_cardinality', {'profile': p['id'], 'count': len(cs)})
    elif cs[0]['scene_template_ref'] not in template_refs:
        finding('candidate_template_missing', cs[0]['scene_template_ref'])
for t in templates:
    slots = {x['slot_key'] for x in t['endpoint_slots']}
    if slots != {'arrival', 'departure'}:
        finding('template_endpoint_slots', {'template': t['id'], 'slots': sorted(slots)})

assignment_by_g5 = {r['canonical_g5_id']: r for r in assignments}
if set(assignment_by_g5) != set(g5_by_id):
    finding('assignment_g5_coverage', {'missing': sorted(set(g5_by_id)-set(assignment_by_g5))[:10], 'extra': sorted(set(assignment_by_g5)-set(g5_by_id))[:10]})
for gid, a in assignment_by_g5.items():
    if a['scene_profile_ref'].split('@')[0] not in profile_by_id:
        finding('assignment_profile_missing', gid)
    if a['scene_template_ref'] not in template_refs:
        finding('assignment_template_missing', gid)

route_rows = load_csv('templates/route-chain-authoring.csv')
route_by_id = {r['route_request_id']: r for r in route_rows}
if len(route_by_id) != 86: finding('route_request_identity_count', len(route_by_id))
for r in route_rows:
    if r['from_canonical_g5_id'] not in g5_by_id or r['to_canonical_g5_id'] not in g5_by_id:
        finding('compiled_route_endpoint_missing', r['route_request_id'])
    elif g5_by_id[r['from_canonical_g5_id']]['parent_g4_id'] == g5_by_id[r['to_canonical_g5_id']]['parent_g4_id']:
        finding('compiled_route_not_cross_g4', r['route_request_id'])
    rev = route_by_id.get(r['reverse_route_request_id'])
    if not rev:
        finding('route_reverse_missing', r['route_request_id'])
    elif rev['reverse_route_request_id'] != r['route_request_id'] or rev['from_canonical_g5_id'] != r['to_canonical_g5_id'] or rev['to_canonical_g5_id'] != r['from_canonical_g5_id']:
        finding('route_reverse_not_reciprocal', r['route_request_id'])

pins = load_csv('templates/version-pin-resolution.csv')
pin_counts = Counter(r['entity_kind'] for r in pins)
if pin_counts != Counter({'world_revision': 1, 'canonical_g2': 15, 'canonical_g3': 32}):
    finding('version_pin_count_mismatch', dict(pin_counts))

result = {
    'schema_version': 'rus.p12_target_semantic_audit.v1',
    'result': 'PASS' if not findings else 'FAIL',
    'open_findings': len(findings),
    'checked_counts': {
        'host_g4': len(g4s), 'canonical_g5': len(g5s), 'physical_pairs': len(pairs),
        'source_directions': sum(len(p['directions']) for p in pairs), 'scene_profiles': len(profiles),
        'route_requests': len(route_rows), 'version_pin_rows': len(pins),
    },
    'findings': findings,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(0 if not findings else 1)
