# DDL materialization requirements

## Physical projection

Branch DDL обязан иметь нормализованные таблицы либо доказанно эквивалентную структуру для:

- canonical spatial node versions;
- scene materialization profiles/candidates;
- canonical G5 connection profiles/bindings;
- G4 entry endpoint bindings;
- G4 traversal profiles and directional exits;
- world routes, points, segments, endpoint bindings and segment contexts;
- authoring dependency edges and provenance;
- immutable import/run manifests and readiness gaps.

## Constraints

- `(id, version)` immutable identity for authoring rows.
- FK/version graph compatibility; no bare latest lookup.
- One approved scene profile per endpoint-capable canonical G5.
- Same-parent-G4 constraint for canonical G5 connection binding.
- Reciprocal reverse constraints.
- Action/time XOR.
- Route point/segment ordinal continuity.
- Exactly one from and one to endpoint binding per approved route.
- Approved route departure requires approved directional exit.
- Staging context tables denied to runtime role.

## Migration order

```text
profiles and registries
→ canonical G4/G5 nodes
→ scene templates/profiles/candidates
→ entry bindings
→ connection profiles/bindings
→ traversal profiles/directional exits
→ routes/points/segments/contexts/endpoints
→ readiness report
```

No migration may mark rows approved when referenced profile/chain is absent. Schema reference must be regenerated from actual DDL and digest-checked.
