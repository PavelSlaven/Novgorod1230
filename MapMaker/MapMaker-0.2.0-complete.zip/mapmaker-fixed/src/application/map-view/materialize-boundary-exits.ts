import { markerForEdge, styleForEdge } from "../../domain/catalog.js";
import type { EdgeKnowledgeState, MapEdgeDTO, MapNodeDTO } from "../../domain/types.js";
import type { BoundaryGraph, VisibleGraph } from "./internal.js";

const rank: Record<EdgeKnowledgeState, number> = { traversed: 5, known_exactly: 4, known_roughly: 3, rumored: 2, doubtful: 1 };

export function materializeBoundaryExits(graph: VisibleGraph): BoundaryGraph {
  const edgeKnowledge = new Map(graph.edgeKnowledge.map((item) => [item.edgeId, item]));
  const boundaryNodes: MapNodeDTO[] = [];
  const boundaryEdges: MapEdgeDTO[] = [];
  for (const exit of graph.boundaryExits) {
    const candidates = exit.edgeIds.map((id) => edgeKnowledge.get(id)).filter((item): item is NonNullable<typeof item> => Boolean(item));
    if (candidates.length === 0) continue;
    const sourcePublicId = graph.publicNodeIdByCanonicalId.get(exit.sourceNodeId);
    if (!sourcePublicId) continue;
    candidates.sort((a, b) => rank[(b.state === "false_belief" ? b.presentationState ?? "known_roughly" : b.state)] - rank[(a.state === "false_belief" ? a.presentationState ?? "known_roughly" : a.state)]);
    const knowledge = candidates[0]!;
    const presentation = knowledge.state === "false_belief" ? knowledge.presentationState ?? "known_roughly" : knowledge.state;
    const publicExitId = `exit:${knowledge.publicId}`;
    const position = graph.layout.boundaryPositions?.[exit.id];
    if (!position) throw new Error(`boundary_position_missing:${exit.id}`);
    boundaryNodes.push({
      id: publicExitId,
      title: knowledge.displayLabel ?? "Известный выход",
      iconKey: "exit",
      x: position.x,
      y: position.y,
      labelPriority: 2,
      knowledgeState: presentation === "traversed" ? "visited" : presentation,
      current: false,
      selectable: true,
      hasKnownChildren: knowledge.knownTargetMapAvailable === true,
      synthetic: "boundary_exit"
    });
    const styleKey = styleForEdge(knowledge.displayType);
    boundaryEdges.push({
      id: `boundary-edge:${knowledge.publicId}`,
      source: sourcePublicId,
      target: publicExitId,
      edgeType: knowledge.displayType,
      styleKey,
      markerKey: markerForEdge(knowledge.displayType),
      knowledgeState: presentation,
      traversalState: knowledge.traversalState,
      bendPoints: graph.layout.edgeGeometry?.[exit.id] ?? [],
      knownSummary: knowledge.knownSummary
    });
  }
  return { ...graph, boundaryNodes, boundaryEdges };
}
