# Toponymy audit: gn_nov_g1_xp017_yp025

Result: **PASS**.

All names are marked `functional_descriptive`. None is claimed as an attested medieval proper name. No modern settlement name is used as a historical object.
