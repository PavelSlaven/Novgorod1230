import test from "node:test";
import assert from "node:assert/strict";
import { calculateLayoutQuality } from "../dist/node.js";

const nodes = [
  { id: "a", parentNodeId: "p", level: "G4", title: "A", nodeType: "yard" },
  { id: "b", parentNodeId: "p", level: "G4", title: "B", nodeType: "yard" }
];

test("quality report detects and clears node overlaps", () => {
  const overlap = calculateLayoutQuality(nodes, [], { a: { x: .5, y: .5 }, b: { x: .52, y: .5 } });
  assert.equal(overlap.nodeOverlapCount, 1);
  const clear = calculateLayoutQuality(nodes, [], { a: { x: .2, y: .2 }, b: { x: .8, y: .8 } });
  assert.equal(clear.nodeOverlapCount, 0);
  assert.equal(clear.invalidCoordinateCount, 0);
});

test("quality report detects edge crossings", () => {
  const four = ["a","b","c","d"].map((id) => ({ id, parentNodeId: "p", level: "G4", title: id, nodeType: "yard" }));
  const edges = [{ id: "ac", source: "a", target: "c", edgeType: "road" }, { id: "bd", source: "b", target: "d", edgeType: "road" }];
  const report = calculateLayoutQuality(four, edges, { a:{x:.2,y:.2}, b:{x:.8,y:.2}, c:{x:.8,y:.8}, d:{x:.2,y:.8} });
  assert.equal(report.edgeCrossingCount, 1);
});
