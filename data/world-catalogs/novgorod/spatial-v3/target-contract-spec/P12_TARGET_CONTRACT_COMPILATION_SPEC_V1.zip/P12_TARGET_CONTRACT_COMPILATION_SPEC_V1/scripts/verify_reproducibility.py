from __future__ import annotations
import csv, hashlib, json, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []
def fail(code, detail): errors.append({'code': code, 'detail': detail})
def read_json(path): return json.loads((ROOT / path).read_text(encoding='utf-8-sig'))
def csv_rows(path):
    with (ROOT / path).open(encoding='utf-8-sig', newline='') as fh: return list(csv.DictReader(fh))

zip_path = ROOT / 'inputs/P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE.zip'
count_ledger = read_json('data/count-ledger.json')
if hashlib.sha256(zip_path.read_bytes()).hexdigest() != count_ledger['p12_source_zip_sha256']:
    fail('source_zip_digest_mismatch', str(zip_path))

prefix = 'P12_NOVGOROD_SOURCE_APPROVAL_PACKAGE/'
with zipfile.ZipFile(zip_path) as zf:
    names = set(zf.namelist())
    manifest_name = prefix + 'manifest.json'
    if manifest_name not in names:
        fail('source_manifest_missing', manifest_name)
    else:
        manifest = json.loads(zf.read(manifest_name))
        declared = {prefix + r['path']: r for r in manifest['files']}
        actual_files = {n for n in names if not n.endswith('/') and n != manifest_name}
        if set(declared) != actual_files:
            fail('source_fileset_mismatch', {'missing': sorted(set(declared)-actual_files), 'extra': sorted(actual_files-set(declared))})
        for name, rec in declared.items():
            payload = zf.read(name)
            if len(payload) != rec['size'] or hashlib.sha256(payload).hexdigest() != rec['sha256']:
                fail('source_file_digest_mismatch', name)
        for local_name in [
            'catalog.json','g4-host-sectors.json','canonical-g5-inventory.json','physical-exit-source-pairs.json',
            'legacy-edge-mapping-bindings.json','approved-scene-profile-families.json','approved-scene-template-families.json',
            'scene-materialization-profiles.json','scene-materialization-candidates.json','scene-profile-assignments.json','provenance.json'
        ]:
            archive_bytes = zf.read(prefix + 'data/' + local_name)
            local_bytes = (ROOT / 'inputs' / local_name).read_bytes()
            if archive_bytes != local_bytes:
                fail('copied_input_not_byte_identical', local_name)

# Recompute deterministic logical projections from copied inputs and compare key columns.
pairs = read_json('inputs/physical-exit-source-pairs.json')['records']
g4s = read_json('inputs/g4-host-sectors.json')['records']
g5s = read_json('inputs/canonical-g5-inventory.json')['records']
profiles = read_json('inputs/scene-materialization-profiles.json')['records']
candidates = read_json('inputs/scene-materialization-candidates.json')['records']

directions = csv_rows('data/source-direction-ledger.csv')
expected_direction_ids = {d['direction_id'] for p in pairs for d in p['directions']}
if {r['direction_id'] for r in directions} != expected_direction_ids:
    fail('direction_ledger_not_reproducible', 'direction IDs differ')

nodes = csv_rows('data/canonical-node-compilation.csv')
if {r['id'] for r in nodes} != {r['id'] for r in g4s} | {r['id'] for r in g5s}:
    fail('node_compilation_not_reproducible', 'node IDs differ')

scene = csv_rows('data/scene-profile-compilation.csv')
cand_map = {(r['profile_id'], r['profile_version']): r for r in candidates}
for r in scene:
    key = (r['profile_id'], r['profile_version'])
    if key not in cand_map or r['scene_template_ref'] != cand_map[key]['scene_template_ref']:
        fail('scene_compilation_not_reproducible', r['profile_id'])
if {r['profile_id'] for r in scene} != {r['id'] for r in profiles}:
    fail('scene_profile_set_mismatch', 'profile IDs differ')

result = {'schema_version': 'rus.p12_target_reproducibility.v1', 'result': 'PASS' if not errors else 'FAIL', 'errors': errors}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(0 if not errors else 1)
