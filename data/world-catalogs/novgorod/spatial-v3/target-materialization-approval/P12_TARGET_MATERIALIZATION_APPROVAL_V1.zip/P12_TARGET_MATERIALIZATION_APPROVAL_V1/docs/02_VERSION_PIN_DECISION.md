# Version-pin decision

The approved target world revision is `novgorod_spatial_v3_target_contract_approval_001@1`. All 15 retained G2 and 32 retained G3 parents use immutable authoring version `1`; their exact refs are listed in `data/version-pins.csv`.

The 32 host G4 and 195 canonical G5 rows retain version `1`. No `latest` lookup is permitted. Every import must use the explicit `(id, version)` graph.

The exact Git commit is not a content version. It is produced after integration and is required only for P27/fresh-checkout/P28 evidence.
