import type { BoundaryGraph, CollapsedGraph, VisibleEdge } from "./internal.js";

export function collapseVisualEdges(graph: BoundaryGraph): CollapsedGraph {
  const byCanonicalId = new Map(graph.visibleEdges.map((edge) => [edge.canonicalId, edge]));
  const consumed = new Set<string>();
  const collapsedEdges: VisibleEdge[] = [];
  for (const edge of graph.visibleEdges) {
    if (consumed.has(edge.canonicalId)) continue;
    const reverse = edge.reverseCanonicalId ? byCanonicalId.get(edge.reverseCanonicalId) : undefined;
    consumed.add(edge.canonicalId);
    if (reverse && reverse.displayType === edge.displayType) {
      consumed.add(reverse.canonicalId);
      const sorted = [edge, reverse].sort((a, b) => a.publicId.localeCompare(b.publicId));
      const first = sorted[0]!;
      const second = sorted[1]!;
      collapsedEdges.push({ ...first, publicId: `${first.publicId}~${second.publicId}`, reverse: {
        publicId: second.publicId,
        knowledgeState: second.knowledgeState,
        traversalState: second.traversalState,
        knownSummary: second.knownSummary
      }});
    } else {
      collapsedEdges.push(edge);
    }
  }
  return { ...graph, collapsedEdges };
}
