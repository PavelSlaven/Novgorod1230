import type { BuildMapViewInput } from "../../domain/types.js";
import type { ValidatedRequest } from "./internal.js";

export function validateMapRequest(input: BuildMapViewInput): ValidatedRequest {
  if (!input.parentNodeId || !/^G[1-4]$/.test(input.level)) throw new Error("invalid_map_request");
  if (input.layout.parentNodeId !== input.parentNodeId || input.layout.level !== input.level) {
    throw new Error("map_layout_mismatch");
  }
  const currentKnowledge = input.nodeKnowledge.find((item) => item.nodeId === input.currentNodeId);
  if (!currentKnowledge) throw new Error("current_position_not_known");
  if (!["visited", "seen", "known_exactly"].includes(currentKnowledge.state)) {
    throw new Error("current_position_not_exact");
  }
  return {
    parentNodeId: input.parentNodeId,
    level: input.level,
    currentNodeId: input.currentNodeId,
    allowUnapprovedLayout: input.allowUnapprovedLayout === true,
    breadcrumbs: input.breadcrumbs ?? []
  };
}
