import type { BuildMapViewInput, MapViewDTO } from "../../domain/types.js";
import { applyCharacterKnowledge } from "./apply-character-knowledge.js";
import { applyPartyOverlay } from "./apply-party-overlay.js";
import { attachApprovedLayout } from "./attach-approved-layout.js";
import { attachVisualStyles } from "./attach-visual-styles.js";
import { buildMapViewDTO } from "./build-map-view-dto.js";
import { collapseVisualEdges } from "./collapse-visual-edges.js";
import { loadLocalCanonicalGraph } from "./load-local-canonical-graph.js";
import { materializeBoundaryExits } from "./materialize-boundary-exits.js";
import { validateMapRequest } from "./validate-map-request.js";
import { validateNoHiddenLeaks } from "./validate-no-hidden-leaks.js";

export function runMapViewPipeline(input: BuildMapViewInput): MapViewDTO {
  const request = validateMapRequest(input);
  const canonical = loadLocalCanonicalGraph(input, request);
  const withParty = applyPartyOverlay(canonical);
  const visible = applyCharacterKnowledge(withParty);
  const withExits = materializeBoundaryExits(visible);
  const collapsed = collapseVisualEdges(withExits);
  const positioned = attachApprovedLayout(collapsed);
  const styled = attachVisualStyles(positioned);
  return validateNoHiddenLeaks(buildMapViewDTO(styled));
}
