const EDGE_ALIASES: Record<string, string> = {
  road: "road", route: "road", corridor_segment: "corridor_segment", street: "street",
  path: "path", trail: "path", forest_track: "forest_track", river: "river", lake_route: "lake_route",
  water_route: "lake_route", winter_road: "winter_road", yard_passage: "yard_passage", passage: "yard_passage",
  door: "door", gate: "gate", bridge: "bridge", ford: "ford", ferry: "ferry",
  crossing: "offroad_crossing", offroad_crossing: "offroad_crossing", border_transition: "border_transition",
  unknown_route: "other"
};

export const markerForEdge = (edgeType: string): string | undefined =>
  ["bridge", "gate", "door", "ford", "ferry"].includes(edgeType) ? edgeType : undefined;

export const styleForEdge = (edgeType: string): string => EDGE_ALIASES[edgeType] ?? "other";

export const EDGE_LABELS: Record<string, string> = {
  road: "Дорога", corridor_segment: "Магистраль", street: "Улица", path: "Тропа",
  forest_track: "Лесная тропа", river: "Река", lake_route: "Водный путь", winter_road: "Зимник",
  yard_passage: "Проход", door: "Дверь", gate: "Ворота", bridge: "Мост", ford: "Брод",
  ferry: "Переправа", offroad_crossing: "Вне дорог", border_transition: "Выход", other: "Связь"
};
