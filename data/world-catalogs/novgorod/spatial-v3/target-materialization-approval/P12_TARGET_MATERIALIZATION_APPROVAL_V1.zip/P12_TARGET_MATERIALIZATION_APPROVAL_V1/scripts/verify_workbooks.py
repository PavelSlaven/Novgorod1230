from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]
def load(rel): return json.loads((ROOT/rel).read_text(encoding='utf-8'))
def rows(rel):
    with (ROOT/rel).open(encoding='utf-8',newline='') as f: return list(csv.DictReader(f))
def fail(msg): print('FAIL workbooks:',msg); raise SystemExit(1)

vp=load('data/version-pins.json')['records']; vw=rows('workbooks/approved-version-pin-resolution.csv')
if len(vp)!=50 or len(vw)!=50: fail('version workbook count')
for a,b in zip(vp,vw):
    for k in b:
        if str(a.get(k) or '')!=b[k]: fail('version workbook mismatch '+a['stable_id']+' '+k)

profiles=load('data/approved-connection-profiles.json')['records']; pw=rows('workbooks/approved-endpoint-profile-authoring.csv')
if len(profiles)!=12 or len(pw)!=12: fail('profile workbook count')
pm={r['source_edge_type']:r for r in profiles}
for w in pw:
    p=pm.get(w['edge_type'])
    if not p: fail('unknown workbook edge type '+w['edge_type'])
    checks={
        'target_scope':p['target_scope'],
        'cost_kind':p['cost_kind'],
        'passage_or_route_kind_id':p['passage_or_route_kind_ref'].rsplit('@',1)[0],
        'transition_environment_profile_ref':p['transition_environment_profile_ref'],
        'movement_orientation_profile_ref':p['movement_orientation_profile_ref'],
        'risk_profile_ref':p['risk_profile_ref'],
        'availability_condition_set_ref':p['availability_condition_set_ref'],
        'editorial_status':'approved',
        'blocking_gap_code':'',
    }
    for k,v in checks.items():
        if w[k]!=str(v): fail('profile workbook mismatch '+w['edge_type']+' '+k)
    if p['cost_kind']=='action':
        if w['action_units']!=str(p['action_units']) or any(w[k] for k in ['baseline_movement_method_id','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref']): fail('profile action XOR workbook')
    else:
        if w['action_units'] or w['baseline_movement_method_id']!=p['baseline_movement_method_ref'].rsplit('@',1)[0] or w['movement_method_cost_profile_ref']!=p['movement_method_cost_profile_ref'] or w['base_minutes']!=str(p['base_minutes']) or w['dynamic_recheck_policy_ref']!=p['dynamic_recheck_policy_ref']: fail('profile time XOR workbook')

routes=load('data/approved-world-routes.json')['records']; rw=rows('workbooks/approved-route-chain-authoring.csv')
if len(routes)!=86 or len(rw)!=86: fail('route workbook count')
rm={r['id'].replace('wrv3__','wrrqv3__',1):r for r in routes}
for w in rw:
    r=rm.get(w['route_request_id'])
    if not r: fail('unknown route request '+w['route_request_id'])
    if w['source_pair_ref']!=r['source_pair_ref'] or w['from_canonical_g5_id']+'@1'!=r['from_canonical_g5_ref'] or w['to_canonical_g5_id']+'@1'!=r['to_canonical_g5_ref']: fail('route workbook endpoint mismatch '+w['route_request_id'])
    if w['reverse_route_request_id']!=r['reverse_route_ref'].rsplit('@',1)[0].replace('wrv3__','wrrqv3__',1): fail('route workbook reverse mismatch')
    if w['ordered_route_point_ids'].split('|')!=r['ordered_point_refs']: fail('route workbook points')
    if w['editorial_status']!='approved' or w['blocking_gap_code']!='': fail('route workbook approval')

print('PASS verify_workbooks 50 pins / 12 profiles / 86 routes')
