export type MapScaleLevel = "G1" | "G2" | "G3" | "G4";
export type NodeKnowledgeState = "visited" | "seen" | "known_exactly" | "known_roughly" | "rumored" | "doubtful";
export type InternalNodeKnowledgeState = NodeKnowledgeState | "false_belief";
export type EdgeKnowledgeState = "traversed" | "known_exactly" | "known_roughly" | "rumored" | "doubtful";
export type InternalEdgeKnowledgeState = EdgeKnowledgeState | "false_belief";
export type TraversalState = "open" | "restricted" | "blocked" | "seasonal" | "unknown";
export type LayoutStatus = "draft" | "geometry_failed" | "geometry_validated" | "needs_semantic_review" | "approved" | "rejected";
export type BoundarySide = "north" | "east" | "south" | "west";

export interface Point { x: number; y: number }

export interface MapBreadcrumb {
  publicNodeId: string;
  title: string;
  level: MapScaleLevel;
}

export interface MapNodeDTO {
  id: string;
  title: string;
  shortLabel?: string;
  description?: string;
  iconKey: string;
  x: number;
  y: number;
  labelPriority?: 1 | 2 | 3;
  knowledgeState: NodeKnowledgeState;
  current: boolean;
  selectable: boolean;
  hasKnownChildren: boolean;
  synthetic?: "boundary_exit";
  visibleStatus?: { blocked?: boolean; dangerous?: boolean; occupied?: boolean; changed?: boolean };
}

export interface DirectionState {
  traversalState: TraversalState;
  knownSummary?: string;
}

export interface MapEdgeDTO {
  id: string;
  source: string;
  target: string;
  edgeType: string;
  styleKey: string;
  markerKey?: string;
  knowledgeState: EdgeKnowledgeState;
  traversalState: TraversalState;
  bendPoints: Point[];
  knownSummary?: string;
  directions?: { forward?: DirectionState; reverse?: DirectionState };
}

export interface MapLegendItem { key: string; label: string; kind: "node" | "edge" | "state" }

export interface LayoutQualityReport {
  nodeOverlapCount: number;
  minimumNodeDistance: number;
  edgeCrossingCount: number;
  labelCollisionCount: number;
  boundaryExitConflictCount: number;
  invalidCoordinateCount: number;
  duplicateCoordinateCount: number;
  missingGeometryCount: number;
  totalEdgeBends: number;
  aspectRatio: number;
}

export interface SemanticReview {
  required: boolean;
  decision: "approved" | "rejected" | "not_required";
  reviewerType: "human" | "llm" | "policy";
  reviewerId: string;
  reviewedAt: string;
  rationale: string[];
}

export interface MapViewDTO {
  layout: {
    id: string;
    level: MapScaleLevel;
    parentNodeId: string;
    version: number;
    widthRatio: number;
    heightRatio: number;
    status: LayoutStatus;
    qualityReport?: LayoutQualityReport;
    semanticReview?: SemanticReview;
  };
  breadcrumbs: MapBreadcrumb[];
  currentPosition: { nodeId: string; cameFromNodeId?: string; cameByVisualEdgeId?: string };
  nodes: MapNodeDTO[];
  edges: MapEdgeDTO[];
  legend: MapLegendItem[];
  viewPermissions: { canZoomOut: boolean; canOpenParent: boolean; canOpenChildren: boolean };
}

export interface CanonicalNode {
  id: string;
  parentNodeId: string;
  level: MapScaleLevel;
  title: string;
  nodeType: string;
  gridX?: number;
  gridY?: number;
}

export interface CanonicalEdge {
  id: string;
  reverseEdgeId?: string;
  source: string;
  target: string;
  edgeType: string;
}

export interface CompiledBoundaryExit {
  id: string;
  edgeIds: string[];
  sourceNodeId: string;
  externalNodeId: string;
  side: BoundarySide;
  edgeType: string;
}

export interface CharacterNodeKnowledge {
  nodeId: string;
  publicId: string;
  state: InternalNodeKnowledgeState;
  presentationState?: NodeKnowledgeState;
  displayTitle: string;
  displayDescription?: string;
  displayIconKey: string;
  displayPosition?: Point;
  knownChildMapAvailable: boolean;
  visibleStatus?: MapNodeDTO["visibleStatus"];
}

export interface CharacterEdgeKnowledge {
  edgeId: string;
  publicId: string;
  state: InternalEdgeKnowledgeState;
  presentationState?: EdgeKnowledgeState;
  displayType: string;
  displayLabel?: string;
  traversalState: TraversalState;
  knownSummary?: string;
  knownTargetMapAvailable?: boolean;
}

export interface PartyNodeOverlay {
  nodeId: string;
  visibleStatus?: MapNodeDTO["visibleStatus"];
}

export interface PartyEdgeOverlay {
  edgeId: string;
  traversalState?: TraversalState;
  knownSummary?: string;
}

export interface PartyMapOverlay {
  nodes?: PartyNodeOverlay[];
  edges?: PartyEdgeOverlay[];
}

export interface SavedLayout {
  id: string;
  parentNodeId: string;
  level: MapScaleLevel;
  version: number;
  profile: string;
  status: LayoutStatus;
  positions: Record<string, Point>;
  edgeGeometry?: Record<string, Point[]>;
  boundaryPositions?: Record<string, Point>;
  qualityReport?: LayoutQualityReport;
  semanticReview?: SemanticReview;
}

export interface BuildMapViewInput {
  parentNodeId: string;
  level: MapScaleLevel;
  nodes: CanonicalNode[];
  edges: CanonicalEdge[];
  boundaryExits?: CompiledBoundaryExit[];
  nodeKnowledge: CharacterNodeKnowledge[];
  edgeKnowledge: CharacterEdgeKnowledge[];
  partyOverlay?: PartyMapOverlay;
  layout: SavedLayout;
  currentNodeId: string;
  breadcrumbs?: MapBreadcrumb[];
  allowUnapprovedLayout?: boolean;
}

export interface MapDataSource {
  loadView(request: { parentNodeId: string; level: MapScaleLevel }): Promise<MapViewDTO>;
}
