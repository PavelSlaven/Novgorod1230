from pathlib import Path
import hashlib,json,re,sys
from collections import defaultdict,Counter
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def recs(p): return load(p)['records']
def fail(msg): print('FAIL target projection:',msg); raise SystemExit(1)
def rid(x): return x.rsplit('@',1)[0] if x else None
def vref(i,v='1'): return f'{i}@{v}'
def exact(row,fields,label):
    if set(row)!=set(fields): fail(f'{label} fields missing={set(fields)-set(row)} extra={set(row)-set(fields)}')
# Load
world=recs('target/world-revisions.json'); nodes=recs('target/canonical-spatial-nodes.json')
sp=recs('target/scene-materialization-profiles.json'); sc=recs('target/scene-materialization-candidates.json')
op=recs('target/topological-movement-orientation-profiles.json'); dc=recs('target/topological-direction-contexts.json')
cp=recs('target/canonical-g5-connection-profiles.json'); cb=recs('target/canonical-g5-connection-bindings.json')
ep=recs('target/g4-entry-endpoint-bindings.json'); exits=recs('target/g4-directional-exits.json')
routes=recs('target/world-routes.json'); pts=recs('target/world-route-points.json'); segs=recs('target/world-route-segments.json')
ctx=recs('target/world-route-segment-spatial-contexts.json'); ends=recs('target/world-route-endpoint-bindings.json')
tp=recs('target/g4-traversal-profiles.json'); tcb=recs('target/g4-traversal-direction-context-bindings.json'); teb=recs('target/g4-traversal-exit-bindings.json')
deps=recs('target/authoring-dependency-edges.json')
counts=load('target/target-projection-counts.json')['counts']
expected={'world_revisions':1,'version_pins':50,'canonical_spatial_nodes':227,'scene_materialization_profiles':195,'scene_materialization_candidates':195,'topological_orientation_profiles':4,'topological_direction_contexts':86,'canonical_g5_connection_profiles':12,'canonical_g5_connection_bindings':454,'g4_entry_endpoint_bindings':32,'route_context_links_staging_only':56,'direct_route_source_bindings':43,'g4_traversal_profiles':32,'g4_traversal_direction_context_bindings':86,'g4_traversal_exit_bindings':86,'g4_directional_exits':86,'world_routes':86,'world_route_points':172,'world_route_segments':86,'world_route_segment_spatial_contexts':86,'world_route_endpoint_bindings':172,'external_dependency_pins':475}
for k,v in expected.items():
    if counts.get(k)!=v: fail(f'count ledger {k}={counts.get(k)} expected {v}')
# Exact fields.
node_fields=['id','version','world_revision_id','scale_level','spatial_class_id','parent_ref','primary_function_id','shape_id','regional_template_ref','grid_x','grid_y','grid_convention_ref','evidence_status','status','provenance_ref']
for x in nodes: exact(x,node_fields,'canonical_spatial_node')
route_fields=['id','version','route_kind_id','reverse_route_ref','availability_condition_set_ref','risk_profile_ref','status','provenance_ref']
for x in routes: exact(x,route_fields,'world_route')
point_fields=['id','version','world_route_ref','ordinal','point_kind','anchor_policy','stable_label_id','context_switch_phase','status','provenance_ref']
for x in pts: exact(x,point_fields,'world_route_point')
seg_fields=['id','version','world_route_ref','ordinal','from_route_point_ref','to_route_point_ref','transition_environment_profile_ref','movement_orientation_profile_ref','baseline_movement_method_id','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref','capacity','risk_profile_ref','availability_condition_set_ref','status','provenance_ref']
for x in segs: exact(x,seg_fields,'world_route_segment')
end_fields=['id','version','world_route_ref','endpoint_role','route_point_ref','canonical_g5_id','directional_exit_ref','scene_endpoint_slot_key','status','provenance_ref']
for x in ends: exact(x,end_fields,'world_route_endpoint_binding')
exit_fields=['id','version','g4_id','direction_context_id','exit_orientation_rule_ref','exit_kind','exit_canonical_g5_id','boundary_feature_template_ref','status','provenance_ref']
for x in exits: exact(x,exit_fields,'g4_directional_exit')
# IDs unique.
for label,xs in [('nodes',nodes),('profiles',sp),('orientation',op),('direction context',dc),('connection profiles',cp),('connections',cb),('entries',ep),('exits',exits),('routes',routes),('points',pts),('segments',segs),('endpoints',ends)]:
    ids=[vref(x['id'],x['version']) for x in xs if 'id' in x]
    if len(ids)!=len(set(ids)): fail(label+' duplicate identity')
# Node parent/version graph.
node_map={vref(x['id'],x['version']):x for x in nodes}
g4={k:v for k,v in node_map.items() if v['scale_level']=='G4'}; g5={k:v for k,v in node_map.items() if v['scale_level']=='G5'}
if len(g4)!=32 or len(g5)!=195: fail('G4/G5 split')
for x in g5.values():
    if x['parent_ref'] not in g4: fail('G5 parent not target G4 '+x['id'])
for x in nodes:
    if x['world_revision_id']!=world[0]['id'] or x['status']!='approved': fail('node world/status')
    if any(x[k] is not None for k in ['grid_x','grid_y','grid_convention_ref']): fail('non-G1 grid fields populated')
# Scene exact one profile/candidate per G5.
spm={vref(x['id'],x['version']):x for x in sp}; cand=defaultdict(list)
for x in sc: cand[vref(x['profile_id'],x['profile_version'])].append(x)
if set(x['source_ref'] for x in sp)!=set(g5): fail('scene profile G5 coverage')
for k in spm:
    if len(cand[k])!=1 or cand[k][0]['weight']!=1: fail('scene candidate cardinality '+k)
# Profiles XOR and topological ref.
oprefs={vref(x['id'],x['version']) for x in op}
cpmap={vref(x['id'],x['version']):x for x in cp}
for x in cp:
    if x['movement_orientation_profile_ref'] not in oprefs: fail('unresolved topological orientation')
    if x['profile_scope']=='world_route_segment' and x['cost_kind']!='time': fail('world route segment non-time')
    if x['cost_kind']=='action':
        if not x['action_units'] or any(x[k] is not None for k in ['baseline_movement_method_id','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref']): fail('action XOR')
    elif x['cost_kind']=='time':
        if x['action_units'] is not None or any(x[k] is None for k in ['baseline_movement_method_id','movement_method_cost_profile_ref','base_minutes','dynamic_recheck_policy_ref']): fail('time XOR')
    else: fail('cost kind')
# Connection parent and reciprocity.
cbmap={vref(x['id'],x['version']):x for x in cb}
for x in cb:
    fg=vref(x['from_canonical_g5_id']); tg=vref(x['to_canonical_g5_id']); pg=vref(x['parent_g4_id'])
    if fg not in g5 or tg not in g5 or g5[fg]['parent_ref']!=pg or g5[tg]['parent_ref']!=pg: fail('connection parent')
    if x['connection_profile_ref'] not in cpmap or cpmap[x['connection_profile_ref']]['profile_scope']!='site_connection': fail('connection profile scope')
    rev=cbmap.get(x['reverse_binding_ref'])
    if not rev or rev['reverse_binding_ref']!=vref(x['id']) or rev['from_canonical_g5_id']!=x['to_canonical_g5_id'] or rev['to_canonical_g5_id']!=x['from_canonical_g5_id']: fail('connection reciprocity')
# Direction contexts/exits.
dcmap={vref(x['id'],x['version']):x for x in dc}; exmap={vref(x['id'],x['version']):x for x in exits}
for e in exits:
    d=dcmap.get(vref(e['direction_context_id']))
    if not d or d['from_g4_ref']!=vref(e['g4_id']) or d['from_canonical_g5_ref']!=vref(e['exit_canonical_g5_id']): fail('exit direction context')
    if e['exit_kind']!='world_route_exit' or e['boundary_feature_template_ref'] is not None: fail('exit kind XOR')
# Routes chain/reciprocity and exact endpoint/segment rows.
rmap={vref(x['id'],x['version']):x for x in routes}; byroute_pts=defaultdict(list); byroute_seg=defaultdict(list); byroute_end=defaultdict(list)
for x in pts: byroute_pts[x['world_route_ref']].append(x)
for x in segs: byroute_seg[x['world_route_ref']].append(x)
for x in ends: byroute_end[x['world_route_ref']].append(x)
ctxkey={(x['segment_id'],x['segment_version']) for x in ctx}
for rr,r in rmap.items():
    rev=rmap.get(r['reverse_route_ref'])
    if not rev or rev['reverse_route_ref']!=rr: fail('route reciprocal ref')
    ps=sorted(byroute_pts[rr],key=lambda x:x['ordinal']); ss=sorted(byroute_seg[rr],key=lambda x:x['ordinal']); es=byroute_end[rr]
    if len(ps)!=2 or len(ss)!=1 or len(es)!=2: fail('route cardinality')
    if [x['ordinal'] for x in ps]!=[0,1] or [x['point_kind'] for x in ps]!=['endpoint_from','endpoint_to']: fail('point order')
    s=ss[0]
    if s['from_route_point_ref']!=vref(ps[0]['id']) or s['to_route_point_ref']!=vref(ps[1]['id']): fail('segment point continuity')
    if (s['id'],s['version']) not in ctxkey: fail('missing segment context')
    if s['base_minutes']<=0: fail('nonpositive route minutes')
    roles={x['endpoint_role']:x for x in es}
    if set(roles)!= {'from','to'}: fail('endpoint roles')
    if roles['from']['route_point_ref']!=vref(ps[0]['id']) or roles['from']['directional_exit_ref'] not in exmap: fail('from endpoint')
    if roles['to']['route_point_ref']!=vref(ps[1]['id']) or roles['to']['directional_exit_ref'] is not None: fail('to endpoint')
    # Reverse endpoints swap.
    revroles={x['endpoint_role']:x for x in byroute_end[r['reverse_route_ref']]}
    if roles['from']['canonical_g5_id']!=revroles['to']['canonical_g5_id'] or roles['to']['canonical_g5_id']!=revroles['from']['canonical_g5_id']: fail('route endpoint reciprocity')
# Every segment exactly one context.
if len(ctx)!=len(segs) or len(ctxkey)!=len(segs): fail('segment context cardinality')
for x in ctx:
    if x['g0_id']!='region_novgorod_land' or x['g1_id']!='gn_nov_g1_xp017_yp026' or x['weather_scope_id']!='weather_scope_g1__gn_nov_g1_xp017_yp026': fail('segment context scope')
# Traversal relations.
if len(tp)!=32: fail('traversal count')
for t in tp:
    if t['traversal_model']!='through_area': fail('traversal model')
for rows,label,field in [(tcb,'traversal contexts','direction_context_ref'),(teb,'traversal exits','directional_exit_ref')]:
    groups=defaultdict(list)
    for x in rows: groups[(x['g4_id'],x['g4_version'])].append(x)
    if set(groups)!={(t['g4_id'],t['g4_version']) for t in tp}: fail(label+' G4 coverage')
    for key,xs in groups.items():
        xs=sorted(xs,key=lambda x:x['ordinal'])
        if [x['ordinal'] for x in xs]!=list(range(len(xs))): fail(label+' ordinal')
# Dependency edge identity/ordinals.
dg=defaultdict(list); seen=set()
for x in deps:
    ident=(x['source_ref'],x['dependency_role'],x['target_ref'])
    if ident in seen: fail('duplicate dependency edge')
    seen.add(ident); dg[(x['source_ref'],x['dependency_role'])].append(x)
for k,xs in dg.items():
    if sorted(x['canonical_ordinal'] for x in xs)!=list(range(len(xs))): fail('dependency ordinal '+str(k))
# Every versioned target reference resolves to a local row or an explicit external pin.
external={x['ref'] for x in recs('target/external-dependency-pins.json')}
local=set()
for p in (ROOT/'target').glob('*.json'):
    if p.name in {'external-dependency-pins.json','authoring-dependency-edges.json','target-projection-counts.json'}:
        continue
    data=json.loads(p.read_text(encoding='utf-8'))
    for x in data.get('records',[]):
        if 'id' in x and 'version' in x: local.add(vref(x['id'],x['version']))
        elif 'profile_id' in x and 'profile_version' in x: local.add(vref(x['profile_id'],x['profile_version']))
        elif 'segment_id' in x and 'segment_version' in x: local.add(vref(x['segment_id'],x['segment_version']))
import re
allrefs=set()
def walkrefs(x):
    if isinstance(x,dict):
        for k,v in x.items(): walkrefs(v)
    elif isinstance(x,list):
        for v in x: walkrefs(v)
    elif isinstance(x,str) and re.fullmatch(r'[^\s@]+@[^\s@]+',x): allrefs.add(x)
for rel in ['target/world-revisions.json','target/canonical-spatial-nodes.json','target/scene-materialization-profiles.json','target/scene-materialization-candidates.json','target/topological-movement-orientation-profiles.json','target/topological-direction-contexts.json','target/canonical-g5-connection-profiles.json','target/canonical-g5-connection-bindings.json','target/g4-entry-endpoint-bindings.json','target/route-context-links.json','target/direct-route-source-bindings.json','target/g4-directional-exits.json','target/world-routes.json','target/world-route-points.json','target/world-route-segments.json','target/world-route-endpoint-bindings.json','target/weather-scopes.json','target/g4-traversal-direction-context-bindings.json','target/g4-traversal-exit-bindings.json']:
    walkrefs(load(rel))
unresolved=allrefs-local-external
if unresolved: fail('unresolved refs '+str(sorted(unresolved)[:10]))
# P28 boundary.
if load('data/p28-production-activation-status.json')['status']!='BLOCKED': fail('P28 not blocked')
print('PASS validate_target_projection',json.dumps(expected,sort_keys=True))
