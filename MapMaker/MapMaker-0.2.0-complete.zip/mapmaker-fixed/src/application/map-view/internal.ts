import type {
  BuildMapViewInput, CanonicalEdge, CanonicalNode, CharacterEdgeKnowledge, CharacterNodeKnowledge,
  CompiledBoundaryExit, EdgeKnowledgeState, MapBreadcrumb, MapEdgeDTO, MapNodeDTO, NodeKnowledgeState,
  PartyMapOverlay, Point, SavedLayout, TraversalState
} from "../../domain/types.js";

export interface ValidatedRequest {
  parentNodeId: string;
  level: BuildMapViewInput["level"];
  currentNodeId: string;
  allowUnapprovedLayout: boolean;
  breadcrumbs: MapBreadcrumb[];
}

export interface LocalCanonicalGraph {
  request: ValidatedRequest;
  nodes: CanonicalNode[];
  edges: CanonicalEdge[];
  boundaryExits: CompiledBoundaryExit[];
  nodeKnowledge: CharacterNodeKnowledge[];
  edgeKnowledge: CharacterEdgeKnowledge[];
  partyOverlay: PartyMapOverlay;
  layout: SavedLayout;
}

export interface OverlayGraph extends LocalCanonicalGraph {
  nodeStatusById: Map<string, MapNodeDTO["visibleStatus"]>;
  edgeStateById: Map<string, { traversalState?: TraversalState; knownSummary?: string }>;
}

export interface VisibleNode {
  canonicalId: string;
  publicId: string;
  title: string;
  shortLabel?: string;
  description?: string;
  iconKey: string;
  knowledgeState: NodeKnowledgeState;
  displayPosition?: Point;
  current: boolean;
  hasKnownChildren: boolean;
  visibleStatus?: MapNodeDTO["visibleStatus"];
}

export interface VisibleEdge {
  canonicalId: string;
  reverseCanonicalId?: string;
  publicId: string;
  sourceCanonicalId: string;
  targetCanonicalId: string;
  displayType: string;
  knowledgeState: EdgeKnowledgeState;
  traversalState: TraversalState;
  knownSummary?: string;
  reverse?: {
    publicId: string;
    knowledgeState: EdgeKnowledgeState;
    traversalState: TraversalState;
    knownSummary?: string;
  };
}

export interface VisibleGraph extends OverlayGraph {
  visibleNodes: VisibleNode[];
  visibleEdges: VisibleEdge[];
  publicNodeIdByCanonicalId: Map<string, string>;
}

export interface BoundaryGraph extends VisibleGraph {
  boundaryNodes: MapNodeDTO[];
  boundaryEdges: MapEdgeDTO[];
}

export interface CollapsedGraph extends BoundaryGraph {
  collapsedEdges: VisibleEdge[];
}

export interface PositionedGraph extends CollapsedGraph {
  positionedNodes: MapNodeDTO[];
  positionedEdges: MapEdgeDTO[];
}
