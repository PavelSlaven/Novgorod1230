# Route-chain decision

Each of the 43 approved bidirectional cross-G4 physical pairs produces two separately approved directed routes: 86 routes total.

Each route is a direct one-segment chain because the source pair itself already asserts a direct physical connection between the two canonical G5 endpoints. The approved `direct_route_source_binding` supplies continuity and provenance. This is not shortest-path synthesis.

Every route has exactly two ordered points, one segment, one from endpoint binding, one to endpoint binding, one directional exit and one reciprocal reverse route. Additional staging context links are optional constraints and never generate a path.
