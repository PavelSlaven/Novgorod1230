# Integration order

1. Verify both pinned ZIPs and this bundle manifest.
2. Integrate the approved amendment and schemas in the existing single PR.
3. Add failing contract/negative/database tests before implementation.
4. Implement normalized DDL and pure compilation stages.
5. Import the exact approved data into isolated PostgreSQL.
6. Verify counts, FKs, reciprocity, route continuity, readback digest and rollback.
7. Regenerate schema reference and repository intelligence artifacts.
8. Run targeted tests and the full project suite.
9. Obtain independent critic PASS or admissible PASS WITH NOTES.
10. Close P12 data gaps for the exact bundle digest.
11. Prepare an exact activation candidate commit; do not deploy.
12. Obtain signed P27/fresh-checkout/P28 evidence and only then deploy atomically.
