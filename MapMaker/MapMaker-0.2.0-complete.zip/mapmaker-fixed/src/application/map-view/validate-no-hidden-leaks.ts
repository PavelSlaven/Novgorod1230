import type { MapViewDTO } from "../../domain/types.js";
import { validateMapView } from "../validate-map-view.js";

export function validateNoHiddenLeaks(view: MapViewDTO): MapViewDTO {
  validateMapView(view);
  const serialized = JSON.stringify(view);
  if (/false_belief|canonical|externalNodeId|reverseCanonical/i.test(serialized)) throw new Error("hidden_semantic_leak");
  return view;
}
